#include <cstring>
#ifndef __PERSONA_H__
#define __PERSONA_H__

using namespace std;

typedef struct Tpersona {
	//propriet� della struttura Persone
	char* nome;
	char* cognome;
	int eta;

	//costruttore di default
	Tpersona() {
		nome = new char[strlen("Jane")+1];
		strcpy(nome, "Jane");
		cognome = new char[strlen("Doe")+1];
		strcpy(cognome, "Doe");
		eta=0;
		cout << "Persona Inizializzata per default\n";
	}

	//costruttore specifico
	Tpersona(char* _nome, char* _cognome, int _eta) {
		nome = new char[strlen(_nome)+1];
	 	strcpy(nome, _nome);
	 	cognome = new char[strlen(_cognome)+1];
		strcpy(cognome, _cognome);
		eta= _eta;
		cout << "Persona Inizializzata in modo specifico\n";
	}

	//distruttore
	~Tpersona() {
		cout << "Distuggo: " << nome << " " << cognome << ". ";
		delete[] nome;
		delete[] cognome;
		cout << "Persona distrutta\n";
	}

 	// metodo = 
	// nome per chiamare una funzione all'interno di una classe
	void stampa() const {  //questo metodo non cambia l'istanza
		 //si fa riferimento direttamente ai nomi dei campi
		 cout << nome << " " << cognome  << endl;
	 }

	//const Tpersona p2
	//    l'istanza p2 passata come riferimento non pu� essere cambiata
	// (..) const 
	//    l'istanza Tpersona (su cui � invocato il metodo) non pu� essere cambiata
	int confronta(const Tpersona p2) const {
		if (eta>p2.eta){
			 //cout << nome << " pi� vecchio di " << P2.nome;
			return -1;
		}
		if (eta<p2.eta){
			//cout << nome << " pi� giovane di " << P2.nome;
			return 1;
		}
		return 0;
	 }

};//end struct

// funzione stampa all'esterno della classe
// const 
//    perch� la funzione Stampa non deve cambiare l'istanza p
//    p.nome="aaa" non � permesso
void stampa(const Tpersona p);

// funzione stampa all'esterno della classe
// const 
//    perch� la funzione Stampa non deve cambiare l'istanza p
//    p.nome="aaa" non � permesso
void stampa2(const Tpersona* p);


#endif

