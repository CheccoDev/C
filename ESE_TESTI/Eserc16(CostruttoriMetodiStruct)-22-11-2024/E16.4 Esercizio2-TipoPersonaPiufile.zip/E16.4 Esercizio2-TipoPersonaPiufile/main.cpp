#include <cstdlib>
#include <iostream>
#include "persona.h"
using namespace std;


int main(int argc, char *argv[])
{
		//Mario non esiste all'infuori del blocco delle {}
	//visibilit� ristretta dell'istanza dell'oggetto Mario
	{
		Tpersona Mario;
		Tpersona Anna("Anna", "Rossi", 18);
		// invocazione funzione Stampa
		cout << "invocazione stampa Mario" << endl;
		stampa(Mario);	//passaggio di valore
		cout << "invocazione stampa Anna" << endl;
		stampa2(&Anna); //passaggio per riferimento
		// invocazione metodo Stampa
		cout << "invocazione Mario.stampa" << endl;
		Mario.stampa();
	    cout << "invocazione Anna.stampa" << endl;
		Anna.stampa();
		cout << "invocazione Mario.confronta Anna" << endl;
		cout << Mario.confronta(Anna) << endl;
		cout << "invocazione Anna.confronta Mario" << endl;
		cout << Anna.confronta(Mario) << endl;
		cout << "Prossima riga: chiusura blocco istruzioni" << endl;
	}
	cout << "Blocco istruzioni chiuso" << endl;
	// Mario viene distrutto dopo il blocco che lo contiene
	// Anna viene distrutto dopo il blocco che lo contiene
	//oppure 
	// si sarebbe dovuto invocare il rispettivo distrutture
    system("pause"); 
	return 0;
}

