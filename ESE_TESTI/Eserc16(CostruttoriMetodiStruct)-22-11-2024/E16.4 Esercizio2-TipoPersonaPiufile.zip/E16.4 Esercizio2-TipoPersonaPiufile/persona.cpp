#include <cstdlib>
#include <iostream>
#include "persona.h"
using namespace std;

// funzione stampa all'esterno della classe
// const 
//    perch� la funzione Stampa non deve cambiare l'istanza p
//    p.nome="aaa" non � permesso
void stampa(const Tpersona p){
	cout << p.nome << " " << p.cognome  << endl;
	//oppure
	// p.Stampa();
}

// funzione stampa all'esterno della classe
// const 
//    perch� la funzione Stampa non deve cambiare l'istanza p
//    p.nome="aaa" non � permesso
void stampa2(const Tpersona* p){
	cout << p->nome << " " << p->cognome  << endl;
	//oppure
	// p->Stampa();
}
