#include <cstdlib>
#include <iostream>
#include "FIFO.h"
#include "tipo_dati.h"
using namespace std;

bool cerca(CodaPtr p, Tdato d){
	if(p->head==NULL){  //lista VUOTA
		return false;
	} 
	//scorro gli elementi
	Tnodo *s = p->head;
	do{
		//if (d.compare(s->data))
		//if (s->data.compare(d))
		if (daticmp(s->data,d)){ 
			return true; 
		}
		s=s->next;      
	}while(s!=NULL);
	return false;
}

bool daticmp(Tdato d1, Tdato d2){
	if( (strcmp(d1.nome,d2.nome)==0) && (strcmp(d1.cognome,d2.cognome)==0) && (d1.eta==d2.eta) ){ 
		return true; 
	}
	return false;
}

//sarebbe meglio controllare se la lista � vuota prima
//di richiamare la get
// put: inserimento in head
// get: estrazione da tail
Tdato get(CodaPtr p){
	Tdato d; //dato inizializzato costruttore default
	if (p->head==NULL){//caso lista vuota 
		return d; 
	}
	if (p->head->next== NULL){
		//caso 1 solo elemento
		d = p->head->data;
		// deallocare elemento
		delete p->head;
		// lista vuota
		p->head=NULL;
		p->tail=NULL;
	}
	else{
		//lista con + elementi
		// salvare dato dell'ultimo nodo
		d = p->tail->data;
		// cercare elemento prima di quello puntato da tail
		Tnodo* before_tail = p->head;
		while(before_tail->next != p->tail){
		//while(before_last->next->next!=NULL){
			before_tail = before_tail->next;
		}
		// deallocare elemento puntato da tail
		delete p->tail;
		// aggiornare elemento che era prima di tail
		before_tail->next=NULL;
		// aggiornare tail
		p->tail = before_tail;
	}
	return d;
}

// put: inserimento in head
// get: estrazione da tail
void put(CodaPtr p, Tdato d){
	Tnodo* q = new Tnodo(d, p->head);
	p->head = q;
	// p->head = new Tnodo(d, p->head)
	if (p->tail==NULL){ 
		//caso di lista vuota
		p->tail = p->head; 
	}
}

void menu(CodaPtr p){
	int scelta;
	Tdato d;
	do{
		do{
			system("CLS");
			cout <<"1. leggi dato"<<endl; 
			cout <<"2. inserisci dato lista"<<endl;
			cout <<"3. ricerca dato"<<endl;      
			cout <<"4. stampa"<<endl;
			cout <<"5. estrai dati lista"<<endl;
			cout <<"6. FINE"<<endl;
			cin >> scelta;  
		} while( (scelta<1) || (scelta>6) ); 
		cout<<"=============="<<endl;
		switch (scelta)
		{
			case 1: {   
				fflush(stdin);
				cout <<"nome="; cin >> d.nome;
				cout <<"cognome="; cin >> d.cognome;
				cout <<"eta="; cin >> d.eta;
				break;
			} 
			case 2: { 
				put(p,d); 
				break;
			}
			case 3: {  
				cout <<"nome="; cin >> d.nome;
				cout <<"cognome="; cin >> d.cognome;
				cout <<"eta="; cin >> d.eta;
				if(cerca(p,d)==true)
				{ 	cout << "\nTrovato!!!";}
				else
				{ 	cout << "\nNon trovato!!!";}
				system("PAUSE");
				break;
			}
			case 4: { 
				p->stampa(); 
				system("PAUSE");  
				break;
			}
			case 5: { 
				d=get(p); 
				d.stampa(); 
				system("PAUSE"); 
				break;
			}                        
		}   
	}while (scelta!=6);
}

