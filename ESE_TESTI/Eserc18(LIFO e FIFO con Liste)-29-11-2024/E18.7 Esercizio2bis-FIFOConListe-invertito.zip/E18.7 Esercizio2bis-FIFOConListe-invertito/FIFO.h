#ifndef __FIFO_H__
#define __FIFO_H__
#include "tipo_dati.h"

void menu(CodaPtr p);
void put(CodaPtr p, Tdato d);
Tdato get(CodaPtr p);
bool cerca (CodaPtr p, Tdato d);
bool daticmp(Tdato d1,Tdato d2);
#endif
