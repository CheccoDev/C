#ifndef __TIPO_DATI_H__
#define __TIPO_DATI_H__
#include <iostream>
#include <cstring>
#define MAXCHAR 20
using namespace std;

typedef struct Tdato{
	char nome[MAXCHAR];
	char cognome[MAXCHAR];
	int eta;
	Tdato() { 
		nome[0]='\0'; 
		cognome[0]='\0'; 
		eta=0; 
	}  
	Tdato(char _nome[MAXCHAR],  char _cognome[MAXCHAR], int _eta){ 
		strcpy(nome,_nome); 
		strcpy(cognome,_cognome); 
		eta=_eta; 
	}
	void stampa(){ 
		cout << "nome:"<<nome<<" cognome:"<<cognome<<" eta:"<<eta << endl;   
	}      
	bool compare(Tdato d) {
		if(strcmp(nome,d.nome)==0 && strcmp(cognome,d.cognome)==0 && eta==d.eta ){ 
			return true;
		}
		return false;      
	}
}Tdato;

typedef struct Tnodo{
	Tdato data;
	Tnodo* next;
	Tnodo(){ 
		next=NULL; 
	}
	Tnodo(Tdato d, Tnodo* n) { 
		data=d; next=n;
	}
	void stampa(){ 
		data.stampa(); 
	}
}Tnodo;
typedef struct TipoCoda{
	Tnodo* head;	// puntatore al primo elemento inserito
					// punta all'elemento che si dovra' leggere con get
	Tnodo* tail;  	// puntatore ultimo elemento inserito
					// put deve inserire nuovo elemento prima di questo            
	TipoCoda(){
		head=NULL; 
		tail=NULL; 
	}
	void stampa(){
		Tnodo *s = head;
		while (s!=NULL){ 
			s->stampa(); 
			s= s->next; 
		}
		cout << endl;  
	}
	~TipoCoda(){
		cout << "\ndistruttore\n";
		Tnodo* tmp=head;
		while(head!=NULL){
			head = head->next;
			delete tmp;
			tmp = head;
		}
	}
} TipoCoda;

typedef TipoCoda Coda;
typedef TipoCoda* CodaPtr;


#endif
