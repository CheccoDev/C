#include <cstdlib>
#include <iostream>
#include "tipo_dati.h"
#include "FIFO.h"
using namespace std;

int main()
{
    CodaPtr p = new TipoCoda();
    menu(p);
    p->~Coda();
    return 1;
}
