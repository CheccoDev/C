#include <cstdlib>
#include <iostream>
#include "lista_struct.h"
using namespace std;

Nodoptr removeLast(Nodoptr s){
    // nessun elemento in lista
	if (s==NULL){ return NULL; }
	// 1 elemento in lista
	if (s->next==NULL){ delete s; return NULL; }
	Nodoptr p = s;
	while (p->next->next!=NULL){
		p=p->next;  
	} 
	delete p->next;
	p->next = NULL;
	return s;
}
Nodoptr removeFirst(Nodoptr s){
	Nodoptr n = s;
	if (s!=NULL){
		s= s->next;  
		delete n;        
	} 
	return s;   
}
void stampa(Nodoptr s){
	Nodoptr p = s;
	while (p!=NULL){
		p->stampa();
		p = p->next;    
	}
	cout << endl;
}
Nodoptr insertFirst(Nodoptr s, Tdato currD){
	return new Tnodo(currD, s);     
}

Nodoptr insertLast(Nodoptr s, Tdato currD){
	if(s==NULL){
		return new Tnodo(currD, NULL);
	}
	Nodoptr p = s;
	while (p->next!=NULL){ 
		p=p->next; 
	}
	p->next = new Tnodo(currD, NULL);
	return s;
}
int lung(Nodoptr s){
	int l=0;
	if (s==NULL){ 
		return l; 
	}
	Nodoptr p=s;
	do{
		l++;
		p=p->next;       
	}while(p!=NULL);  
	return l;       
}
