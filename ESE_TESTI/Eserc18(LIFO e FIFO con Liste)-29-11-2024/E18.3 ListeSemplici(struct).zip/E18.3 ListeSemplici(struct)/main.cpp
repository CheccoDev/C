#include <cstdlib>
#include <iostream>
#include "lista_struct.h"
using namespace std;

int main(int argc, char *argv[]){

    
    return EXIT_SUCCESS;
}



