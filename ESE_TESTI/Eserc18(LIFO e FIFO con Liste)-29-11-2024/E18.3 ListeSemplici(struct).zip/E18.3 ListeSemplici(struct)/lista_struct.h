#ifndef __LISTA__
#define __LISTA__

#include <cstdlib>
#include <iostream>
using namespace std;

typedef struct Tdato{
	int i; 
	float v;	
	Tdato(){
		i=0; v=0.0;
	}
	Tdato(int _i, float _v){
		i = _i; 
		v = _v;
	}
	void stampa()const{
		cout << "[ " << i << "-" << v << " ] " ;
	}
}Tdato;

typedef struct Tnodo{
	Tdato dato; 
	Tnodo *next;
  
	Tnodo(){
  		next = NULL;
  	}
  	Tnodo(Tdato d){
  		dato = d;
  		next = NULL;
  	}
  	Tnodo(Tdato d, Tnodo* n){
  		dato = d;
		next = n;
  	}
  	void stampa()const{
  		dato.stampa();
	}
}Tnodo;

typedef Tnodo* Nodoptr;

Nodoptr removeLast(Nodoptr s);
Nodoptr removeFirst(Nodoptr s);
void stampa(Nodoptr s);
Nodoptr insertFirst(Nodoptr s, Tdato CurrD);
Nodoptr insertLast(Nodoptr s, Tdato CurrD);
int lung(Nodoptr s);

#endif

