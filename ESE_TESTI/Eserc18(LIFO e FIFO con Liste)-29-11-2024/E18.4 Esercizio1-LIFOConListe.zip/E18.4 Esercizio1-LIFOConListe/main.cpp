#include <cstdlib>
#include <iostream>
#include "lifo.h"

using namespace std;

int main(int argc, char *argv[]){
  	// esercizio 2
  	Tnodo* stack=NULL;
  	Tdato x;
	x = Tdato("Mario", "Rossi", 23);
  	stack = push(stack, x);
  	
  	x = Tdato("Paolo", "Bianchi", 30);
  	stack = push(stack, x);
  	
  	x = Tdato("Maria", "Verdi", 20);
  	stack = push(stack, x);
  	
  	stampa(stack);
  	
  	if(stack!=NULL){
  		x = read(stack);
  		stack = pop(stack);
  		printf("\ndato estratto: ");
  		x.stampa();
  		printf("\n");
	}
	
	stampa(stack);
	printf ("\nlunghezza lista=%d\n",length(stack));
	
	system("PAUSE"); 
	
	// esercizio 3	
	Tnodo* p=NULL;
	int scelta;
	do{
		do{
			system("CLS");
			cout <<"1. leggi dato da tastiera"<<endl; 
			cout <<"2. inserisci dato stack"<<endl;
			cout <<"3. stampa stack"<<endl;      
			cout <<"4. leggi dato in stack"<<endl;
			cout <<"5. estrai dato dalla stack"<<endl;
			cout <<"6. FINE"<<endl;
			cin >> scelta;  
		} while( (scelta<1) || (scelta>6) ); 
		cout<<"=============="<<endl;
		switch (scelta)
		{
			case 1: {   
				fflush(stdin);
				cout <<"nome="; cin >> x.nome;
				cout <<"cognome="; cin >> x.cognome;
				cout <<"eta="; cin >> x.eta;
				break;
			} 
			case 2: {
				p = push(p,x);
				printf("\ndato inserito\n");
				system("PAUSE");
				break;
			}
			case 3: {  
				stampa(p);
				printf("\nstack\n");
				system("PAUSE");
				break;
			}
			case 4: { 
				x = read(p);
				x.stampa();
				printf("\nprimo dato in coda\n");
				system("PAUSE");  
				break;
			}
			case 5: {
				x = read(p); 
				p = pop(p); 
				x.stampa(); 
				system("PAUSE"); 
				break;
			}
		}   
	}while (scelta!=6);
	
	// svuotare stack
	while(p!=NULL){
		p = pop(p);
	}
	return EXIT_SUCCESS;
}

