#include <cstdlib>
#include <iostream>
#include "lifo.h"

using namespace std;

//scorro la lista LIFO e la stampo
void stampa(Tnodo* s){
	Tnodo* p = s;
   	while(p!=NULL){ 
    //chiamo il metodo stampa del Tnodo
    //che a sua volta chiama il metodo stampa del Tdato
    	p->stampa(); 
    	printf("\n");
    	p=p->next; 
   	}  
}

//conta quanti elmenti ho nella lista LIFO
int length(Tnodo* s){
	int l;
	Tnodo* p;
	l=0;
	for(p=s ;p!=NULL; p=p->next ) {
		l++;     
	}
	return l;   
}     

//insertFirst
Tnodo* push(Tnodo* s, Tdato d){
	Tnodo* n = new Tnodo();
	n->dato = d; 
	n->next = s;
	return n;
	// return new Tnodo(d, s);
}

//removeFirst
Tnodo* pop (Tnodo* s)  {
  if (s==NULL){ 
    return s; 
  } 
  Tnodo* n = s;
  s = s->next;
  delete n;
  return s;
}

//lettura elemento in testa
Tdato read (Tnodo* s){
  Tdato d; //costruttore default; // Tdato d = Tdato(); // Tdato d();
  //se lista vuota devo ritornare comunque qualcosa
  //meglio sempre controllare prima di invicare la pop
  if (s==NULL){ 
    return d; 
  }
  return s->dato;
}

bool daticmp (Tdato d1, Tdato d2){
	// implementazione 1
	/*
	if ( (strcmp(d1.nome,d2.nome)==0) && (strcmp(d1.cognome,d2.cognome)==0) && (d1.eta==d2.eta) )
		return true; 
	else
		return false;        
	*/
	// implementazione 2
	// sfruttare metodo definito nella struttura Tdato
	return d1.compara(d2);
	// implementazione 2 migliore: se cambia il tipo di Tdato 
	// (esempio: contenente le coordinate di un punto float x; float y)
	// la funzione daticmp non cambia: cambia l'implementazione della 
	// funzione compara in struct Tdato
}
