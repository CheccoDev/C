#include <iostream>
#include <cstdio>
#include <cstring>
#define MAXSTR 50
typedef struct Tdato{
  	char nome[MAXSTR];
	char cognome[MAXSTR];
	int eta;
	Tdato(){
		nome[0]='\0';
		cognome[0]='\0';
		eta=0;
	} 
	Tdato(char* _nome, char* _cognome, int _eta){
		strcpy(nome, _nome);
		strcpy(cognome, _cognome);   
		eta = _eta;
	}   
	void stampa()const{
		printf("%s %s %d",nome, cognome, eta);    
	}
	bool compara(Tdato d){
		if ( (strcmp(nome,d.nome)==0) &&
			(strcmp(cognome,d.cognome)==0) &&  (eta==d.eta) ) { 
			return true; 
		} else { 
			return false;        
		}
		// alternativa
		// return (strcmp(nome,d.nome)==0) && (strcmp(cognome,d.cognome)==0) && (eta==d.eta);
	}

}Tdati;

typedef struct Tnodo{
	Tdato dato; 
	Tnodo* next; 
	Tnodo() {   
		next = NULL;  
	}   
	Tnodo(Tdato x, Tnodo* n) {   
		dato = x; next = n;  
	}
	void stampa(){
		dato.stampa();   
	}
}Tnodo;



//typedef nodo  TipoNodo;
//typedef nodo* Nodoptr;
int length (Tnodo* s);
void stampa (Tnodo* s);
Tnodo* push (Tnodo* s, Tdato currdato);//insertFirst
Tnodo* pop (Tnodo* s);//removeFirst
Tdato read (Tnodo* s);//lettura elemento in testa
bool daticmp (Tdato d1, Tdato d2);//controlal se due elementi sono uguali

