#include <cstdlib>
#include <iostream>
#include "FIFO.h"
#include "tipo_dati.h"
using namespace std;

bool cerca(CodaPtr p, Tdato d){
	if(p->head==NULL){  //lista VUOTA
		return false;
	} 
	//scorro gli elementi
	Tnodo *s = p->head;
	do{
		//if (d.compare(s->data))
		//if (s->data.compare(d))
		if (daticmp(s->data,d)){ 
			return true; 
		}
		s=s->next;      
	}while(s!=NULL);
	return false;
}

bool daticmp(Tdato d1, Tdato d2){
	if( (strcmp(d1.nome,d2.nome)==0) && (strcmp(d1.cognome,d2.cognome)==0) && (d1.eta==d2.eta) ){ 
		return true; 
	}
	return false;
}

//sarebbe meglio controllare se la lista � vuota prima
//di richiamare la get
Tdato get(CodaPtr p){
	Tdato d; //dato inizializzato costruttore default
	if (p->head==NULL){//caso lista vuota 
		return d; 
	}
	d = p->head->data;
	if (p->head->next== NULL){
		//caso 1 solo elemento
		// deallocare elemento
		delete p->head;
		// lista vuota
		p->head=NULL;
		p->tail=NULL;
	}
	else{
		//lista con + elementi
		// deallocare elemento
		delete p->head;
		// aggiornare head
		p->head=p->head->next;
	}
	return d;
}

void put(CodaPtr p, Tdato d){
	Tnodo* q = new Tnodo(d, NULL);  //ultimo nodo dalla coda
	if (p->tail==NULL){ 
		//caso di lista vuota
		p->head = q; 
	}else{
		// tail != NULL
		// aggiorno l'attuale ultimo nodo
		p->tail->next = q; //collego ultimo nodo al nuovo nodo
	}
	p->tail = q;  //aggiorno sempre tail
}

void menu(CodaPtr p){
	int scelta;
	Tdato d;
	do{
		do{
			system("CLS");
			cout <<"1. leggi dato"<<endl; 
			cout <<"2. inserisci dato lista"<<endl;
			cout <<"3. ricerca dato"<<endl;      
			cout <<"4. stampa"<<endl;
			cout <<"5. estrai dati lista"<<endl;
			cout <<"6. FINE"<<endl;
			cin >> scelta;  
		} while( (scelta<1) || (scelta>6) ); 
		cout<<"=============="<<endl;
		switch (scelta)
		{
			case 1: {   
				fflush(stdin);
				cout <<"nome="; cin >> d.nome;
				cout <<"cognome="; cin >> d.cognome;
				cout <<"eta="; cin >> d.eta;
				break;
			} 
			case 2: { 
				put(p,d); 
				break;
			}
			case 3: {  
				cout <<"nome="; cin >> d.nome;
				cout <<"cognome="; cin >> d.cognome;
				cout <<"eta="; cin >> d.eta;
				if(cerca(p,d)==true)
				{ 	cout << "\nTrovato!!!";}
				else
				{ 	cout << "\nNon trovato!!!";}
				system("PAUSE");
				break;
			}
			case 4: { 
				p->stampa(); 
				system("PAUSE");  
				break;
			}
			case 5: { 
				d=get(p); 
				d.stampa(); 
				system("PAUSE"); 
				break;
			}                        
		}   
	}while (scelta!=6);
}

int casuale(int min ,int max){
	return rand()%(max-min+1)+min;
}
