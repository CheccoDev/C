/*
Chiedere all'utente la dimensione effettiva dall'array.
Inizializzare gli elementi utili l'array con valori tra 5 e 20.
Stampare:
- l'array (gli elementi utili)
- il valore minimo
- il valore massimo
- la media

Ricerca del minimo e del massimo tramite valori.
*/

#include <stdio.h>
#include <time.h>   // per rand
// direttiva define
#define LUNGHEZZA_MASSIMA 10
#define VALMAX 20
#define VALMIN 5

int main (int argc, const char * argv[]) {
	int a[LUNGHEZZA_MASSIMA];
	int lunghezza=0;
	int i;
	int min;
	int max;
	int avg;
	int sum;
	printf("Lunghezza vettore: ");
	scanf("%d",&lunghezza);
	// inizializza
	for(i=0 ; i<lunghezza ; i++){
		a[i] = rand()%(VALMAX-VALMIN+1)+VALMIN;
	}
	// stampa
	for(i=0 ; i<lunghezza; i++){
		printf("%d ",a[i]);
	}
	printf("\n");
	min=a[0];
	max=a[0];
	sum=0;
	for(i=0 ; i<lunghezza ; i++){
		if(a[i]<min){ min=a[i]; }
		if(a[i]>max){ max=a[i]; }
		sum=sum+a[i];  
	}
	printf("Minimo: %d\n", min);
	printf("Massimo:  %d\n", max);
	printf("Media: %f\n", (float)sum/lunghezza);  
    	
	//system("PAUSE"); 
    return 0;
}
