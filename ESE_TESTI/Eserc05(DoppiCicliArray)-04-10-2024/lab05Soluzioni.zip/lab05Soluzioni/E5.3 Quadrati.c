/* Chiedere all'utente la dimensione n e 
stampare le tabelle nxn con le seguenti strutture
(esempi con n=5)
x x x x x
x x x x x
x x x x x
x x x x x
x x x x x
------------------------
+ x x x +
o + x + x
o o + x x
o + o + x
+ o o o +
------------------------
x x x x x
x o o o x
x o o o x
x o o o x
x x x x x
*/
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]){
	int i, j, n;
	printf("inserire il numero N\n");
	scanf("%d", &n);
	
	i = 0;
	while (i < n){
		j = 0;
		while (j < n){
			printf("x ");
			j = j + 1;
		}
		printf("\n");
		i = i + 1;
	}
	printf("\n------------------------\n");
	
	i = 0;
	while (i < n){
		j = 0;
		while (j < n){
			if( i==j || i==n-1-j ){
				printf("+ ");
			}else{
				if( i>j ){
					printf("x ");
				}else{
					printf("o ");
				}
			}
			j = j + 1;
		}
		printf("\n");
		i = i + 1;
	}
	printf("\n------------------------\n");
	
	i = 0;
	while (i < n){
		j = 0;
		while (j < n){
			if( i==0 || j==0 || i==n-1 || j==n-1 ){
				printf("x ");
			}else{
				printf("o ");
			}
			j = j + 1;
		}
		printf("\n");
		i = i + 1;
	}		
	
	printf("\n------------------------\n");
	printf("\nfor\n------------------------\n");
	for (i=0 ; i<n ;i++){
		for ( j=0 ; j<n ; j++){
			printf("x ");
		}
		printf("\n");
	}
	printf("\n------------------------\n");
	
	for (i=0 ; i<n ;i++){
		for ( j=0 ; j<n ; j++){
			if( i==j || i==n-1-j) {
				printf("+ ");
			}else{
				if( i<j ){
					printf("x ");
				}else{
					printf("o ");
				}
			}
		}
		printf("\n");
	}
	printf("\n------------------------\n");
	
	for (i=0 ; i<n ;i++){
		for ( j=0 ; j<n ; j++){
			if( i==0 || j==0 || i==n-1 || j==n-1 ){
				printf("x ");
			}else{
				printf("o ");
			}
		}
		printf("\n");
	}
	//system("PAUSE");	
	return 0;
}

