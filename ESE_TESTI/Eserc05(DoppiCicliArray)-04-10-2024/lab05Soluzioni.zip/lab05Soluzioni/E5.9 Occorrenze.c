/*
Generi casualmente N=100 valori tra 0 e 20. Estremi inclusi. [0-20]
Calcolare le occorrenze per ognuno dei valori possibili [0-20].
Stampare le occorrenze per i valori [0-20].
Calcolare e stampare il valore minimo e massimo delle occorrenze.

Occorrenze: numero di volte che un valore e' stato generato.
*/
#include <stdio.h>
#include <time.h>   // per rand
// direttiva define
#define N 100
#define VALMAX 20

int main (int argc, const char * argv[]) {
	int occ[VALMAX+1]; // 21 elementi possibili: 0-20 estremi inclusi
	int i, imin, imax;
	// inizializza
	for(i=0 ; i<VALMAX+1 ; i++){
		occ[i] = 0;
	}
	// numeri casuali [0-20]
	for(i=0 ; i<N ; i++){
		occ[rand()%(VALMAX+1)]++;
	}
	// stampa occorrenze
	for(i=0 ; i<VALMAX+1; i++){
		printf("%d: %d\n",i, occ[i]);
	}
	printf("\n");
	
	// ricerca minimo e massimo
	imax=0;
	imin=0;
	for(i=0 ; i<VALMAX+1; i++){
		if( occ[i]<occ[imin] ) imin=i;
		if( occ[i]>occ[imax] ) imax=i;
	}
	printf("minima occorrenza: %d (%d)\n", imin, occ[imin]);
	printf("massima occorrenza: %d (%d)\n", imax, occ[imax]);
    	
	//system("PAUSE"); 
    return 0;
}
