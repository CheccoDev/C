/*
Esempi di inizializzazione di array
a) valori cheisti ad utente
b) valori casuali 
c) valori casuali in range
*/
#include <stdio.h>
#include <time.h>   // per rand
// direttiva define
#define LUNGHEZZA_MASSIMA 20

int main (int argc, const char * argv[]) {
	int a[LUNGHEZZA_MASSIMA];
	int lunghezza=0;
	int i=0;
	
	printf("Lunghezza vettore: ");
	scanf("%d",&lunghezza);
	// inizializza con interazione utente
	i=0;
	while(i<lunghezza){
		printf("Inserire numero: ");
		scanf("%d",&a[i]);
		i=i+1;  
	}
	// stampa
	i=0;
	while(i<lunghezza){
		printf("%d ",a[i]);
		i=i+1;        
	}
	printf("\n");
	
	// inizializzazione casuale
	printf("\n-----------------------------\n");
	printf("inizializzazione casuale\n\n");
	for(i=0 ; i<lunghezza; i++){
		a[i] = rand();
	}
	for(i=0 ; i<lunghezza; i++){
		printf("%d ", a[i]);
	}
	printf("\n");
	
	printf("\n-----------------------------\n");
	printf("inizializzazione casuale: 5 -- 20\n\n");
	for(i=0 ; i<lunghezza; i++){
		a[i] = rand()%(20-5+1)+5;
	}
	for(i=0 ; i<lunghezza; i++){
		printf("%d ", a[i]);
	}
	printf("\n");
	
	//system("PAUSE"); 
    return 0;
}
