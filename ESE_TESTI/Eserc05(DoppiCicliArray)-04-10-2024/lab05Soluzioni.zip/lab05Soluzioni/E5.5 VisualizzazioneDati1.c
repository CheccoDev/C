/*
Esempio di visualizzazione del contenuto di un array. 
*/
#include <stdio.h>
#include <stdlib.h>
// vettori

int main(int argc, char *argv[])
{
	//inizializzazione del vettore
	int v[4] = {5, 1, 0, 3};
	
	//indici di scorrimento
	int i,j;
	
	printf("\n------------------------\n");
	printf("array\n");
	// stampa contentuto array
	for(i = 0; i < 4; i++) {
		printf("%d ", v[i]);
	}
	printf("\n------------------------\n");
	printf("istogramma\n");
	// stampa istogrammi in orizzontale
	for(i = 0; i < 4; i++) {
		for(j = 0; j < v[i]; j++) 
	    { 
			printf("*");  
		}
	    printf("\n");
	}
	printf("\n");
	system("PAUSE");	
	return 0;
}
