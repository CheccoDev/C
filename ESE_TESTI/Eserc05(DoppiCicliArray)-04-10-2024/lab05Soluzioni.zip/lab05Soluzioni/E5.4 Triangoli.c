/* Chiedere all'utente la dimensione n (numero righe) e 
stampare le seguenti strtture
(esmepi con n=5)
*
* *
* * *
* * * *
* * * * *
------------------------
+ + + + +
+ + + +
+ + +
+ +
+
------------------------
0
1 1
2 2 2
3 3 3 3
4 4 4 4 4
------------------------
0
0 1
0 1 2
0 1 2 3
0 1 2 3 4
------------------------
+
+ +
+ o +
+ o o +
+ + + + +
------------------------
*
* *
* * *
* * * *
* * * * *
* * * *
* * *
* *
*
------------------------
        *
      * *
    * * *
  * * * *
* * * * *
*/
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]){
	int i, j, limite;
	printf("inserire il numero di righe\n");
	scanf("%d", &limite);

/*
+
+ +
+ + +
+ + + +
+ + + + +
*/	
	i = 0;
	while (i < limite){
		j = 0;
		while (j <= i){
			printf("* ");
			j = j + 1;
		}
		printf("\n");
		i = i + 1;
	}	
	
/*
	printf("\n------------------------\n");
	for (i=0 ; i<limite ; i++){
		for (j=0 ; j<=i ; j++){
			printf("* ");
		}
		printf("\n");
	}
*/
	
/*
+ + + + + 
+ + + + 
+ + + 
+ + 
+ 

*/
	printf("\n------------------------\n");
	i = 0;
	while (i < limite){
		j = 0;
		while (j < limite - i ){
			printf("+ ");
			j = j + 1;
		}
		printf("\n");
		i = i + 1;
	}
/*
	printf("\n------------------------\n");
	for (i=0 ; i<limite ; i++){
		for (j=0 ; j<limite-i ; j++){
			printf("* ");
		}
		printf("\n");
	}
*/

/*
0
1 1
2 2 2
3 3 3 3
*/
	printf("\n------------------------\n");
	for (i=0 ; i<limite ; i++){
		for (j=0 ; j<=i ; j++){
			printf("%d ", i);
		}
		printf("\n");
	}
	
/*
0
0 1
0 1 2
0 1 2 3
*/
	printf("\n------------------------\n");
	for (i=0 ; i<limite ; i++){
		for (j=0 ; j<=i ; j++){
			printf("%d ", j);
		}
		printf("\n");
	}

/*
+
+ +
+ o +
+ o o +
+ o o o +
+ + + + + +
*/	
	printf("\n------------------------\n");
	for (i=0 ; i<limite ; i++){
		for (j=0 ; j<=i ; j++){
			if( j==0 || i==limite-1 || i==j ){
				printf("%c ", '+');
			}else{
				printf("%c ", 'o');
			}	
		}
		printf("\n");
	}
/*
*
* *
* * * 
* *
*
*/
	printf("\n------------------------\n");
	for (i=0 ; i<limite ; i++){
		for (j=0 ; j<=i ; j++){
			printf("%c ", '*');	
		}
		printf("\n");
	}
	for (i=0 ; i<limite-1 ; i++){
		for (j=0 ; j<limite-1-i ; j++){
			printf("%c ", '*');	
		}
		printf("\n");
	}
	
/*
        *
      * *
    * * *
  * * * *
* * * * *
*/
	printf("\n------------------------\n");
	for (i=0 ; i<limite ; i++){
		for (j=0 ; j<limite-1-i ; j++){
			printf("  ");	
		}
		for (j=j ; j<limite ; j++){
			printf("* ");	
		}
		printf("\n");
	}
	
	//system("PAUSE");	
	return 0;
}

