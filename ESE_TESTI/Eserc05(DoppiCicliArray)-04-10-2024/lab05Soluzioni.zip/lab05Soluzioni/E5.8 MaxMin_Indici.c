/*
Chiedere all'utente la dimensione effettiva dall'array.
Inizializzare gli elementi utili l'array con valori tra 5 e 20.
Stampare:
- l'array (gli elementi utili)
- il valore minimo
- il valore massimo
- la media

Ricerca del minimo e del massimo tramite posizione/indice.
*/

#include <stdio.h>
#include <time.h>   // per rand
// direttiva define
#define LUNGHEZZA_MASSIMA 10
#define VALMAX 20
#define VALMIN 5

int main (int argc, const char * argv[]) {
	int a[LUNGHEZZA_MASSIMA];
	int lunghezza=0;
	int i;
	int imin;
	int imax;
	int avg;
	int sum;
	printf("Lunghezza vettore: ");
	scanf("%d",&lunghezza);
	// inizializza
	for(i=0 ; i<lunghezza ; i++){
		a[i] = rand()%(VALMAX-VALMIN+1)+VALMIN;
	}
	// stampa
	for(i=0 ; i<lunghezza; i++){
		printf("%d ",a[i]);
	}
	printf("\n");
	imin=0;
	imax=0;
	sum=0;
	for(i=0 ; i<lunghezza ; i++){
		if(a[i]<a[imin]){ imin=i; }
		if(a[i]>a[imax]){ imax=i; }
		sum=sum+a[i];  
	}
	printf("Minimo: %d\n", a[imin]);
	printf("Massimo:  %d\n", a[imax]);
	printf("Media: %f\n", (float)sum/lunghezza);  
    	
	//system("PAUSE"); 
    return 0;
}
