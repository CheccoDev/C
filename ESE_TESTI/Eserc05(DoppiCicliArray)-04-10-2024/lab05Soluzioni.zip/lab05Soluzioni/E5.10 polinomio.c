/*
Chiedere all'utente
- il grado di un polinomio
- i coefficienti per ogni grado (compreso grado 0)
Stampare i valori del polinomio calcolati nelle coordinate
x= -2.0, -1.5, -1, -0.5, 0, 0.5, 1.0, 1.5, 2.0, 2.5
Cercare i valori massimi e minimi del polinomio.
Stampare le coordinate di questi punti: (xmin, ymin) e (xmax, ymax)
*/
#include <stdio.h>
#include <math.h>
// direttiva define
#define MAX 10

int main (int argc, const char * argv[]) {
	float coeff[MAX+1];
	int grado, i, x;
	float y;
	printf("grado polinomio: ");
	scanf("%d", &grado);
	i=0;
	while(i<=grado){
		printf("coeff grado %d: ", i);
		scanf("%f", &coeff[i]);
		i++;
	}
	/*for(i=0 ; i<=grado; i++){
		printf("coeff grado %d", i);
		scanf("%f", &coeff[i]);
	}*/
	
	// stampa valori
	for(x=-20 ; x<=20 ; x=x+5){
		y = 0;
		for(i=0 ; i<=grado ; i++){
			y += coeff[i]*pow((x/10.0),i);  //coef(i)*x^i
		}
		printf("valore in x=%f: y= %f\n", x/10.0, y);
	}
		
	// stampa valori - alternativa
	float xf = -2.0;
	while(xf<=2.0){
		y = 0;
		for(i=0 ; i<=grado ; i++){
			y += coeff[i]*pow(xf,i);
		}
		printf("valore in x=%f: y= %f\n", xf, y);
		xf += 0.5;
	}
	
	// cerca min/max
	float xmax, ymax, xmin, ymin;
	xmax = -2.0;
	y = 0;
	for(i=0 ; i<=grado ; i++){
		y += coeff[i]*pow(xmax,i);;
	}
	ymax = y;
	xmin = xmax;
	ymin = ymax;
	for(x=-20 ; x<=20 ; x=x+5){
		y = 0;
		for(i=0 ; i<=grado ; i++){
			y += coeff[i]*pow((x/10.0),i);  //coef(i)*x^i
		}
		if(y>ymax){
			ymax = y;
			xmax = x/10.0;
		}
		if(y<ymin){
			ymin = y;
			xmin = x/10.0;
		}
	}
    printf("\nmassimo x=%f per x=%f\n", ymax, xmax);	
    printf("\nminimo  y=%f per x=%f\n", ymin, xmin);
    
    //system("PAUSE"); 
    return 0;
}
