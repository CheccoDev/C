#include <stdio.h>
#include <stdlib.h>

#define NR 25
#define NC 10
#define W 90

typedef struct {
	char c;
	float val;
}Telemento;

typedef Telemento Tdato[NR][NC];

int main (int argc, const char * argv[]) {
	Tdato mat;
	// analogo a  
	// Telemento mat[NR][NC];
    
	int i, j, num, imin, jmin, imax, jmax;
	float tot, media;
	char cerca;
	// inizializzazione con c --> '!'
	for (i=0 ; i<NR ; i++) {
		for (j=0 ; j<NC ; j++) {
			mat[i][j].c = '!';
		}
	}
	// inizializza causale di W elementi
	for (num=0; num<W; num++) {
		do {
			i = rand()%NR;
			j = rand()%NC;
		}while (mat[i][j].c != '!');
		mat[i][j].c = rand()%('x' - 'c' + 1) + 'c';
		// (rand()%(15*cost - (-10)*cost + 1 ) + (-10)*cost)/100.0
		mat[i][j].val = (rand()%(1500 + 1000 + 1 ) - 1000)/100.0;
	}
	
	/* 
	// ALTERNATIVA inizializza causale di W elementi
	num=0;
	while(num<W) {
  	i = rand()%NR;
		j = rand()%NC;
		if(mat[i][j].c != '!'){
		  mat[i][j].c = rand()%('x' - 'c' + 1) + 'c';
		  mat[i][j].val = (rand()%(1500 + 1000 + 1 ) - 1000)/100.0;
		  num++;
		}
	}
	*/
	
	// stampa
	for (i=0; i<NR; i++) {
		for (j=0; j<NC; j++) {
			if (mat[i][j].c == '!') {
				printf("# ");
			}else {
				printf("[%c %.2f] ", mat[i][j].c, mat[i][j].val);
			}
		}
		printf("\n");
	}
	
	// stampare somma dei valori associati a carattere car
	printf("\nInserisci carattere: ");
	scanf("%c", &cerca);
	tot = 0;
	// imin = 0;
	// jmin = 0;
	// imax = 0; 
	// jmax = 0;
	// cerca il primo elemento valido
	// non si puo' impostare come minimo e massimo 
	// la posizione [0][0]
	// visto che potrebbe essere un elemento NON valido
	// cioe' con carattere c == '!'
	int trovato = 0;
	for (i=0; i<NR && !trovato; i++) {
		for (j=0; j<NC && !trovato; j++) {
			if (mat[i][j].c != '!') {
				// ipotesi: il primo elemento valido e' il massimo
				// ipotesi: il primo elemento valido e' il minimo
				imin = i; jmin = j;
				imax = i; jmax = j;
				trovato = 1;
			}
		}
	}
	
	for (i=0; i<NR; i++) {
		media = 0;
		num = 0;
		for (j=0; j<NC; j++) {
			// somma degli elementi con c uguale a cerca
			if (mat[i][j].c == cerca) {
				tot += mat[i][j].val;
			}
			// minimo
			if (mat[i][j].c != '!' && mat[i][j].val < mat[imin][jmin].val) {
				imin = i;
				jmin = j;
			}
			// massimo
			if (mat[i][j].c != '!' && mat[i][j].val > mat[imax][jmax].val) {
				imax = i;
				jmax = j;
			}
			//media
			if (mat[i][j].c != '!') {
				media += mat[i][j].val;
				num++;
			}
			/*
			// alternativa
			if (mat[i][j].c != '!') {
				media += mat[i][j].val;
				num++;
				if (mat[i][j].c == cerca) {
					tot += mat[i][j].val;
				}
				if (mat[i][j].val < mat[imin][jmin].val) {
					imin = i;
					jmin = j;
				}
				if (mat[i][j].val > mat[imax][jmax].val) {
					imax = i;
					jmax = j;
				}
			}
			
			*/
		}
		if (num == 0) {
			printf("\nMedia per riga %d: --", i);
		}else {
			printf("\nMedia per riga %d: %f", i, media/num);
		}		
	}
	printf("\nSomma: %.4f", tot);
	printf("\nMinimo: %c %.2f in %d %d", mat[imin][jmin].c, mat[imin][jmin].val, imin, jmin);
	printf("\nMassimo: %c %.2f in %d %d", mat[imax][jmax].c, mat[imax][jmax].val, imax, jmax);
		
    return 0;
}
