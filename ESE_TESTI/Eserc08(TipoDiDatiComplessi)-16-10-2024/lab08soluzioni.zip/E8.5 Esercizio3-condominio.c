#include <stdio.h>
#include <stdlib.h>

#define MAX_PERSONE 6
#define MAX_VANI 5
#define MAX_PIANI 8
#define MAX_APPARTAMENTI 10
#define MAX_STR 30

typedef char Stringa[MAX_STR];

typedef struct {
	int gg, mm, aa;
}Tdata;

typedef struct {
	Stringa nome;
	Stringa cognome;
	Tdata data;
}Tpersona;

typedef struct {
	Stringa desc;
	float mq;
}Tvano;

typedef struct {
	Tpersona persone[MAX_PERSONE];
	Tvano vani[MAX_VANI];
	int n_persone;
	int n_vani;
}Tappartamento;

typedef struct {
	Stringa indirizzo;
	Stringa amministratore;
	Tappartamento appartamenti[MAX_PIANI][MAX_APPARTAMENTI];
	int n_piani;
	int n_app;
}Tcondominio;

int main (int argc, const char * argv[]) {
    Tcondominio condominio;
    int i, j, k, l, len;
	len=3;
	
	condominio.n_piani = rand()%(MAX_PIANI+2-1)+2;
	condominio.n_app = rand()%(MAX_APPARTAMENTI+2-1)+2;
	for(l=0 ; l<len ; l++){
		condominio.amministratore[l] = rand()%('z'-'a'+1)+'a';
		condominio.indirizzo[l] = rand()%('z'-'a'+1)+'a';
	}
	condominio.amministratore[len] = '\0';
	condominio.indirizzo[len] = '\0';
	for(i=0 ; i<condominio.n_piani ; i++){
		for(j=0 ; j<condominio.n_app ; j++){
			condominio.appartamenti[i][j].n_persone = rand()%(MAX_PERSONE-1+1)+1;
			condominio.appartamenti[i][j].n_vani = rand()%(MAX_VANI-3+1)+3;
			for(k=0 ; k<condominio.appartamenti[i][j].n_vani ; k++){
				condominio.appartamenti[i][j].vani[k].desc[0] = 'A'+k;
				condominio.appartamenti[i][j].vani[k].desc[1] = '\0';
				condominio.appartamenti[i][j].vani[k].mq = (rand()%(120*100 - 30*100 +1) +30*100)/100.0;
			}
			for(k=0 ; k<condominio.appartamenti[i][j].n_persone ; k++){
				for(l=0 ; l<len ; l++){
					condominio.appartamenti[i][j].persone[k].nome[l] = rand()%('z'-'a'+1)+'a';
					condominio.appartamenti[i][j].persone[k].cognome[l] = rand()%('z'-'a'+1)+'a';
				}
				condominio.appartamenti[i][j].persone[k].nome[l] = '\0';
				condominio.appartamenti[i][j].persone[k].cognome[l] = '\0';
				condominio.appartamenti[i][j].persone[k].data.gg = rand()%(31 - 1 +1) +1;
				condominio.appartamenti[i][j].persone[k].data.mm = rand()%(12 - 1 +1) +1;
				condominio.appartamenti[i][j].persone[k].data.aa = rand()%(2000 - 1940 +1) +1940;
			}
		}
	}
	
	/* stampa */
	condominio.n_piani = rand()%(MAX_PIANI+2-1)+2;
	condominio.n_app = rand()%(MAX_APPARTAMENTI+2-1)+2;
	for(l=0 ; l<len ; l++){
		condominio.amministratore[l] = rand()%('z'-'a'+1)+'a';
		condominio.indirizzo[l] = rand()%('z'-'a'+1)+'a';
	}
	printf("\n\nCONDOMINIO\n\n");
	printf("indirizzo: %s\n", condominio.indirizzo);
	printf("amministratore: %s\n", condominio.amministratore);
	printf("piani: %d\n", condominio.n_piani);
	printf("appartamento per piano: %d\n", condominio.n_app);
	
	for(i=0 ; i<condominio.n_piani ; i++){
		printf("\tpiano %d\n", i);
		for(j=0 ; j<condominio.n_app ; j++){
			printf("\t\tappartamento %d\n", i);
			printf("\t\t\tvani %d\n", condominio.appartamenti[i][j].n_vani);
			for(k=0 ; k<condominio.appartamenti[i][j].n_vani ; k++){
				printf("\t\t\t\t%s %.2f\n", condominio.appartamenti[i][j].vani[k].desc,condominio.appartamenti[i][j].vani[k].mq);
			}
			printf("\t\t\tpersone %d\n", condominio.appartamenti[i][j].n_persone);
			for(k=0 ; k<condominio.appartamenti[i][j].n_persone ; k++){
				printf("\t\t\t\t%s %s %d/%d/%d\n", condominio.appartamenti[i][j].persone[k].nome,
													condominio.appartamenti[i][j].persone[k].cognome,
													condominio.appartamenti[i][j].persone[k].data.gg,
													condominio.appartamenti[i][j].persone[k].data.mm,
													condominio.appartamenti[i][j].persone[k].data.aa);
			}
		}
	}
	
    return 0;
}
