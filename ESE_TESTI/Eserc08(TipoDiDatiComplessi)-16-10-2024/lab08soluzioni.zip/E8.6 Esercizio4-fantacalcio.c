#include <stdio.h>

/* PARAMETRI */
#define NUM_MAX_STR 50
#define NUM_SQUADRE 3

typedef char Stringa[NUM_MAX_STR];

typedef struct {
	Stringa  nome;
	Stringa  cognome;
	int      NCoppe;
} Tallenatore;

typedef struct {
	Stringa     nome;
	Stringa     colore;
	Tallenatore allenatore;
	int         punteggio;
} Tsquadra;

typedef Tsquadra Tfantacalcio[NUM_SQUADRE];

int main (int argc, const char * argv[]) {
	/* DICHIARAZIONE VARIABILI */
	Tfantacalcio fantacalcio;
	int NAllConCoppa;
	int i;
	
	/* INSERIMENTO DATI */
	for (i=0; i<NUM_SQUADRE; i++)
	{
/*
		printf("\n\t\t***************\n\t\t* FANTACALCIO *\n\t\t***************");
		printf("\n\n\t\t Squadra n %d\n",i+1);
		printf("\n Inserisci il nome della squadra: ");
		scanf("%s",fantacalcio[i].nome);
		printf("\n Inserisci il colore della casacca: ");
		scanf("%s",fantacalcio[i].colore);
		printf("\n Inserisci punteggio della squadra: ");
		scanf("%d", &fantacalcio[i].punteggio);
		printf("\n Inserisci il nome dell'allenatore : ");
		scanf("%s",fantacalcio[i].allenatore.nome);
		printf("\n Inserisci il cognome dell'allenatore : ");
		scanf("%s",fantacalcio[i].allenatore.cognome);
		printf("\n Inserisci il numero di coppe vinte dall'allenatore : ");
		scanf("%d", &fantacalcio[i].allenatore.NCoppe);
*/
		fantacalcio[i].nome[0] = rand()%('Z' - 'A' + 1) + 'A';
		fantacalcio[i].nome[1] = rand()%('z' - 'a' + 1) + 'a';
		fantacalcio[i].nome[2] = rand()%('z' - 'a' + 1) + 'a';
		fantacalcio[i].nome[3] = '\0';
		fantacalcio[i].colore[0] = rand()%('z' - 'a' + 1) + 'a';
		fantacalcio[i].colore[1] = rand()%('z' - 'a' + 1) + 'a';
		fantacalcio[i].colore[2] = '\0';
		fantacalcio[i].punteggio = rand()%(50 - 0 + 1) + 0;
		fantacalcio[i].allenatore.nome[0] = rand()%('Z' - 'A' + 1) + 'A';
		fantacalcio[i].allenatore.nome[1] = rand()%('z' - 'a' + 1) + 'a';
		fantacalcio[i].allenatore.nome[2] = rand()%('z' - 'a' + 1) + 'a';
		fantacalcio[i].allenatore.nome[3] = '\0';
		fantacalcio[i].allenatore.cognome[0] = rand()%('Z' - 'A' + 1) + 'A'; 
		fantacalcio[i].allenatore.cognome[1] = rand()%('z' - 'a' + 1) + 'a';
		fantacalcio[i].allenatore.cognome[2] = rand()%('z' - 'a' + 1) + 'a';
		fantacalcio[i].allenatore.cognome[3] = rand()%('z' - 'a' + 1) + 'a';
		fantacalcio[i].allenatore.cognome[4] = '\0';
		fantacalcio[i].allenatore.NCoppe = rand()%(16 - 0 + 1) + 0;
	}
	
	/* ANALISI DATI */
	NAllConCoppa=0;
	//clrscr();
	printf("\n\t\t**************\n\t\t* FANTACALCIO *\n\t\t**************");
	printf("\n\n Gli allenatori di squadre con punteggio maggiore di 30 punti sono: \n");
	for (i=0; i<NUM_SQUADRE; i++)
	{
		if (fantacalcio[i].punteggio > 30)
			printf("\n\t\t%s",fantacalcio[i].allenatore.cognome);
		if (fantacalcio[i].allenatore.NCoppe > 0) NAllConCoppa++;
	}
	printf("\n\n Il numero di allenatori che hanno vinto almeno una coppa sono : %d",NAllConCoppa);

    return 0;
}

