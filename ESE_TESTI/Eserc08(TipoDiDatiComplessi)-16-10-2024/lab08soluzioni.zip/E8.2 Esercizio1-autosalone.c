#include <stdio.h>

/* PARAMETRI */
#define MAX_STR 20
#define MAX_AUTO 30

typedef char Stringa[MAX_STR];

typedef struct {
	Stringa nome;
	Stringa cognome;
} Tacquirente;

typedef struct {
	Stringa marca;
	int cilindrata;
	int anno;
	Tacquirente acquirente;
} Tvettura;

typedef struct {
	Tvettura vetture[MAX_AUTO];
	int n_vetture;
} Tsalone;

int main (int argc, const char * argv[]) {
	/* DICHIARAZIONE VARIABILI */
	Tsalone salone;
	int auto_imm_2000, i_max_cilindrata;
	int i, k, len;
	
		/* richiesta a utente con controllo input */
	do {
		printf("\nQuante auto? ");
		scanf("%d", &salone.n_vetture);
	}while(salone.n_vetture<3 || salone.n_vetture>MAX_AUTO);
	
	/* INSERIMENTO DATI */
	/*
	for (i=0; i<salone.n_vetture; i++){
		printf("\n\t\t***************\n\t\t* AUTOSALONE *\n\t\t***************");
		printf("\n\n\t\t Vettura n %d\n",i+1);
		printf("\n Inserisci la marca della vettura: ");
		scanf("%s",salone.vetture[i].marca);
		printf("\n Inserisci la cilindrata: ");
		scanf("%d", &salone.vetture[i].cilindrata);
		printf("\n Inserisci l'anno di immatricolazione: ");
		scanf("%d", &salone.vetture[i].anno);
		printf("\n Inserisci il nome dell'acquirente : ");
		scanf("%s", salone.vetture[i].acquirente.nome);
		printf("\n Inserisci il cognome del pirlone : ");
		scanf("%s", salone.vetture[i].acquirente.cognome);
	}
	*/
	// Inizializzazione casuale
	len=3;
	for (i=0; i<salone.n_vetture; i++){
		for(k=0 ; k<len ; k++){
			salone.vetture[i].marca[k] = rand()%('z'-'a'+1)+'a';
			salone.vetture[i].acquirente.nome[k] = rand()%('z'-'a'+1)+'a';
			salone.vetture[i].acquirente.cognome[k] = rand()%('z'-'a'+1)+'a';
		}
		salone.vetture[i].marca[k] = '\0';
		salone.vetture[i].acquirente.nome[k] = '\0';
		salone.vetture[i].acquirente.cognome[k] = '\0';
		salone.vetture[i].cilindrata = rand()%(3000-1000+1)+1000;
		salone.vetture[i].anno = rand()%(2017-1990+1)+1990;
	}
	/* Stampa */
	for(i=0 ; i<salone.n_vetture ; i++){
		printf("\nVettura %d\n", i+1);
		printf("\tmarca:  %s\n", salone.vetture[i].marca);
		printf("\tacquirente: %s %s\n", salone.vetture[i].acquirente.nome, salone.vetture[i].acquirente.cognome);
		printf("\tcilindrata:  %d\n", salone.vetture[i].cilindrata);
		printf("\tanno:  %d\n", salone.vetture[i].anno);
	}
	
	/* ANALISI DATI */
	auto_imm_2000=0;
	i_max_cilindrata=0;
	printf("\n\n Gli acquirenti di auto di cilindrata maggiore a 1500 sono: \n");
	for (i=0 ; i<salone.n_vetture ; i++)
	{
		if (salone.vetture[i].cilindrata > 1500){ 
			printf("\n\t%s",salone.vetture[i].acquirente.cognome); 
		}
		if (salone.vetture[i].anno == 2000) { 
			auto_imm_2000++; 
		}
		if (salone.vetture[i].cilindrata > salone.vetture[i_max_cilindrata].cilindrata){
			i_max_cilindrata = i;
		}
	}
	printf("\n\n Il numero di vetture immatricolate nel 2000 e' : %d", auto_imm_2000);
	printf("\n\n Proprietario di vettura con massima cilindrata : %s", salone.vetture[i_max_cilindrata].acquirente.cognome);
	return 0;
}
