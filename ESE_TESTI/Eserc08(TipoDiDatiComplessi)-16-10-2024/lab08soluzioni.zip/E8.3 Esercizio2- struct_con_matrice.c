#include <stdio.h>
#include <stdlib.h>

#define NR 25
#define NC 10
#define W 90

typedef struct {
	char c;
	float val;
}Telemento;
typedef struct {
	Telemento m[NR][NC];
	// eventuali altri campi necessari
}Tdato;

int main (int argc, const char * argv[]) {
	Tdato mat;
    
	int i, j, num, imin, jmin, imax, jmax;
	float tot, media;
	char cerca;
	// inizializzazione con c --> '!'
	for (i=0 ; i<NR ; i++) {
		for (j=0 ; j<NC ; j++) {
			mat.m[i][j].c = '!';
		}
	}
	// inizializza causale di W elementi
	for (num=0; num<W; num++) {
		do {
			i = rand()%NR;
			j = rand()%NC;
		}while (mat.m[i][j].c != '!');
		mat.m[i][j].c = rand()%('x' - 'c' + 1) + 'c';
		// (rand()%(15*cost - (-10)*cost + 1 ) + (-10)*cost)/100.0
		mat.m[i][j].val = (rand()%(1500 + 1000 + 1 ) - 1000)/100.0;
	}
	
	// stampa
	for (i=0; i<NR; i++) {
		for (j=0; j<NC; j++) {
			if (mat.m[i][j].c == '!') {
				printf("# ");
			}else {
				printf("[%c %.2f] ", mat.m[i][j].c, mat.m[i][j].val);
			}
		}
		printf("\n");
	}
	
	// stampare somma dei valori associati a carattere car
	printf("\nInserisci carattere: ");
	scanf("%c", &cerca);
	tot = 0;
	// imin = 0;
	// jmin = 0;
	// imax = 0; 
	// jmax = 0;
	// cerca il primo elemento valido
	// non si puo' impostare come minimo e massimo 
	// la posizione [0][0]
	// visto che potrebbe essere un elemento NON valido
	// cioe' con carattere c == '!'
	int trovato = 0;
	for (i=0; i<NR && !trovato; i++) {
		for (j=0; j<NC && !trovato; j++) {
			if (mat.m[i][j].c != '!') {
				// ipotesi: il primo elemento valido e' il massimo
				// ipotesi: il primo elemento valido e' il minimo
				imin = i; jmin = j;
				imax = i; jmax = j;
				trovato = 1;
			}
		}
	}
	
	for (i=0; i<NR; i++) {
		media = 0;
		num = 0;
		for (j=0; j<NC; j++) {
			// somma degli elementi con c uguale a cerca
			if (mat.m[i][j].c == cerca) {
				tot += mat.m[i][j].val;
			}
			// minimo
			if (mat.m[i][j].c != '!' && mat.m[i][j].val < mat.m[imin][jmin].val) {
				imin = i;
				jmin = j;
			}
			// massimo
			if (mat.m[i][j].c != '!' && mat.m[i][j].val > mat.m[imax][jmax].val) {
				imax = i;
				jmax = j;
			}
			//media
			if (mat.m[i][j].c != '!') {
				media += mat.m[i][j].val;
				num++;
			}
			/*
			// alternativa
			if (mat.m[i][j].c != '!') {
				media += mat.m[i][j].val;
				num++;
				if (mat.m[i][j].c == cerca) {
					tot += mat.m[i][j].val;
				}
				if (mat.m[i][j].val < mat.m[imin][jmin].val) {
					imin = i;
					jmin = j;
				}
				if (mat.m[i][j].val > mat.m[imax][jmax].val) {
					imax = i;
					jmax = j;
				}
			}
			
			*/
		}
		if (num == 0) {
			printf("\nMedia per riga %d: --", i);
		}else {
			printf("\nMedia per riga %d: %f", i, media/num);
		}		
	}
	printf("\nSomma: %.4f", tot);
	printf("\nMinimo: %c %.2f in %d %d", mat.m[imin][jmin].c, mat.m[imin][jmin].val, imin, jmin);
	printf("\nMassimo: %c %.2f in %d %d", mat.m[imax][jmax].c, mat.m[imax][jmax].val, imax, jmax);
		
    return 0;
}
