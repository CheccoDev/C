#include <stdio.h>

#define MAX_S 20
#define N_GIOCATORI 30
#define N_PARTITE 10
#define N_SQUADRE 10

typedef char Stringa[MAX_S];

typedef struct{
	Stringa nome, cognome;
	int numero;      
} Tgiocatore;

typedef struct{
	Stringa nome;
	Tgiocatore giocatori[N_GIOCATORI];      
} Tsquadra;

typedef struct{
	int gg,mm,aa;
} Tdata;

typedef struct{
	int s1, s2;  // indice dell'array Squadre      
	Tdata datapartita;
	int numGiornata;  
	enum {andata, ritorno} girone;
	int g1,g2;      
} Tpartita;

typedef struct{
	Tpartita partite[N_PARTITE];
	enum {a, B, C1,C2,D,Eccellenza,Pulcini} serie;
} Tcampionato;

int main()
{
	Tcampionato serieA, serieB;
	Tsquadra squadre[N_SQUADRE];
	
	// Esempi di inizializzazione
	serieA.serie = a;
	serieA.partite[0].datapartita.gg = 10;
	serieA.partite[9].g1 = 3;
	printf("nome squadra: ");
	scanf("%s", squadre[8].nome);
	squadre[1].giocatori[0].numero = 11;
	
	// Esempi di stampa
	// potrebbero generare errori, dovuti a incompleta inizializzazione
	printf("Giocatore: %d %s", 
		   squadre[1].giocatori[0].numero, 
		   squadre[1].giocatori[0].cognome);
	
    switch (serieA.serie) {
		case a:
			printf("a");
			break;
		case B:
			printf("B");
			break;
		case C1:
			printf("C1");
			break;
		case C2:
			printf("C2");
			break;
		case D:
			printf("D");
			break;
		case Eccellenza:
			printf("Eccellenza");
			break;
		case Pulcini:
			printf("Pulcini");
			break;
	}
	
	printf("Squadra: %s", squadre[serieA.partite[3].s1].nome);
	
	system("PAUSE");
	return 0;
}
