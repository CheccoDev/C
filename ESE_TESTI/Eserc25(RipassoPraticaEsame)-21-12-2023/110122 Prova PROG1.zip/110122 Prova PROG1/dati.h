#ifndef __DATI_H__
#define __DATI_H__

#include <iostream>
#include <cstdlib>
#include <ctime>
#include <cstring>

#define DIM 3
typedef enum Tfrutto { MELA, PESCA, PERA } Tfrutto;

typedef struct Tproduzione {
	char piantagione[20]; 
	unsigned int numeroPiante;
	float quantita;
	Tfrutto tipoFrutto;
	Tproduzione ();
	Tproduzione(char _piantagione[], int _numeroPiante, float _quantita, Tfrutto _tipoFrutto);
	~Tproduzione();
	void stampa();
	void stampaSuFile(FILE *fp);
} Tproduzione;

typedef struct TipoCodaFIFO {
	int head, tail; //posizione inserimento, posizione prelevamento
	int dim; //numero elementi array==coda
	int n; //numero elementi presenti nella coda
	Tproduzione* s; // array dinamico circolare
	TipoCodaFIFO();
	TipoCodaFIFO(int _dim);
	int codaIsEmpty();
	int codaIsFull();
	void put(Tproduzione p);
	Tproduzione get();
	void stampa();
} TipoCodaFIFO;

void newProduzione(Tproduzione* p);
float casualeFloat(int min, int max);
int casuale(int min, int max);
void addProduzione(TipoCodaFIFO* produzioni[], int dim, Tproduzione p);
void stampaProduzioni(TipoCodaFIFO* produzioni[], int dim);
int estraiProduzioni(TipoCodaFIFO* produzioni[], int dim, Tfrutto tf);
#endif

