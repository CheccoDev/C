#include "dati.h"
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <cstring>

using namespace std;

Tproduzione::Tproduzione() {
	piantagione[0] = '\0';
	numeroPiante = 0;
	quantita = 0.0;
	tipoFrutto = MELA;
}

Tproduzione::Tproduzione(char _piantagione[], int _numeroPiante, float _quantita, Tfrutto _tipoFrutto) {
	strcpy(piantagione, _piantagione);
	numeroPiante = _numeroPiante;
	quantita = _quantita;
	tipoFrutto = _tipoFrutto;
}
Tproduzione::~Tproduzione(){

}
void Tproduzione::stampa() {
	cout << piantagione << " (";
	switch (tipoFrutto) {
		case MELA: cout << "MELA"; break;
		case PESCA: cout <<  "PESCA"; break;
		case PERA: cout << "PERA"; break;
		default: cout <<  "N/A"; break;
	}
	cout << ") " << quantita << " " << numeroPiante;
}
void Tproduzione::stampaSuFile(FILE *fp) {
	fprintf(fp, "%s (", piantagione);
	switch (tipoFrutto) {
		case MELA: fprintf(fp, "MELA"); break;
		case PESCA: fprintf(fp, "PESCA"); break;
		case PERA: fprintf(fp, "PERA"); break;
		default: fprintf(fp, "N/A"); break;
	}
	fprintf(fp, ") %f %d\n", quantita, numeroPiante);
}


TipoCodaFIFO::TipoCodaFIFO(){
	TipoCodaFIFO(1);
}
TipoCodaFIFO::TipoCodaFIFO(int _dim) {
	dim = _dim;
	n = 0;
	head=0;
	tail =0;
	s = new Tproduzione[dim];
}
int TipoCodaFIFO::codaIsEmpty() {
	return n==0;
}
int TipoCodaFIFO::codaIsFull() {
	return n==dim;
}
void TipoCodaFIFO::put(Tproduzione p) {
	s[head++] = p;
	n++;
	head = head%dim;
}
Tproduzione TipoCodaFIFO::get() {
	n--;
	Tproduzione t = s[tail++];
	tail = tail%dim;
	return t;
}
void TipoCodaFIFO::stampa() {
	if (n==0) 
		return;
	int i = tail;
	do{
		s[i].stampa();
		cout << endl;
		i = (++i)%dim;
	} while(i!=head);
	cout << endl;
}

void newProduzione(Tproduzione* p) {
	cout << "Inserisci il nome della piatagione" << endl;
	scanf("%s", p->piantagione);
	fflush(stdin);
	
	cout << "Inserisci il numero di piante della piantagione" << endl;
	scanf("%d", &p->numeroPiante);
	fflush(stdin);
	while (p->numeroPiante < 1000 || p->numeroPiante > 9999) {
		cout << "Errore: Inserisci il numero di piante della piantagione" << endl;
		cin >> p->numeroPiante;
		fflush(stdin);
	}
	p->quantita = casualeFloat(100, 2000);
	p->tipoFrutto = (Tfrutto) casuale(0,2);
}

float casualeFloat(int min, int max) {
	return ((rand()%(max*100-min*100+1)+(min*100))/100.0);
}
int casuale(int min, int max) {
	return rand()%(max-min+1)+min;
}
void addProduzione(TipoCodaFIFO* produzioni[], int dim, Tproduzione p) {
	int coda = casuale(0, DIM-1);
	if (!produzioni[coda]->codaIsFull()) {
		produzioni[coda]->put(p);
	} else {
		FILE *fp;
		fp = fopen("noProd.txt", "a");
		if (fp != NULL) {
			p.stampaSuFile(fp);
		} else {
			cout << "Impossibile aprire il file" << endl;
		} 
	}
}

void stampaProduzioni(TipoCodaFIFO* produzioni[], int dim) {
	int i;
	for (i =0; i < dim; i++) {
		cout << "--PRODUZIONE " << i << "-------------" << endl;
		produzioni[i]->stampa();
		cout << " ----------------------- " << endl;
	}
}

int estraiProduzioni(TipoCodaFIFO* produzioni[], int dim, Tfrutto tf) {
	int counter = 0;
	int i =0;
	Tproduzione tmp;
	for (i=0; i < dim; i++) {
		while (!produzioni[i]->codaIsEmpty()) {
			tmp = produzioni[i]->get();
			if (tmp.tipoFrutto == tf) {
				counter++;
			}
		}
	}
	return counter;
}
