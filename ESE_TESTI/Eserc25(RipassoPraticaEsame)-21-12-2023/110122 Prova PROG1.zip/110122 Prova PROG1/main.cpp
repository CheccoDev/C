#include <iostream>
#include <cstdlib>
#include <ctime>
#include "dati.h"

using namespace std;

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char** argv) {
	srand(time(0));
	TipoCodaFIFO* pf[DIM];
	Tproduzione p;
	
	for (int i = 0; i< DIM; i++) {
		pf[i] = new TipoCodaFIFO(3);
	}

	for(int i=0; i<6; i++) { 
		newProduzione(&p); 
		addProduzione(pf, DIM, p); 
	}
	stampaProduzioni(pf, DIM);
	estraiProduzioni(pf, DIM, MELA);

	return 0;
}
