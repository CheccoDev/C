#include "dati.h"
#include <iostream>
#include <cstdlib>
#include <string.h>

using namespace std;

Tnave::Tnave() {
	nomeNave[0] = '\0'; 
	annoVaro = 0;
	stazza = 0.0;
	tipoBattello = ALISCAFO;
}

Tnave::Tnave(char _nomeNave[], unsigned int _annoVaro, float _stazza, Tbattello _tipoBattello) {
	strcpy(nomeNave, _nomeNave);
	annoVaro = _annoVaro;
	stazza = _stazza;
	tipoBattello = _tipoBattello;
}

void Tnave::stampa() {
	cout << nomeNave << " " ;
	switch (tipoBattello) {
		case ALISCAFO: cout << "(ALISCAFO) "; break;
		case CROCIERA: cout << "(CROCIERA) "; break;
		case TRAGHETTO: cout << "(TRAGHETTO) "; break;
		default: cout << "(N/A) "; break;
	}
	printf("%.2f", stazza);
	cout << " TON anno varo=" << annoVaro; 
}

Tnodo::Tnodo (Tnodo *n, Tnodo *p, Tnave _nave) {
	nave = _nave;
	next = n;
	prev = p;
}
Tnodo::Tnodo() {
	next = NULL;
	prev = NULL;
}
void Tnodo::stampa() {
	nave.stampa();
	cout << endl;
	Tnodo* tmp = next;
	while (tmp != NULL) {
		tmp->nave.stampa();
		cout << endl;
		tmp = tmp->next;
	}
}

int random(int min, int max) {
	return rand()%(max-min+1)+min;
}

void newNave(Tnave* n) {
	switch (rand()%3) {
		case 0: n->tipoBattello = ALISCAFO; break;
		case 1: n->tipoBattello = CROCIERA; break;
		case 2:
		default: n->tipoBattello = TRAGHETTO;
	}
	//n->tipoBattello = (Tbattello) random((int) ALISCAFO, (int)TRAGHETTO);
	cout << "inserisci il nome " << endl;
	cin >> n->nomeNave;
	do {
		cout << "Inserisci anno";
		cin >> n->annoVaro;
		if (n->annoVaro < 1995 || n->annoVaro > 2022) {
			cout << "Errore" << endl;
		}
	} while (n->annoVaro < 1995 || n->annoVaro > 2022);
	n->stazza = (float) random(1500000, 5000000)/100;
}

Tnodo* insertLast(Tnodo* nodo, Tnave _nave) {
	Tnodo* inizio = nodo;
	if (inizio == NULL) {
		inizio = new Tnodo(NULL, NULL, _nave);
	} else {
		while (nodo->next != NULL) {
			nodo = nodo->next;
		}
		nodo->next = new Tnodo(NULL, nodo, _nave);
	}
	return inizio;
}

void addNave(Tnodo* por[], int dim, Tnave nave) {
	int x = rand()%dim;
	//int x = random(0, dim-1);
	por[x] = insertLast(por[x], nave);
}

void stampaPorti(Tnodo* por[], int dim) {
	for (int i=0; i<dim; i++) {
		cout << "LISTA " << i << endl;
		if (por[i] != NULL)
			por[i]->stampa();
		else
			cout << "Vuota" << endl;
	}
}

void rimuoviEContaNavi(Tnodo* por[], int dim) {
	int count = 0;
	FILE* file;
	file = fopen("navoi.txt", "w");
	if (file == NULL) {
		cout << "Error";
	} else {
		for (int i=0; i<dim; i++) {
			count = 0;
			while (por[i] != NULL) {
				count++;
				Tnodo* tmp = por[i];
				por[i] = por[i]->next;
				delete[] tmp;
			}
			fprintf(file, "CODA FIFO POS= %d NUMNAVI= %d\n", i, count);
		}
	}
	fclose(file);
}


