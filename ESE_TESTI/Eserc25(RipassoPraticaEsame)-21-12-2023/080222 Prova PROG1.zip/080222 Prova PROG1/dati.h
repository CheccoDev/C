#ifndef __DATI_H__
#define __DATI_H__

#include <iostream>
#include <cstdlib>

#define DIM 5

typedef enum Tbattello { ALISCAFO, CROCIERA, TRAGHETTO} Tbattello;
typedef struct Tnave {
	char nomeNave[20]; unsigned int annoVaro;
	float stazza;
	Tbattello tipoBattello;
	Tnave();
	Tnave(char _nomeNave[], unsigned int _annoVaro, float _stazza, Tbattello _tipoBattello);
	void stampa();
} Tnave;
typedef struct Tnodo {
	Tnave nave;
	Tnodo *next, *prev;
	Tnodo (Tnodo *n, Tnodo *p, Tnave _nave);
	Tnodo();
	void stampa();
} Tnodo;

void newNave(Tnave* n);
void addNave(Tnodo* por[], int dim, Tnave nave);
void stampaPorti(Tnodo* por[], int dim);
void rimuoviEContaNavi(Tnodo* por[], int dim);
#endif


