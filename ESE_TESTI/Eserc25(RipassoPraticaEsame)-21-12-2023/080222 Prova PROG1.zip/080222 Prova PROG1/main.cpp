#include <iostream>
#include <cstdlib>
#include <string.h>
#include <ctime>
#include "dati.h"

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char** argv) {
	Tnodo* porti[DIM];
	Tnave nave;

	srand(time(0));

	for (int i=0; i<DIM; i++) {
		porti[i] = NULL;
	}

	for (int i=0; i<5; i++) {
		newNave(&nave);
		addNave(porti, DIM, nave);
	}
	stampaPorti(porti, DIM);
	rimuoviEContaNavi(porti, DIM);
	return 0;
}
