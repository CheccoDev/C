#include <stdio.h>
#include <stdlib.h>

#define MAX 50
#define VAL_MIN 0
#define	VAL_MAX	99

typedef struct Tmatrice{
	int mat[MAX][MAX];
	int nr, nc;
}Tmatrice;

void init(int m[MAX][MAX], int nr, int nc);
void stampa(int m[MAX][MAX], int nr, int nc);
Tmatrice somma(Tmatrice a, Tmatrice b);
Tmatrice prod(Tmatrice a, Tmatrice b);
void stampa_v2(Tmatrice m);
int casuale(int min, int max);

int main (int argc, const char * argv[]) {
    int n;
	Tmatrice a, b, c;
	printf("Dimensione matrice: ");
	scanf("%d", &a.nr);
	while (a.nr<0 || a.nr>MAX) {
		printf("Errore.\nDimensione matrice <%d: ", MAX);
		scanf("%d", &a.nr);
	}
	a.nc = a.nr;
	b.nr = a.nr;
	b.nc = a.nr;
	init(a.mat, a.nr, a.nc);
	init(b.mat, b.nr, b.nc);
	printf("\nmatrice a\n");
	stampa_v2(a);
	printf("\nmatrice b\n");
	stampa_v2(b);
	c = somma(a, b);
	printf("\nmatrice somma\n");
	stampa_v2(c);
	c = prod(a, b);
	printf("\nmatrice prodotto\n");
	stampa_v2(c);
	
    return 0;
}

void init(int m[MAX][MAX], int nr, int nc){
	int i, j;
	for (i=0; i<nr; i++) {
		for (j=0; j<nc; j++) {
			m[i][j] = casuale(VAL_MIN, VAL_MAX);
		}
	}
}

void stampa(int m[MAX][MAX], int nr, int nc){
	int i, j;
	for (i=0; i<nr; i++) {
		for (j=0; j<nc; j++) {
			printf("%d ", m[i][j]);
		}
		printf("\n");
	}
}

Tmatrice somma(Tmatrice m1, Tmatrice m2){
	int i, j;
	Tmatrice ris;
	ris.nr = m1.nr;
	ris.nc = m1.nc;
	for (i=0; i<m1.nr; i++) {
		for (j=0; j<m1.nc; j++) {
			ris.mat[i][j] = m1.mat[i][j] + m2.mat[i][j];
		}
	}
	return ris;
}

Tmatrice prod(Tmatrice m1, Tmatrice m2){
	int i, j, k;
	Tmatrice ris;
	ris.nr = m1.nr;
	ris.nc = m1.nc;
	for (i=0; i<m1.nr; i++) {
		for (j=0; j<m1.nc; j++) {
			ris.mat[i][j] = 0;
			for (k=0; k<m1.nc; k++) {
				ris.mat[i][j] += m1.mat[i][k] * m2.mat[k][j];
			}
		}
	}
	return ris;
}

int casuale(int min, int max){
	return rand()%(max-min+1)+min;
}

void stampa_v2(Tmatrice m){
	int i, j;
	for (i=0; i<m.nr; i++) {
		for (j=0; j<m.nc; j++) {
			printf("%d ", m.mat[i][j]);
		}
		printf("\n");
	}
}
