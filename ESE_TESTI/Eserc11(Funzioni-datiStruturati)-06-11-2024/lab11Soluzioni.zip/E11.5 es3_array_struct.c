/*
Definire una struct Tpunto 
  typedef struct{ float x, y; }Tpunto;

Definire un array punti di MAX=100 elementi di tipo Tpunto
Chiedere all�utente il numero di punti da considerare
Popolare l�array con valori casuali di x e y compresi tra -5.00 e 5.00
  Funzione init + init_punto
Stampare l�array
  Funzione stampa + stampa_punto
Cercare il punto pi� vicino e pi� lontano dall�origine e stamparne a video le coordinate
  Funzione minimo e massimo


*/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define MAX 100

typedef struct Tpunto{
	float x, y;
}Tpunto;

typedef enum {FALSE, TRUE} Boolean;
/* Dichiarazioni (prototipi) delle funzioni */

/* Inizializzazione punti */
void init(Tpunto vett[], int dim);
/* Inizializzazione singolo punto */ 
Tpunto init_punto(float x, float y);
/* Stampa punti */
void stampa(const Tpunto vett[], int dim);
/* Stampa punto */
void stampa_punto(Tpunto p);
/* Restituisce indice di elemento minimo */  
int minimo(const Tpunto vett[], int dim);
/* Restituisce indice di elemento massimo */  
int massimo(const Tpunto vett[], int dim);
/* Genera numeri casuali tra i valori min e max */
int casuale(int min, int max);

int main (int argc, const char * argv[]) {
    Tpunto p;
    p = init_punto(casuale(-500, 500)/100.0, casuale(-500, 500)/100.0);
    stampa_punto(p);
    
	Tpunto punti[MAX];
    int imin, imax, dim;
	printf("dimensione: "); scanf("%d", &dim);
	/* popolo l'array con valori casuali e stampo */
	init(punti, dim);
	stampa(punti, dim);
	
	imin = minimo(punti, dim);
	imax = massimo(punti, dim);
	printf("\nminimo: ");
	stampa_punto(punti[imin]);
	printf("\nmassimo: ");
	stampa_punto(punti[imax]);
	printf("\n");
	
	return 0;
}

int casuale(int min, int max){
	return min+(rand()%(max-min+1));
}

Tpunto init_punto(float x, float y){
	Tpunto ris;
	ris.x = x;
	ris.y =y;
	return ris;
}
void init(Tpunto vett[], int dim){
	int i;
	for(i=0 ; i<dim ; i++){
		vett[i] = init_punto(casuale(-500, 500)/100.0, casuale(-500, 500)/100.0);
	}
}
void stampa_punto(Tpunto p){
	printf("%.2f %.2f %s\n", p.x, p.y, p.nome);
}
void stampa(const Tpunto vett[], int dim){
	int i;
	for(i=0 ; i<dim ; i++){
		stampa_punto(vett[i]);
		printf("\n");
	}
	printf("\n");
}

int minimo(const Tpunto vett[], int dim){
	int imin = 0; 
	float delta_min=sqrt(vett[0].x*vett[0].x + vett[0].y*vett[0].y );
	//float delta_min= vett[0].x*vett[0].x + vett[0].y*vett[0].y ;
	int i;
	float delta;
	for(i=0 ; i<dim ; i++){
		delta = sqrt(vett[i].x*vett[i].x + vett[i].y*vett[i].y );
		//delta = vett[i].x*vett[i].x + vett[i].y*vett[i].y ;
		if( delta<delta_min){
			delta_min = delta;
			imin = i;
		}
	}
	return imin;
}
int massimo(const Tpunto vett[], int dim){
	int imax = 0; 
	float delta_max = sqrt(vett[0].x*vett[0].x + vett[0].y*vett[0].y );
	//float delta_max = vett[0].x*vett[0].x + vett[0].y*vett[0].y ;
	int i;
	float delta;
	for(i=0 ; i<dim ; i++){
		delta = sqrt(vett[i].x*vett[i].x + vett[i].y*vett[i].y );
		//delta = vett[i].x*vett[i].x + vett[i].y*vett[i].y ;
		if( delta>delta_max){
			delta_max = delta;
			imax = i;
		}
	}
	return imax;
}

