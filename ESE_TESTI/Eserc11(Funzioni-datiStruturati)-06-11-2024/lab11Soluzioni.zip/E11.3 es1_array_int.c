/*
Definire una variabile vet1 array di N (100) interi
Chiedere all�utente quanti elementi sono da considerare (l) 
Inizializzare la variabile vet1 con valori casuali tra 1 e 10
  Definire ed usare funzione init
  Definire ed usare funzione casuale
Stampare la variabile vet1 
  Definire ed usare funzione stampa
*/

#include <stdio.h>
#include <stdlib.h>

#define N 20
#define VAL_MIN 0
#define VAL_MAX 10

/* Dichiarazioni (prototipi) delle funzioni */
/* Inizializzazione array */
void init(int v[], int dim);
/* Genera numeri casuali tra i valori min e max */
int casuale(int min, int max);
/* Stampa array (N elementi) */ 
void stampa(const int v[], int dim);


int main (int argc, const char * argv[]) {
    int vet[N];
	int dim;
	printf("Quanti numeri? ");
	scanf("%d", &dim);
	init(vet, dim);
	stampa(vet, dm);
		
	return 0;
}

/* Implementazioni delle funzioni */
/* Inizializzazione array */
void init(int v[], int dim){
	int i;
	for (i=0 ; i<dim ; i++) {
		v[i] = casuale(VAL_MIN, VAL_MAX);
	}
}

/* Genera numeri casuali tra i valori min e max */
int casuale(int min, int max){
	return rand()%(max-min+1)+min;
}

/* Stampa array (N elementi) */ 
void stampa(const int vett[], int dim){
	int i;
	for(i=0 ; i<dim ; i++){
		printf("%d ", vett[i]);
	}
	printf("\n");
}
