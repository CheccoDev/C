/*
Struttura della funzione main():
  dichiarazione variabili e matrici
  richiesta all�utente della dimensione delle matrici (n<MAX)
  (**) inizializzazione matrice A
  (**) inizializzazione matrice B
  (**) stampa matrice A
  (**) stampa matrice B
  (**) calcola e stampa somma: A + B
  (**) calcola e stampa prodotto: A * B

NB: (**) operazioni da eseguire tramite l�utilizzo di una funzione

*/
#include <stdio.h>
#include <stdlib.h>

#define MAX 50
#define VAL_MIN 0
#define	VAL_MAX	99

void init(int m[MAX][MAX], int dim);
void stampa(int m[MAX][MAX], int dim);
void stampa_somma(int m1[MAX][MAX], int m2[MAX][MAX], int dim);
void stampa_prod(int m1[MAX][MAX], int m2[MAX][MAX], int dim);
int casuale(int min, int max);

int main (int argc, const char * argv[]) {
    int n;
	int a[MAX][MAX], b[MAX][MAX];
	printf("Dimensione matrice: ");
	scanf("%d", &n);
	while (n<0 || n>MAX) {
		printf("Errore.\nDimensione matrice <%d: ", MAX);
		scanf("%d", &n);
	}
	init(a, n);
	init(b, n);
	printf("\nmatrice a\n");
	stampa(a, n);
	printf("\nmatrice b\n");
	stampa(b, n);
	
	stampa_somma(a, b, n);
	stampa_prod(a, b, n);
	
    return 0;
}

void init(int m[MAX][MAX], int dim){
	int i, j;
	for (i=0; i<dim; i++) {
		for (j=0; j<dim; j++) {
			m[i][j] = casuale(VAL_MIN, VAL_MAX);
		}
	}
}

void stampa(int m[MAX][MAX], int dim){
	int i, j;
	for (i=0; i<dim; i++) {
		for (j=0; j<dim; j++) {
			printf("%d ", m[i][j]);
		}
		printf("\n");
	}
}

void stampa_somma(int m1[MAX][MAX], int m2[MAX][MAX], int dim){
	int i, j;
	int ris[MAX][MAX];
	for (i=0; i<dim; i++) {
		for (j=0; j<dim; j++) {
			ris[i][j] = m1[i][j] + m2[i][j];
		}
	}
	printf("\nmatrice somma\n");
	stampa(ris, dim);
}

void stampa_prod(int m1[MAX][MAX], int m2[MAX][MAX], int dim){
	int i, j, k;
	int ris[MAX][MAX];
	for (i=0; i<dim; i++) {
		for (j=0; j<dim; j++) {
			ris[i][j] = 0;
			for (k=0; k<dim; k++) {
				ris[i][j] += m1[i][k] * m2[k][j];
			}
		}
	}
	printf("\nmatrice prodotto\n");
	stampa(ris, dim);
}

int casuale(int min, int max){
	return rand()%(max-min+1)+min;
}

