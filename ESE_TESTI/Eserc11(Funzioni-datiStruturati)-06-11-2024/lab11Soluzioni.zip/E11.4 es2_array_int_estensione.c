/*
Definire una variabile vet1 array di N (100) interi
Chiedere all�utente quanti elementi sono da considerare (l) 
Inizializzare la variabile vet1 con valori casuali tra 1 e 10
  Definire ed usare funzione init
  Definire ed usare funzione casuale
Stampare la variabile vet1 
  Definire ed usare funzione stampa
*/

#include <stdio.h>
#include <stdlib.h>

#define N 20
#define VAL_MIN 0
#define VAL_MAX 10

/* Dichiarazioni (prototipi) delle funzioni */
/* Inizializzazione array */
void init(int v[], int dim);
/* Genera numeri casuali tra i valori min e max */
int casuale(int min, int max);
/* Stampa array (N elementi) */ 
void stampa(const int v[], int dim);

/* Verifica se l'argomento numero e' primo. */ 
Boolean numero_primo(int numero);
/* Stampa i numeri primi presenti nel vettore */ 
void stampa_primi(const int vet[], int dim);

/* Cerca l'indice del massimo tra gli elementi dell�array */  
int cerca_imax(const int vet[], int dim);
/* Verifica se divisore divide dividendo */  
Boolean divisore(int divisore, int dividendo);
/* Stampa i numeri che sono divisori */ 
void stampa_divisori(const int vet[], int dim);

/* Restituisce il minimo tra i due argomenti */  
int minimo(int primo, int secondo);

/* Cerca il minimo tra gli elementi dell�array */  
int cerca_minimo(const int vet[], int dim);


int main (int argc, const char * argv[]) {
    int vet[N];
	int dim;
	printf("Quanti numeri? ");
	scanf("%d", &ldim;
	init(vet, dim);
	stampa(vet, dim);
		
	return 0;
}

/* Implementazioni delle funzioni */
void init(int v[], int dim){
	int i;
	for (i=0 ; i<dim ; i++) {
		v[i] = casuale(VAL_MIN, VAL_MAX);
	}
}

int casuale(int min, int max){
	return rand()%(max-min+1)+min;
}

void stampa(const int vett[], int dim){
	int i;
	for(i=0 ; i<dim ; i++){
		printf("%d ", vett[i]);
	}
	printf("\n");
}

int cerca_imax(const int vet[], int dim) {
	int i;
	int imax=0;
	for(i=1 ; i<dim ; i++) {
		if(vet[i]>vet[imax]){
			imax=i;
		}
	}
	return imax;
}

Boolean numero_primo(int numero){
	int div=2;
	if(numero!=1) {  
		while(!divisore(div,numero) && div<numero){
			div++;
		}
	} 
	if(div==numero) { return TRUE; } 
	else { return FALSE; }
	//  return (div==numero ? TRUE : FALSE);
	//  return (div==numero);
}
void stampa_primi(const int vet[], int dim){
	int i;
	for(i=0 ; i<dim ; i++){
		if(numero_primo(vet[i])){
			printf("%d ", vet[i]);
		}
	}
}
Boolean divisore(int divisore, int dividendo) {
	if((dividendo%divisore)==0) { return TRUE; }
	else { return FALSE; }
	//	return ((dividendo%divisore)==0);
	//	return !(dividendo%divisore);
}
void stampa_divisori(const int vet[], int dim){
	int i, j;
	int trovato = FALSE;
	for(i=0 ; i<dim ; i++){
		trovato = FALSE;
		for(j=0 ; j<dim && trovato==FALSE ; j++){
			if(i!=j && divisore(vet[i], vet[j])){
				printf("%d ", vet[i]);
				trovato = TRUE;
			}
		}
	}
}

int minimo(int primo, int secondo) {
	if(primo<=secondo) {return primo;}
	else {return secondo;}
    //	return (primo<=secondo ? primo : secondo);
}
int cerca_minimo(const int vet[], int dim) {
	int i;
	int min=vet[0];
	for(i=1 ; i<dim ; i++) {
		min=minimo(min, vet[i]);
	}
	return min;
}

