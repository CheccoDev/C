/*
Definire una variabile vet1 array di N (100) interi
Chiedere all�utente quanti elementi sono da considerare (l) 
Inizializzare la variabile vet1 usando con valori casuali tra 1 e 10
Stampare la variabile vet1

Soluzione senza funzioni
*/
#include <stdio.h>
#include <stdlib.h>

#define N 200
#define VAL_MIN 1
#define VAL_MAX 10

int main (int argc, const char * argv[]) {
    int vet[N]; 
	int i, dim;
	printf("Quanti numeri? "); scanf("%d", &l);
	
	for(i=0 ; i<dim ; i++){
		vet[i] = rand()%(VAL_MAX - VAL_MIN + 1) + VAL_MIN;
	}
	
	for(i=0 ; i<dim ; i++){
		printf("%d ", vet[i]);
	}
	printf("\n");

	return 0;
}
