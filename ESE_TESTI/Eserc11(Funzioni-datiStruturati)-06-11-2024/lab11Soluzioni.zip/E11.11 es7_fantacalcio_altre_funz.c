#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define NUM_SQUADRE 30
#define MAX_L 20

typedef char Stringa[MAX_L];
typedef struct  {
	Stringa nome;
	Stringa cognome;
	int NCoppe;
} Tallenatore;
typedef struct{
	Stringa nome;
	Stringa colore;
	int punteggio;
	Tallenatore allenatore;
}Tsquadra;

typedef Tsquadra Tfantacalcio[NUM_SQUADRE];

/* Inizializzazione struttura */
void popola(Tfantacalcio f, int dim);
/* Stampa la struttura */
void elabora(Tfantacalcio f, int dim);
/* Generazione numeri casuali */
int casuale(int min, int max);
/* Stampa */
void stampa(Tfantacalcio f, int dim);
/* Popola singolo alleantore */
Tallenatore popola_allenatore(Stringa nome, Stringa cognome, int coppe);
/* Popola singola squadra */
Tsquadra popola_squadra(Stringa nome, Stringa colore, int punti, Tallenatore all);
/* Stampa alleantore */
void stampa_allenatore(Tallenatore a);
/* Stampa squadra */
void stampa_squadra(Tsquadra s);
/* Generazione stringhe casuali - stringa memorizzata in str */
void str_casuale(char str[], int len);

int main (int argc, const char * argv[]) {
    Tfantacalcio fantacalcio;
	int n_squadre;
	
	printf("Quante squadre partecipano? (< %d)", NUM_SQUADRE); 
	scanf("%d", &n_squadre);
	// controllo input
	while (n_squadre<0 || n_squadre>30) {
		printf("Numero squadre errate. Quante squadre partecipano? (< %d)", NUM_SQUADRE);
		scanf("%d", &n_squadre);
	}
	
	popola(fantacalcio, n_squadre);
	stampa(fantacalcio, n_squadre);
	elabora(fantacalcio, n_squadre);
	
	getchar();
	return 0;
}

void popola(Tfantacalcio f, int dim){
	int i;
	Tallenatore a;
	Stringa s1, s2;
	printf("\n\t\t**********\n\t\t* FANTACALCIO *\n\t\t**********\n");
	for (i=0 ; i<dim ; i++){
		str_casuale(s1, 4);
		str_casuale(s2, 5);
		a = popola_allenatore( s1, s2, casuale(0, 15) );
		str_casuale(s1, 6);
		str_casuale(s2, 6);
		f[i] = popola_squadra( s1, s2, casuale(0, 70), a);
	}
}

void elabora(Tfantacalcio f, int dim) {
	/* ANALISI DATI */
	int NAllConCoppa=0;
	int i;
	printf("\n\t\t**********\n\t\t* FANTACALCIO *\n\t\t**********");
	printf("\nGli allenatori con punteggio maggiore di 30 punti sono: \n");
	for (i=0 ; i<dim ; i++){
		if (f[i].punteggio > 30)
			printf("\n\t\t%s",f[i].allenatore.cognome);
		if (f[i].allenatore.NCoppe > 0) 
			NAllConCoppa++;
	}
	printf("\n\n Il numero di allenatori che hanno vinto almeno una coppa sono : %d",NAllConCoppa);
}

int casuale(int valmin, int valmax){    
	return (rand() % (valmax -valmin+1))+valmin;
}

/* Stampa */
void stampa(Tfantacalcio f, int dim){
	int i;
	printf("\n\t\t******\n\t\t* FANTACALCIO *\n\t\t******");
	for (i=0; i<dim ; i++){
		printf("\n\n\t\t Squadra n: %d\n",i+1);
		stampa_squadra(f[i]);
	}
}
/* Popola singolo alleantore */
Tallenatore popola_allenatore(Stringa nome, Stringa cognome, int coppe){
	Tallenatore rit;
	strcpy(rit.nome, nome);
	/*
	int i=0;
	while(nome[i]){
		rit.nome[i]= nome[i];
		i++;
	}
	rit.nome[i]= nome[i]; // copia di end-of-string
	*/
	strcpy(rit.cognome, cognome);
	rit.NCoppe = coppe;
	return rit;
}
/* Popola singola squadra */
Tsquadra popola_squadra(Stringa nome, Stringa colore, int punti, Tallenatore all){
	Tsquadra rit;
	strcpy(rit.nome, nome);
	strcpy(rit.colore, colore);
	rit.punteggio = punti;
	rit.allenatore = all;
	return rit;
}
/* Stampa alleantore */
void stampa_allenatore(Tallenatore a){
	printf("\t%s %s %d", a.nome, a.cognome, a.NCoppe);
}
/* Stampa squadra */
void stampa_squadra(Tsquadra s){
	printf("%s %s %d", s.nome, s.colore, s.punteggio);
	printf("\n");
	stampa_allenatore(s.allenatore);
}
/* Generazione stringhe casuali - stringa memorizzata in str */
void str_casuale(char str[], int len){
	int i;
	for(i=0 ; i<len ; i++){
		str[i] = casuale('a', 'z');
	}
	str[len]='\0';
	// prima lettera maiuscola
	str[0]=str[0]-'a'+'A';
}
