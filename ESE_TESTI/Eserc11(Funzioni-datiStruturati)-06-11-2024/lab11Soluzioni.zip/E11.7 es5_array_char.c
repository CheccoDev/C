/*
Definire un programma che
  crea un array di MASSIMO 200 elementi (char)
  dimensione effettiva chiesta all�utente
  popola automaticamente l�array con valori compresi fra �a� e �z� in modo casuale 
  stampa a video
    l�array
    l�elemento di valore minimo nell�array 
    gli elementi che sono vocali
    l�elemento pi� ricorrente

*/
#include <stdio.h>
#include <stdlib.h>

#define LUNGHEZZA_ARRAY 200
#define VAL_MIN 'a'
#define VAL_MAX 'z'

typedef enum {FALSE, TRUE} Boolean;

/* Dichiarazioni (prototipi) delle funzioni */
/* Inizializzazione array */
void init(char vett[], int dim);
/* Stampa array */
void stampa(const char vett[], int dim);
/* Verifica se l'argomento numero e' una vocale. */ 
Boolean vocale(char c);
/* Restituisce il minimo tra i due argomenti */  
int minimo(int primo, int secondo);
/* Restituisce il minimo carattere */  
char cerca_minimo(const char vett[], int dim);
/* Genera numeri casuali tra i valori min e max */
int casuale(int min, int max);
/* Restituisce il carattere con massima freqeunza */
char max_occorrenza(const char vett[], int dim, char vmin, char vmax);

int main (int argc, const char * argv[]) {
    char array[LUNGHEZZA_ARRAY];
    int occ[VAL_MAX-VAL_MIN+1];
    
    char c_min;
	int i, j, dim, trovato;
	printf("dimensione: "); scanf("%d", &dim);
	
	/* popolo l'array con numeri casuali e stampo */
	init(array, dim);
	stampa(array, dim);
	
	/* Trovo il valore minimo dell'array e lo stampo */
	c_min = cerca_minimo(array, dim);
	
	/* stampo le vocali presenti */
	for(i=0 ; i<dim ; i++){                    
		if(vocale(array[i])==TRUE){
			printf("Vocale in %d: %c \n",i,array[i]);
		}
	}
	
	/* calcolo massima occorrenza */
	printf("Carattere piu' frequente: %c", max_occorrenza(array, dim, VAL_MIN, VAL_MAX));
	
	return 0;
}

void init(char vett[], int dim){
	int i;
	for(i=0 ; i<dim ; i++){
		vett[i] = casuale(VAL_MIN, VAL_MAX);
	}
}

void stampa(const char vett[], int dim){
	int i;
	for(i=0 ; i<dim ; i++){
		printf("%c ", vett[i]);
	}
	printf("\n");
}

Boolean vocale(char c){
	if (c=='a' || c=='e' || c=='i' || c=='o' || c=='u')
		return TRUE;
	else
		return FALSE;
	// return ( (c=='a' || c=='e' || c=='i' || c=='o' || c=='u') ? TRUE : FALSE)
	// return (c=='a' || c=='e' || c=='i' || c=='o' || c=='u');
}

int min(int primo, int secondo) {
	if(primo<=secondo) {return primo;}
	else {return secondo;}
    //	return (primo<=secondo ? primo : secondo);
}

char cerca_minimo(const char vett[], int dim){
	char cmin = vett[0];
	int i;
	for(i=0 ; i<dim ; i++){
		cmin = min(cmin, vett[i]);
	}
	return cmin;
}

int casuale(int min, int max){
	return min+(rand()%(max-min+1));
}

char max_occorrenza(const char vett[], int dim, char vmin, char vmax){
	int occ[vmax-vmin+1];
	int i, imax;
	// azzera occ
	for(i=0 ; i<vmax-vmin+1 ; i++) {   
		occ[i]=0;
	}
	// calcola occorrenze
	for(i=0 ; i<dim ; i++) {   
		occ[ vett[i]-vmin ]++;
	}
	// cerca massimo
	imax=0;
	for(i=1 ; i<vmax-vmin+1 ; i++) {
		if( occ[i]>occ[imax] ){
			imax=i;
		}
	}
	return imax+vmin;
}
