/*
Definire con typedef la struttura dati FANTACALCIO: 
una lista di squadre con i relativi allenatori.
L�allenatore � una persona caratterizzata da 
  nome (stringa)
  cognome (stringa)
  numero di coppe vinte (intero >=0)
La singola squadra � identificata dal 
  nome squadra (stringa)
  colore della casacca (stringa)
  punteggio corrente (intero >=0)
  l�allenatore. 
Calcolare e visualizzare il solo cognome 
degli allenatori di squadre che hanno pi� di 30 punti 
in classifica, nonch� il numero totale di allenatori 
che hanno vinto almeno una coppa.

*/
#include <stdio.h>
#include <stdlib.h>

#define NUM_SQUADRE 30
#define MAX_L 20

typedef char Stringa[MAX_L];
typedef struct  {
	Stringa nome;
	Stringa cognome;
	int NCoppe;
} Tallenatore;
typedef struct{
	Stringa nome;
	Stringa colore;
	int punteggio;
	Tallenatore allenatore;
}Tsquadra;

typedef Tsquadra Tfantacalcio[NUM_SQUADRE];

/* Inizializzazione struttura */
void popola(Tfantacalcio f, int dim);
/* Elabora la struttura e stampa informazioni */
void elabora(const Tfantacalcio f, int dim);
/* Generazione numeri casuali */
int casuale(int min, int max);
/* Stampa */
void stampa(const Tfantacalcio f, int dim);


int main (int argc, const char * argv[]) {
    Tfantacalcio fantacalcio;
	int n_squadre;
	
	printf("Quante squadre partecipano? (< %d)", NUM_SQUADRE); 
	scanf("%d", &n_squadre);
	// controllo input
	while (n_squadre<0 || n_squadre>30) {
		printf("Numero squadre errate. Quante squadre partecipano? (< %d)", NUM_SQUADRE);
		scanf("%d", &n_squadre);
	}
	
	// controllo input
	do {
		printf("Quante squadre partecipano? (< %d)", NUM_SQUADRE); 
		scanf("%d", &n_squadre);
		if(n_squadre<0 || n_squadre>30){
			printf("Numero squadre errate. < %d", NUM_SQUADRE);
		}
	}while (n_squadre<0 || n_squadre>30);
	
	popola(fantacalcio, n_squadre);
	stampa(fantacalcio, n_squadre);
	elabora(fantacalcio, n_squadre);
	
	getchar();
	return 0;
}

void popola(Tfantacalcio f, int dim){
	int i;
	
	printf("\n\t\t**********\n\t\t* FANTACALCIO *\n\t\t**********\n");
	for (i=0 ; i<dim ; i++){
		/*
		printf("\n\t\t**********\n\t\t* SQUADRA %d *\n\t\t**********\n", i+1);
		printf("nome squadra: ");
		scanf("%s", f[i].nome);
		printf("colore squadra: ");
		scanf("%s", f[i].colore);
		f[i].punteggio = casuale(0, 70);
		printf("nome allenatore: ");
		scanf("%s", f[i].allenatore.nome);
		printf("cognome allenatore: ");
		scanf("%s", f[i].allenatore.cognome);
		f[i].allenatore.NCoppe=casuale(0, 15);
		*/
		int k;
		for(k=0 ; k<3 ; k++){
			f[i].nome[k] = casuale('a', 'z');
			f[i].colore[k] = casuale('a', 'z');
			f[i].allenatore.nome[k] = casuale('a', 'z');
			f[i].allenatore.cognome[k] = casuale('a', 'z');
		}
		f[i].nome[k] = '\0';
		f[i].colore[k] = '\0';
		f[i].allenatore.nome[k] = '\0';
		f[i].allenatore.cognome[k] = '\0';
		f[i].punteggio = casuale(0, 70);
		f[i].allenatore.NCoppe = casuale(0, 15); 
	}
}

void elabora(const Tfantacalcio f, int dim) {
	/* ANALISI DATI */
	int NAllConCoppa=0;
	int i;
	printf("\n\t\t**********\n\t\t* FANTACALCIO *\n\t\t**********");
	printf("\nGli allenatori con punteggio maggiore di 30 punti sono: \n");
	for (i=0 ; i<dim ; i++){
		if (f[i].punteggio > 30)
			printf("\n\t\t%s",f[i].allenatore.cognome);
		if (f[i].allenatore.NCoppe > 0) 
			NAllConCoppa++;
	}
	printf("\n\n Il numero di allenatori che hanno vinto almeno una coppa sono : %d",NAllConCoppa);
}

int casuale(int valmin, int valmax){    
	return (rand() % (valmax -valmin+1))+valmin;
}

/* Stampa */
void stampa(const Tfantacalcio f, int dim){
	int i;
	printf("\n\t\t******\n\t\t* FANTACALCIO *\n\t\t******");
	for (i=0; i<dim ; i++){
		printf("\n\n\t\t Squadra n: %d\n",i+1);
		printf("%s %s %d\n", f[i].nome,
			   f[i].colore, 
			   f[i].punteggio);
		printf("\t%s %s %d\n", f[i].allenatore.nome, 
			   f[i].allenatore.cognome,
			   f[i].allenatore.NCoppe);
	}
}
