#include <stdio.h>
#include <stdlib.h>

#define MAX 50
#define VAL_MIN 0
#define	VAL_MAX	99

typedef struct Tmatrice{
	int mat[MAX][MAX];
	int nr, nc;
}Tmatrice;

void init(int m[MAX][MAX], int nr, int nc);
void stampa(int m[MAX][MAX], int nr, int nc);
void somma(int m1[MAX][MAX], int m2[MAX][MAX], int ris[MAX][MAX], int nr, int nc);
void prod(int m1[MAX][MAX], int m2[MAX][MAX], int ris[MAX][MAX], int nr, int nc);
int casuale(int min, int max);

int main (int argc, const char * argv[]) {
    int n;
	Tmatrice a, b, c;
	printf("Dimensione matrice: ");
	scanf("%d", &a.nr);
	while (a.nr<0 || a.nr>MAX) {
		printf("Errore.\nDimensione matrice <%d: ", MAX);
		scanf("%d", &a.nr);
	}
	a.nc = a.nr;
	b.nr = a.nr;
	b.nc = a.nr;
	init(a.mat, a.nr, a.nc);
	init(b.mat, b.nr, b.nc);
	printf("\nmatrice a\n");
	stampa(a.mat, a.nr, a.nc);
	printf("\nmatrice b\n");
	stampa(b.mat, b.nr, b.nc);
	c.nr = a.nr;
	c.nc = a.nr;
	somma(a.mat, b.mat, c.mat, a.nr, a.nc);
	printf("\nmatrice somma\n");
	stampa(c.mat, c.nr, c.nc);
	prod(a.mat, b.mat, c.mat, a.nr, a.nc);
	printf("\nmatrice prodotto\n");
	stampa(c.mat, c.nr, c.nc);
	
	stampa_v2(c);
    return 0;
}

void init(int m[MAX][MAX], int nr, int nc){
	int i, j;
	for (i=0; i<nr; i++) {
		for (j=0; j<nc; j++) {
			m[i][j] = casuale(VAL_MIN, VAL_MAX);
		}
	}
}

void stampa(int m[MAX][MAX], int nr, int nc){
	int i, j;
	for (i=0; i<nr; i++) {
		for (j=0; j<nc; j++) {
			printf("%d ", m[i][j]);
		}
		printf("\n");
	}
}

void somma(int m1[MAX][MAX], int m2[MAX][MAX], int ris[MAX][MAX], int nr, int nc){
	int i, j;
	for (i=0; i<nr; i++) {
		for (j=0; j<nc; j++) {
			ris[i][j] = m1[i][j] + m2[i][j];
		}
	}
}

void prod(int m1[MAX][MAX], int m2[MAX][MAX], int ris[MAX][MAX], int nr, int nc){
	int i, j, k;
	for (i=0; i<nr; i++) {
		for (j=0; j<nc; j++) {
			ris[i][j] = 0;
			for (k=0; k<nc; k++) {
				ris[i][j] += m1[i][k] * m2[k][j];
			}
		}
	}
}

int casuale(int min, int max){
	return rand()%(max-min+1)+min;
}

void stampa_v2(Tmatrice m){
	int i, j;
	for (i=0; i<m.nr; i++) {
		for (j=0; j<m.nc; j++) {
			printf("%d ", m.mat[i][j]);
		}
		printf("\n");
	}
}
