#include <stdio.h>
#include <stdlib.h>

#define MAX 50
#define VAL_MIN 0
#define	VAL_MAX	99

void init(int m[MAX][MAX], int nr, int nc);
void stampa(int m[MAX][MAX], int nr, int nc);
void somma(int m1[MAX][MAX], int m2[MAX][MAX], int ris[MAX][MAX], int nr, int nc);
void prod(int m1[MAX][MAX], int m2[MAX][MAX], int ris[MAX][MAX], int nr, int nc);
int casuale(int min, int max);

int main (int argc, const char * argv[]) {
    int n;
	int a[MAX][MAX], b[MAX][MAX], c[MAX][MAX];
	printf("Dimensione matrice: ");
	scanf("%d", &n);
	while (n<0 || n>MAX) {
		printf("Errore.\nDimensione matrice <%d: ", MAX);
		scanf("%d", &n);
	}
	init(a, n, n);
	init(b, n, n);
	printf("\nmatrice a\n");
	stampa(a, n, n);
	printf("\nmatrice b\n");
	stampa(b, n, n);
	somma(a, b, c, n, n);
	printf("\nmatrice somma\n");
	stampa(c, n, n);
	prod(a, b, c, n, n);
	printf("\nmatrice prodotto\n");
	stampa(c, n, n);
    return 0;
}

void init(int m[MAX][MAX], int nr, int nc){
	int i, j;
	for (i=0; i<nr; i++) {
		for (j=0; j<nc; j++) {
			m[i][j] = casuale(VAL_MIN, VAL_MAX);
		}
	}
}

void stampa(int m[MAX][MAX], int nr, int nc){
	int i, j;
	for (i=0; i<nr; i++) {
		for (j=0; j<nc; j++) {
			printf("%d ", m[i][j]);
		}
		printf("\n");
	}
}

void somma(int m1[MAX][MAX], int m2[MAX][MAX], int ris[MAX][MAX], int nr, int nc){
	int i, j;
	for (i=0; i<nr; i++) {
		for (j=0; j<nc; j++) {
			ris[i][j] = m1[i][j] + m2[i][j];
		}
	}
}

void prod(int m1[MAX][MAX], int m2[MAX][MAX], int ris[MAX][MAX], int nr, int nc){
	int i, j, k;
	for (i=0; i<nr; i++) {
		for (j=0; j<nc; j++) {
			ris[i][j] = 0;
			for (k=0; k<nc; k++) {
				ris[i][j] += m1[i][k] * m2[k][j];
			}
		}
	}
}

int casuale(int min, int max){
	return rand()%(max-min+1)+min;
}

