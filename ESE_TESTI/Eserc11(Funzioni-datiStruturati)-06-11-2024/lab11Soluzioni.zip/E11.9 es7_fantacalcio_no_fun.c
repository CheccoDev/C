/*
Definire con typedef la struttura dati FANTACALCIO: 
una lista di squadre con i relativi allenatori.
L�allenatore � una persona caratterizzata da 
  nome (stringa)
  cognome (stringa)
  numero di coppe vinte (intero >=0)
La singola squadra � identificata dal 
  nome squadra (stringa)
  colore della casacca (stringa)
  punteggio corrente (intero >=0)
  l�allenatore. 
Calcolare (con un ciclo) e visualizzare il solo cognome 
degli allenatori di squadre che hanno pi� di 30 punti 
in classifica, nonch� il numero totale di allenatori 
che hanno vinto almeno una coppa.

*/
#include <stdio.h>
#include <stdlib.h>

#define NUM_SQUADRE 30
#define MAX_L 20

typedef char Stringa[MAX_L];
typedef struct  {
	Stringa nome;
	Stringa cognome;
	int NCoppe;
} Tallenatore;
typedef struct{
	Stringa nome;
	Stringa colore;
	int punteggio;
	Tallenatore allenatore;
}Tsquadra;

typedef Tsquadra Tfantacalcio[NUM_SQUADRE];

int main (int argc, const char * argv[]) {
    Tfantacalcio fantacalcio;
	int NAllConCoppa, i, n_squadre;
	printf("Quante squadre partecipano? (< %d)", NUM_SQUADRE); 
	scanf("%d", &n_squadre);
	// controllo input
	while (n_squadre<0 || n_squadre>30) {
		printf("Numero squadre errate. Quante squadre partecipano? (< %d)", NUM_SQUADRE);
		scanf("%d", &n_squadre);
	}	
	printf("\n\t\t**********\n\t\t* FANTACALCIO *\n\t\t**********\n");
	/* INSERIMENTO DATI */
	for (i=0; i<n_squadre; i++){
		/*
		printf("nome squadra: ");
		scanf("%s", fantacalcio[i].nome);
		printf("colore squadra: ");
		scanf("%s", fantacalcio[i].colore);
		printf("punteggio squadra: ");
		scanf("%d", &fantacalcio[i].punteggio);
		printf("nome allenatore: ");
		scanf("%s", fantacalcio[i].allenatore.nome);
		printf("cognome allenatore: ");
		scanf("%s", fantacalcio[i].allenatore.cognome);
		printf("numero coppe allenatore: ");
		scanf("%d", &fantacalcio[i].allenatore.NCoppe);
		*/
		 int k;
		 for(k=0 ; k<3 ; k++){
			fantacalcio[i].nome[k] = rand()%('z'-'a'+1)+'a';
			fantacalcio[i].colore[k] = rand()%('z'-'a'+1)+'a';
			fantacalcio[i].allenatore.nome[k] = rand()%('z'-'a'+1)+'a';
			fantacalcio[i].allenatore.cognome[k] = rand()%('z'-'a'+1)+'a';
		 }
		 fantacalcio[i].nome[k] = '\0';
		 fantacalcio[i].colore[k] = '\0';
		 fantacalcio[i].allenatore.nome[k] = '\0';
		 fantacalcio[i].allenatore.cognome[k] = '\0';
		 fantacalcio[i].punteggio = rand()%(70 - 0 + 1) + 0;
		 fantacalcio[i].allenatore.NCoppe = rand()%(15 - 0 + 1) + 0;
	}
	/* VISUALIZZAZIONE DATI */
	printf("\n\t\t******\n\t\t* FANTACALCIO *\n\t\t******");
	for (i=0; i<n_squadre ; i++){
		printf("\n\n\t\t Squadra n: %d\n",i+1);
		printf("%s %s %d\n", fantacalcio[i].nome,
			   fantacalcio[i].colore, 
			   fantacalcio[i].punteggio);
		printf("\t%s %s %d\n", fantacalcio[i].allenatore.nome, 
			   fantacalcio[i].allenatore.cognome,
			   fantacalcio[i].allenatore.NCoppe);
	}
	NAllConCoppa=0;
	printf("\n\t\t******\n\t\t* FANTACALCIO *\n\t\t******");
	printf("\n\n Gli allenatori con punteggio > di 30 punti: \n");
	for (i=0; i<n_squadre; i++){
		if (fantacalcio[i].punteggio > 30)
			printf("\n\t\t%s",fantacalcio[i].allenatore.cognome);
		if (fantacalcio[i].allenatore.NCoppe > 0) 
			NAllConCoppa++;
	}	
	printf("\n\n Il numero di allenatori che hanno vinto almeno una coppa sono : %d",NAllConCoppa);

	return 0;
}
