#include <stdio.h>
#include <stdlib.h>
#define LUNGHEZZA_STRINGHE 30

/* Dichiarazioni (prototipi) delle funzioni */
/* La funzione lunghezza_stringa calcola la lunghezza di una stringa */ 
int lunghezza_stringa(char stringa[]);
/* La funzione min trova il minimo tra gli argomenti primo e secondo */ 
int min(int primo, int secondo);
/* La funzione confronta_stringhe trova l’ordine alfabetico di due stringhe */ 
/* 0: stringhe uguali
   1: stringa 1 precede
   2: stringa 2 precede
*/
int confronta_stringhe(char stringa1[],char stringa2[]);

int main (int argc, const char * argv[]) {
    char s1[LUNGHEZZA_STRINGHE];
	char s2[LUNGHEZZA_STRINGHE];  
	int status;
	printf("Inserire prima stringa: ");
	scanf("%s",s1);
	printf("Inserire seconda stringa: ");
	scanf("%s",s2);
	/* Chiamata della funzione confronta_stringhe */  
	status=confronta_stringhe(s1,s2);
	if(status==0){
		printf("Le stringhe sono uguali!\n");		
	} else{
		if(status==1){
			printf("%s - %s\n",s1,s2);
		} else {
			printf("%s - %s\n",s2,s1);
		}
	}

	return 0;
}

int lunghezza_stringa(char stringa[]) {
	int i=0;
	while(stringa[i]!='\0'){
		i++;                  
	}
	return i;         
}

int min(int primo, int secondo){
	if(primo<=secondo){
		return primo;
	}
	return secondo;
	/* return (primo<=secondo ? primo : secondo);*/
}

int confronta_stringhe(char stringa1[],char stringa2[])
{
	int l1, l2, lun, i;
	/* Chiamata della funzione lunghezza_stringa */  
	l1=lunghezza_stringa(stringa1);
	/* Chiamata della funzione lunghezza_stringa */  
	l2=lunghezza_stringa(stringa2);
	/* Chiamata della funzione min */  
	lun=min(l1,l2);
	i=0;
	while((i<lun)&&(stringa1[i]==stringa2[i])){
		i++;
	}
	/*
	i=0;
	while(stringa1[i]==stringa2[i] && stringa1[i]!='\0' && stringa1[i]!='\0'){
		i++;
	}
	*/
	if(stringa1[i]<stringa2[i]){
		return 1;
	}
	if(stringa1[i]>stringa2[i]){
		return 2;
	}
	return 0; 
}   
 
