#include <cstdlib>
#include <iostream>
#include "dlists.h"
using namespace std;

int random(int min, int max){
  return rand()%(max-min+1)+min;   
}

int main(int argc, char *argv[]) {
    int i;
	Tdato d;
	NodoPtr p=NULL; //lista vuota
	//serve per aver valori per la posizione univoci
	int pos[11]={0,0,0,0,0,0,0,0,0,0,0};
	int currPos;
	for(i=0; i<10; i++){
      do{        
        currPos=random(1,10);
      }while(pos[currPos]==1);
      pos[currPos]=1;
	  d.index = currPos;
	  d.value = random(-5, 5);
	  p=put(p,d);  //p=insertLast(p,d);
    }
    stampa(p);
    
    NodoPtr o=NULL;
    while(p!=NULL){
       d=readFirst(p); 
       p=get(p);  //p=removeFirst(p)
       o=insertOrder(o,d);            
    }
    stampa(o);
    
    Tdato dd(5, 2); //provare con index = 1, 5, 10, 22
    o=removeElem(o,dd); 
    stampa(o);
    
	o=removeCond(o); 
    stampa(o);
    

    system("PAUSE");
    return EXIT_SUCCESS;
}
