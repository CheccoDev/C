#include <cstdlib>
#include <iostream>
#include "dlists.h"
using namespace std;

NodoPtr removeLast(NodoPtr s){
  NodoPtr p = s;
  if (s==NULL) //lista vuota
  { return s; }
  if (s->next==NULL)  //1 solo elemento
  { delete s; return NULL;}
  while (s->next!=NULL){ //mi posiziono sull'ultimo elemento
   s=s->next; 
  }
  //mi posiziono sul penultimo elemento e lo faccio diventare l'ultimo
  s->prev->next=NULL;
  delete s; 
  return p;
}

NodoPtr removeFirst(NodoPtr s){
  NodoPtr p = s;
  if (s==NULL)  { return s; } //lista vuota
  if (s->next==NULL)  //1 solo elemento
  { delete s; return NULL;}   
  if (s!=NULL) {
    s = s->next;
    s->prev=NULL;  
    delete p;        
  } 
  return s;   
}

NodoPtr removeCond(NodoPtr s) {
	NodoPtr p = s;
	while (p!=NULL) {
	    if (p->dato.index % 2 ==0)
			removeElem(s, p->dato);
		p = p->next;    
	  }
	return s;
}

//in base al valore dell'indice della variaible d
NodoPtr removeElem(NodoPtr s, Tdato d){
	NodoPtr p = s;
	if (s==NULL)  { return s; } //lista vuota	
	if (s->next==NULL && s->dato.index == d.index ) { //1 solo elemento
		delete s; return NULL;
	}
	//delete 1� elemento ma lista con pi� elementi
	if (s->prev==NULL && s->dato.index == d.index ) { 
		s = s->next;
	    s->prev=NULL; 
		delete p; 
		return s;
	}	
	while (s!=NULL) { //scorro la lista
		if ( s->dato.index == d.index ) {
			s->prev->next = s->next; //il precedente punta al successivo
			//escludo caso limite ultimo elemento lista
			if (s->next != NULL) {
				s->next->prev = s->prev; //il successivo punta al precedente
			}
			delete s;
			return p;
		}
		s=s->next;
	}
	return p;
}
void stampa(NodoPtr s) {
  while (s!=NULL) {
    //cout <<"["<<s->dato.index<<","<<s->dato.value << "]";
    s->stampa();
    s= s->next;    
  }
  cout << endl;
}

NodoPtr insertOrder(NodoPtr s, Tdato d) {
 bool cond;
 NodoPtr p=s;  //salvo l'indirizzo iniziale 
 if ((s==NULL) || (s->dato.gt(d))) {
	s = insertFirst(s, d);  
	return s; 
 }
 //altrimenti mi fermo sull'elemento prima di cui inserire il dato
 do { 
  cond = true;
  if (s->next!=NULL) {
	//cond = s->next->dato.index<=CurrD.index; 
	cond = !( s->next->dato.gt(d) ); 
  }
  s=s->next;
  } while ((s!=NULL) && (cond)); 
  if (s==NULL){ //ultimo nodo
    p=insertLast(p,d); 
	return p;
  } 

 NodoPtr q = new Tnodo();//creo il nuovo nodo
 q->dato = d;
 q->prev = s->prev; //(s->prev)<-q
 q->next = s; //q->s
 s->prev->next = q; //(s->prev)->q
 s->prev = q;//q<-s
 
 return p;   
}

NodoPtr insertFirst(NodoPtr s, Tdato d){
 NodoPtr p=s;  //indirizzo iniziale 
 //NodoPtr q = new Nodo(d,NULL,s);
 NodoPtr q = new Tnodo();
 q->dato = d;
 q->prev = NULL;  // (1)perch� � il primo nodo
 q->next = s;     // (2)q->s  
 //se lista vuota s=NULL e q->next=NULL corretto
 if (s!=NULL)     //lista non vuota
 { s->prev=q; }   // (3)q<-s
 return q;     
}

NodoPtr insertLast(NodoPtr s,Tdato d){
 NodoPtr p=s;  //indirizzo iniziale
 NodoPtr q = new Tnodo(); //nodo da inserire
 q->dato = d; //q->dato.d = CurrD.d; 
 q->prev = NULL;  //si collega al nodo precedente
 q->next = NULL;  //ultimo nodo della lista  
 if (s!=NULL){
   while (s->next!=NULL)
     { s=s->next; }
   s->next = q;  //penultimo->ultimo
   q->prev = s;  //penultimo<-ultimo
 } else {
   p = q;  
 }
 return p;
}
NodoPtr put(NodoPtr s, Tdato d){
   return insertLast(s,d);     
}
NodoPtr get(NodoPtr s){
   return removeFirst(s);    
}
Tdato readFirst(NodoPtr s){
  return s->dato;   
}

int lung(NodoPtr s){
  int l=0;
  if (s==NULL)
  { return l; }
  do{
    l++;
    s=s->next;       
  }while(s!=NULL);  
  return l;       
}
