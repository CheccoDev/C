#ifndef DLISTS_H_
#define DLISTS_H_
#include <cstdlib>
#include <iostream>
using namespace std;

// the main structure
typedef struct Tdato {
    int index;
    float value;
    Tdato() { index=0; value=0; }  
    Tdato(int p, float c)  { index=p; value=c; }
    void stampa() const{
     cout << "["<<index<<":'"<<value<<"']"; 
	} 	
	bool gt(Tdato d){
	  if (index>d.index) {return true;}
	  return false;
	}
}Tdato;

typedef struct Tnodo {
	Tdato dato;
	Tnodo* prev;  
	Tnodo* next;
	Tnodo() {
		Tdato d; dato=d; prev=NULL; next=NULL; 
	}
	Tnodo(Tdato d, Tnodo* p, Tnodo* n) {
		dato=d; prev=p; next=n;
	}
	void stampa() const { dato.stampa(); }	
}Tnodo;

typedef Tnodo Nodo;
typedef Tnodo* NodoPtr;

// function prototypes
int lung(NodoPtr s);
NodoPtr insertLast(NodoPtr s,Tdato d);
NodoPtr insertFirst(NodoPtr s, Tdato d);
NodoPtr insertOrder(NodoPtr s, Tdato d);
void stampa(NodoPtr s);
NodoPtr removeFirst(NodoPtr s);
NodoPtr removeLast(NodoPtr s);
NodoPtr removeElem(NodoPtr s, Tdato d);
NodoPtr removeCond(NodoPtr s);
NodoPtr put(NodoPtr s, Tdato d);
NodoPtr get(NodoPtr s);
Tdato readFirst(NodoPtr s);
#endif 
/* DLISTS_H_ */
