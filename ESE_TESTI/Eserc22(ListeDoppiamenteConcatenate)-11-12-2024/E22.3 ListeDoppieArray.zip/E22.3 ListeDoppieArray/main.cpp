#include <cstdlib>
#include <iostream>
#include <time.h>
#include "dlists.h"
using namespace std;

int random(int min, int max){
  return rand()%(max-min+1)+min;   
}

int main(int argc, char *argv[]) {
	srand(time(0));
    int i;
	int azione;
	int lista;
	Tdato d;
	
	NodoPtr mieListe[3]; //array di puntatori a liste 
	mieListe[0] = NULL; //lista vuota
	mieListe[1] = NULL; //lista vuota
	mieListe[2] = NULL; //lista vuota

	NodoPtr cestino = NULL;

	for (i = 0; i<50; i++) {
		d.index = random(0, 100);
		d.value = random(-50, 50);
		azione = random(0,10);
		lista = random(0,2);
		if (azione%2 == 0) {
			mieListe[lista]=insertOrder(mieListe[lista], d);
		} else {
			if (mieListe[lista] != NULL) {
				d=readFirst(mieListe[lista]); 
		        mieListe[lista]=get(mieListe[lista]);  //p=removeFirst(p)
		        cestino=insertLast(cestino, d);       
			}  
		}
		cout << "-- iterazione " << i << "------------------------"; cout << endl;
		cout << "0: "; stampa(mieListe[0]);
		cout << "1: "; stampa(mieListe[1]);
		cout << "2: "; stampa(mieListe[2]);
		cout << "Cestino: "; stampa(cestino);
		cout << "--------------------------------------------------"; cout << endl;
	}

    system("PAUSE");
    return EXIT_SUCCESS;
}
