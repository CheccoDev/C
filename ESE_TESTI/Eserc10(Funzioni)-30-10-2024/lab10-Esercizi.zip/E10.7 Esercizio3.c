#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

#define MAX 100

typedef struct {
	float x, y;
}Tpunto;

/* Dichiarazioni (prototipi) delle funzioni */

/* Inizializzazione singolo punto */ 
Tpunto init_punto();
/* Stampa punto */
void stampa_punto(Tpunto p);
/* Genera numeri casuali tra i valori min e max */
float random(int min, int max);
/* calcola distanza tra punto p1 e p2 */
float distanza(Tpunto p1, Tpunto p2);


int main (int argc, const char * argv[]) {
  srand(time(0));
  Tpunto p1, p2;
  float d;
  //init con valori casuali tra [-2.0, +2.0]
  p1 = init_punto();
  p2 = init_punto();
  /*
    si pu� anche fare:
    p1.x = random(-20, 20)/10.0;
    p1.y = random(-20, 20)/10.0;
  */
  stampa_punto(p1); 
  stampa_punto(p2);
  d = distanza(p1, p2);
  printf("la distanza fra i punti e' pari a:%5.2f \n",d);    
  system("PAUSE");
  return 0;
}

float random(int min, int max){
  float ris;
  ris=(rand()%(max*100-min*100+1)+min*100)/100.0;
  return ris;
}

Tpunto init_punto(){
	Tpunto ris;
	ris.x = random(-20, 20)/10.0;
	ris.y = random(-20, 20)/10.0;
	return ris;
}

void stampa_punto(Tpunto p){
	printf("[%.2f, %.2f]\n", p.x, p.y);
}
float distanza(Tpunto p1, Tpunto p2){
  float dist;
  dist=sqrt( pow(p1.x-p2.x,2) + pow(p1.y-p2.y,2) );
  return dist;     
}


