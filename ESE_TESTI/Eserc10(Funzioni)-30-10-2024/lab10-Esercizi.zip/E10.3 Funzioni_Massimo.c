#include <stdio.h>
#include <stdlib.h>
#define valmin 1
int valmax=3; /*visibilit� globale a tutti 
sottoprogrammi e programma principale*/
int massimo;
int max(int a, int b);

int main(int argc, char *argv[])
{
  printf("(MAIN)Valore valmin e':%d\n",valmin);
  int a,b;
  printf("(MAIN)Valore valmax e':%d\n",valmax);
  a=5;
  b=7;
  massimo=max(a,b);
  printf("(MAIN)Valore valmax e':%d\n",valmax);
  printf("(MAIN)Valore massimo e':%d\n",massimo);
  system("PAUSE");	
  return 0;
}

int max(int a, int b)
{
#define valmin 0 /*dichiarazione di costante 
locale al sottoprogramma*/
printf("(F)Valore valmin e':%d\n",valmin);
int valmax; /*variabile locale, visibilit� solo 
all'interno del sottoprogramma*/
if (a>b)    
{valmax=a;}
else
{valmax=b;}
  printf("(F)Valore valmax e':%d\n",valmax);
return valmax;
} 
