#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define N 20
#define EPS 0.00001
typedef enum{FALSE, TRUE} Boolean;

float random(int min, int max);
float funz(float x);
void stampa(float x, float y);
Boolean valoreZero(float val);

int main(int argc, char *argv[]){
  float x,y;
  int i;
  srand(time(0));
  /*PRIMA PARTE*/
  for(i=0; i<N; ++i){
      x = (float)random(-500,+500)/100; 
      y = funz(x); 
      stampa(x,y);
      if (valoreZero(y)){
         printf("intercetta asse x\n");               
      }
  }
  printf("======================\n");
  /*SECONDA PARTE*/
  for (x=-5.0; x<=+5.0; x=x+0.2){
      y = funz(x); 
      stampa(x,y);
      if (valoreZero(y)){
         printf("intercetta asse x\n");               
      }     
  }
  system("PAUSE");  return 0;
}
Boolean numero_primo(int numero){
  int val;
  for(val=2;val<=numero/2; val++){
    if (numero%val==0) { return FALSE; }                        
  }
  return TRUE;
}
Boolean checkdivisore(int divisore, int dividendo){
  if(dividendo%divisore==0) { return TRUE; }  
  return FALSE;    
}
int minimo(int primo, int secondo){
  if(primo<secondo){ return primo; }
  return secondo;  
}
int random(int min, int max){
  return rand()%(max-min+1)+min;
}
float funz(float x){
   float y;
   y = x * pow(x-1,2);
   return y;      
}
void stampa(float x, float y){
   printf("[%5.2f,%5.2f]\n ",x,y);     
}
Boolean valoreZero(float val){
  if (val>0-EPS && val<0+EPS){
     return TRUE; 
  }
  return FALSE;     
}
