#include <stdio.h>
#include <stdlib.h>
typedef enum{FALSE, TRUE} Boolean;

int random(int min, int max);
int minimo(int primo, int secondo);
Boolean checkdivisore(int divisore, int dividendo);
Boolean numero_primo(int numero);

int main(int argc, char *argv[]){
  int val1, val2;
  srand(time(0));
  val1=random(2,6);  printf("%d\n",val1);
  val2=random(3,8);  printf("%d\n",val2);
  printf("minimo=%d \n",minimo(val1,val2));
  
  Boolean check;
  check=checkdivisore(2,4);

  if(check==TRUE) {
    printf("e' un divisore\n");                
  }else{
    printf("non e' un divisore\n");    
  }
  
  Boolean checkprimo;
  checkprimo=numero_primo(7);
  if(checkprimo==TRUE) {
    printf("e' un numero primo\n");                
  }else{
    printf("non e' un numero primo\n");    
  }
	int v=0;
	for (v=0; v<1000000000; v++) {
		numero_primo(v);
	}

  system("PAUSE");  return 0;
}
Boolean numero_primo(int numero){
  int val;
  for(val=2;val<=numero/2; val++){
    if (numero%val==0) { 
		return FALSE;
	}                        
  }
  return TRUE;
}
Boolean checkdivisore(int divisore, int dividendo){
  if(dividendo%divisore==0) { return TRUE; }  
  return FALSE;    
}
int minimo(int primo, int secondo){
  if(primo<secondo){ return primo; }
  return secondo;  
}
int random(int min, int max){
  int ris;
  ris=rand()%(max-min+1)+min;
  return ris;
}
