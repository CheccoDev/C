#include <stdio.h>
#include <stdlib.h>

//dichiarazione dell'header delle funzioni prima del main
//NOTARE il ; dopo l'header
void stampacapo();
void stampa(int a);
int somma(int p1, int p2);
float pigreco();
int random(int valmin, int valmax);

//programma principale (main di fatto � una funzione particolare)
int main(int argc, char *argv[])
{
    int a=7;
    stampa(5);
    stampa(a);
    printf("main %d\n",a);
    stampacapo();
    printf("somma=%d",somma(a,10));
    stampacapo();
    printf("pigreco=%f",pigreco());
	//utilizzo funzione random per variabile intera
	int valint;
	valint = random(-4,+10);	//valori tra -4 e +10
	printf("valore=%d\n",valint);
    //utilizzo funzione random per variabile char
	char valchar;
	valchar = random('a','z');	//valori tra 'a' e 'z'
	printf("valore=%c\n",valchar);	
	//utilizzo funzione random per variabile float
	int valfloat;
	valfloat = (float) random(10,100)/10;	//valori tra 1.0 e 10.0
	printf("valore=%f\n",valfloat);	
    
	system("PAUSE");    return EXIT_SUCCESS;
}

//costruzione della funzione ripetizione dell'header pi� il body della funzione
/*funzione*/
int random(int valmin, int valmax){    /*rand() genera un numero intero*/
    return (rand() % (valmax -valmin+1))+valmin;
}

void stampa(int a){
  a=a+1;   
  printf("%d",a); 
  stampacapo();  
}

void stampacapo(){
  printf("\n");
}   

int somma(int p1, int p2){
    return p1+p2;
}

float pigreco(){
   return 3.1415; 
}
