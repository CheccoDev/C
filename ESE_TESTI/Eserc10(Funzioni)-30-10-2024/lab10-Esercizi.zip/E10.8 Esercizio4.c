#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int fattoriale(int n) {
    if (n <= 1) {
		return 1;		// Caso Base
	}  else {
		return n * fattoriale(n - 1);  // Chiamata Ricorsiva
	}
}

int binomio(int n, int k)  {
	/*
	 C(n,k)= n! / (k! * (n-k)!)
	*/	
	int res;
	res = fattoriale(n)/( fattoriale(k) * fattoriale(n-k) );
	return res;
	
}
int main(int argc, char *argv[]){
	int n,k;
	printf("n="); scanf("%d",&n);
	printf("k="); scanf("%d",&k);
	//manca il controllo sul valore delle variabili
    printf("c(n,k)=%d \n",binomio(n,k));
     
  system("PAUSE");  return 0;
}
