#include <stdio.h>
#include <stdlib.h>
int power(int base, int n);

/*voglio calcolare 3x^2-2x+4 per x=3*/
int main(int argc, char *argv[])
{
    int x=3;
    int y;
    y=3*power(x,2)-2*power(x,1)+4*power(x,0);
    printf("%d",y);
    system("PAUSE");	
    return 0;
}

int power(int base, int n) {
	int i, p=1;
	for(i=1; i<=n; i++)
		p*=base; /*oppure p=p*base;*/
	return p;
}
