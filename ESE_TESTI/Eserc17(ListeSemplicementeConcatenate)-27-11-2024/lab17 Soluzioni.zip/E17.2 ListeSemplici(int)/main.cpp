#include <cstdlib>
#include <iostream>
#include "lista_int.h"
using namespace std;

int main(int argc, char *argv[])
{
     Nodo* x = new Nodo;
    x->dato = 13;
    x->next = NULL; 
    //Nodo* x;     x = NULL;
    Dato miodato;
    //miodato.d=15; x = insertLast(x,miodato);
    miodato = 15; 
	x= insertFirst(x,miodato);
    stampa(x);
    miodato=10; 
	x = insertLast(x,miodato);
    stampa(x);
    miodato=3;  
	x = insertFirst(x,miodato);
    stampa(x);
    x = removeLast(x);
    stampa(x);
    cout << "lung="<<lung(x)<<endl;
    
	system("PAUSE");
    return EXIT_SUCCESS;
}



