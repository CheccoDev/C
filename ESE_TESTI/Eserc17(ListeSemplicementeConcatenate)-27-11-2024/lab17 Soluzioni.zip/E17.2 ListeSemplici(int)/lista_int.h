#include <cstdlib>
#include <iostream>
using namespace std;

typedef int Tdato;

typedef struct Tnodo{
	Tdato dato; 
	Tnodo *next;
  
	Tnodo(){
  		next = NULL;
  	}
  	Tnodo(Tdato d){
  		dato = d;
  		next = NULL;
  	}
  	Tnodo(Tdato d, Tnodo* n){
  		dato = d;
		next = n;
  	}
};

typedef Tdato Dato;
typedef Tnodo Nodo;
typedef Tnodo* Nodoptr;

Nodoptr removeLast(Nodoptr s);
Nodoptr removeFirst(Nodoptr s);
void stampa(Nodoptr s);
Nodoptr insertFirst(Nodoptr s, Dato CurrD);
Nodoptr insertLast(Nodoptr s, Dato CurrD);
int lung(Nodoptr s);
