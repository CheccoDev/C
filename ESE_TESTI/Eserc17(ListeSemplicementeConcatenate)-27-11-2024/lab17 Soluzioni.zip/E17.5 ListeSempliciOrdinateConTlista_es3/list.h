#ifndef __LIST_H__
#define __LIST_H__

#include <cstdlib>
#include <iostream>
#include <cstring>

#define MAXL 20
#define EPS 0.001
using namespace std;

typedef struct Tdato{
	int index; 
	float value;	
	Tdato(){
		index=0; 
		value=0.0;
	}
	Tdato(int _index, float _value){
		index = _index; 
		value = _value;
	}
	bool gt(Tdato d){
    	if (value>d.value){ return true; }
    	return false;
		// return (value>d.value-EPS);
 	}
 	bool lt(Tdato d){
    	return (value<d.value+EPS);
 	}
 	bool eq(Tdato d){
    	return (value>d.value-EPS && value<d.value+EPS);
 	}
	void stampa(){
		cout << "[ " << index << "-" << value << " ] " ;
	}
}Tdato;

typedef struct Tnodo{
	Tdato dato; 
	Tnodo *next;
  
	Tnodo(){
  		next = NULL;
  	}
	Tnodo(Tdato d){
		dato = d;
 		next = NULL;
 	}
 	Tnodo(Tdato d, Tnodo* n){
 		dato = d;
  	next = n;
 	}
 	void stampa(){
 		dato.stampa();
	}
}Tnodo;

typedef struct Tlista{
	Tnodo* head;
	int id;
	char nome[MAXL];
	
	Tlista(){
		head=NULL;
	}
	Tlista(Tnodo* h){
		head = h;
	}
	Tlista(Tdato d){
		head = new Tnodo(d);
	}
	Tlista(Tnodo* h, int _id, char _n[]){
		head = h;
		id =_id;
		strcpy(nome, _n);
	}
	
	~Tlista(){
		Tnodo* toDel = NULL;
		while(head!=NULL){
			toDel = head;
			head = head->next;
			delete toDel;
		}
	}
	
	void stampa(){
		Tnodo* q = head;
		while(q!=NULL){
			q->stampa();
			q = q->next;
		}
	}
	void insert_first(Tdato d){
		head = new Tnodo(d, head);
	}
	void insert_last(Tdato d){
		if(head==NULL){
			head = new Tnodo(d, head);
			return;
		}
		Tnodo* q = head;
		while(q->next != NULL){
			q = q->next;
		}
		q = new Tnodo(d);
	}
	void remove_first(){
		if(head ==NULL){
			return;
		}
		Tnodo* t = head;
		head = head->next;
		delete head;
	}
	void remove_last(){
		if(head ==NULL){
			return;
		}
		Tnodo* q = head;
		while(q->next != NULL){
			q = q->next;			
		}
		delete q->next;
		q->next = NULL;
	}
	void insert_order(Tdato d){
		if ((head==NULL) || (head->dato.gt(d))) { 
			head = new Tnodo(d, head);  
			return; 
		}
		//ordine delle condizioni rilevante!!!!!
		Tnodo* q = head;
		while (q->next!=NULL && q->next->dato.lt(d)) { 
			q = q->next;  
		}
		q->next = new Tnodo(d, q->next);
	}
	void remove_cond(){
		Tnodo* toDel = NULL;
		while(head!=NULL && head->dato.index%2==0){
			toDel = head;
			head = head->next;
			delete toDel;
		}
		if(head==0){
			return;
		}
		Tnodo* q = head;
		while(q->next != NULL){
			if(q->next->dato.index%2==0){
				toDel = q->next;
				q->next = q->next->next;
				delete toDel;
			}else{
				q = q->next;
			}
		}
	}
	void search_remove(Tdato d){	
		// coda vuota
		if (head == NULL)
			return;
		//caso primo elemento       
		Tnodo* toDel = NULL;
	    while ( head!=NULL && head->dato.eq(d) ) {
	      	toDel = head;
	      	head = head->next;
	      	delete toDel;
	    }
	    if(head==NULL)
	    	return;
		Tnodo* q = head;
		while(q->next != NULL) {
	        while( q->next->dato.eq(d) ) {
	    		toDel = q->next;
	            q->next = q->next->next;
	            delete toDel; 
	        }
	        q=q->next;
	    }
	}
}Tlista;

typedef Tdato Dato;
typedef Tnodo Nodo;
typedef Tnodo* Nodoptr;

Nodoptr removeLast(Nodoptr s);
Nodoptr removeFirst(Nodoptr s);
void stampa(Nodoptr s);
Nodoptr insertFirst(Nodoptr s, Dato CurrD);
Nodoptr insertLast(Nodoptr s, Dato CurrD);
int lung(Nodoptr s);

Nodoptr insertOrder(Nodoptr s, Dato d);
Nodoptr searchRemove(Nodoptr s, Dato d);
Nodoptr searchRemoveDup(Nodoptr s, Dato d);
Nodoptr removeCond(Nodoptr s);

#endif
