#include <cstdlib>
#include <iostream>
#include "list.h"
using namespace std;
#define N 3
#define K 20
int main(int argc, char *argv[])
{
    Dato d;
    int i,pos;
    // dichiarazione
    //Nodoptr p[N];
    Tlista l[N];
    
    for(i=0; i<K; i++){ 
    	//d.index=rand()%(9-1+1)+1; 
    	//d.value=rand()%(30-1+1)+1; 
    	d = Dato( rand()%(9-1+1)+1, (rand()%(300-10+1)+10)/10.0 );
    	pos = rand()%(2-0+1)+0; 
    	l[pos].insert_order(d);      
    }
    for(i=0; i<N; i++){
		cout << i << endl; 
		l[i].stampa();
		cout <<endl; 
	}
    //rimozione di un elemento in particolare per esempio dalla lista 0
    cout <<endl<< "valore value dell'elemento da cancellare dalla lista [0]:";
    cin >>  d.value;
    l[0].search_remove(d); 
    l[0].stampa();
    //rimozione tutti elementi indice pari dalla lista 1
    cout <<endl<< "rimozione tutti elementi con valore indice pari dalla lista [1]"<<endl;
    l[1].remove_cond(); 
    l[1].stampa();
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
