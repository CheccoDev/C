#ifndef __LIST_H__
#define __LIST_H__

#include <cstdlib>
#include <iostream>

#define EPS 0.001
using namespace std;

typedef struct Tdato{
	int index; 
	float value;	
	Tdato(){
		index=0; 
		value=0.0;
	}
	Tdato(int _index, float _value){
		index = _index; 
		value = _value;
	}
	bool gt(Tdato d){
    	if (value>d.value){ return true; }
    	return false;
		// return (value>d.value-EPS);
 	}
 	bool lt(Tdato d){
    	return (value<d.value+EPS);
 	}
 	bool eq(Tdato d){
    	return (value>d.value-EPS && value<d.value+EPS);
 	}
	void stampa(){
		cout << "[ " << index << "-" << value << " ] " ;
	}
}Tdato;

typedef struct Tnodo{
	Tdato dato; 
	Tnodo *next;
  
	Tnodo(){
  		next = NULL;
  	}
	Tnodo(Tdato d){
		dato = d;
 		next = NULL;
 	}
 	Tnodo(Tdato d, Tnodo* n){
 		dato = d;
  	next = n;
 	}
 	void stampa(){
 		dato.stampa();
	}
}Tnodo;

typedef Tdato Dato;
typedef Tnodo Nodo;
typedef Tnodo* Nodoptr;

Nodoptr removeLast(Nodoptr s);
Nodoptr removeFirst(Nodoptr s);
void stampa(Nodoptr s);
Nodoptr insertFirst(Nodoptr s, Dato CurrD);
Nodoptr insertLast(Nodoptr s, Dato CurrD);
int lung(Nodoptr s);

Nodoptr insertOrder(Nodoptr s, Dato d);
Nodoptr searchRemove(Nodoptr s, Dato d);
Nodoptr searchRemoveDup(Nodoptr s, Dato d);
Nodoptr removeCond(Nodoptr s);

#endif
