#include <cstdlib>
#include <iostream>
#include "list.h"
using namespace std;

Nodoptr insertFirst(Nodoptr s, Dato currD){
	/*
	Nodoptr q = new Nodo();
	q->dato = currD;
	q->next = s; 
	return q;
	*/
	return new Nodo(currD, s);     
}

Nodoptr insertLast(Nodoptr s, Dato currD){
	if(s==NULL){
		// inserisce primo elemento
		/*
		Nodoptr q = new Nodo();
		q->dato = currD;

		q->next = s; 
		return q;
		*/
		return new Nodo(currD, NULL);
	}
	Nodoptr p = s;
	while (p->next!=NULL){ 
		p=p->next; 
	}
	p->next = new Nodo(currD, NULL);
	return s;
}
void stampa(Nodoptr s){
	Nodoptr p = s;
	while (p!=NULL){
		p->stampa();
		p = p->next;    
	}
	cout << endl;
}
int lung(Nodoptr s){
	int l=0;
	if (s==NULL){ 
		return l; 
	}
	Nodoptr p=s;
	do{
		l++;
		p=p->next;       
	}while(p!=NULL);  
	return l;       
}

Nodoptr removeFirst(Nodoptr s){
	Nodoptr n = s;
	if (s!=NULL){
		s= s->next;  
		delete n;        
	} 
	return s;
	/*
	if(s==NULL)
	  return NULL;
	Nodoptr p = s->next;
	delete s;
	return p;
	*/ 
}

Nodoptr removeLast(Nodoptr s){
	if (s==NULL){ 
		// nessun elemento in lista
		return NULL;
	}
	if (s->next==NULL){ 
		// 1 elemento in lista
		delete s; 
		return NULL;
	}
	Nodoptr p = s;
	while (p->next->next!=NULL){
		p=p->next;  
	} 
	delete p->next;
	p->next = NULL;
	return s;
}

//inserisce in ordine crescente per il campo value
Nodoptr insertOrder(Nodoptr s, Dato d){
	 
	if ((s==NULL) || (s->dato.gt(d))) { 
		s = insertFirst(s, d);  
		return s; 
		// return insertFirst(s, d);
	}
	//ordine delle condizioni rilevante!!!!!
	Nodoptr p=s;
	while (p->next!=NULL && p->next->dato.lt(d)) { 
		p=p->next;  
	}
	/*
	Nodoptr q = new Nodo();//creo il nuovo nodo
	q->dato = d;
	q->next = s->next; 
	p->next = q;
	*/
	p->next = new Nodo(d, p->next);
	return s;
}
//rimuove elemento che corrisponde al dato passato d
//attenzione che il campo value � di tipo float!!!!
// NO DUPLICATI
Nodoptr searchRemove(Nodoptr s, Dato d){
	  if (s != NULL) {
		// coda non vuota
    	Nodoptr q = s;
    	//caso primo elemento       
    	if ( q->dato.eq(d) ) {
	    	/*s = s->next;
	    	delete q; 
			return s;
			*/
			return removeFirst(s);
      	}else {
        	while(q->next != NULL) {
          		if( q->next->dato.eq(d) ) {
            		Nodoptr r = q->next;
		            q->next = q->next->next;
		            delete r;  
					return s; 
		        }
	        	q=q->next;
        	}
      	}
    }
    return s;
	/*
	// coda vuota
	if (s == NULL)
		return NULL;
	//caso primo elemento       
    if ( s->dato.eq(d) ) {
      	return removeFirst(s);
    }
    
	Nodoptr q = s;
	while(q->next != NULL) {
        if( q->next->dato.eq(d) ) {
    		Nodoptr r = q->next;
            q->next = q->next->next;
            delete r;  
			return s; 
        }
        q=q->next;
    }
    return s;
	*/   
}
// CON DUPLICATI
Nodoptr searchRemoveDup(Nodoptr s, Dato d){
	// coda vuota
	if (s == NULL)
		return s;
	//caso primo elemento       
    while ( s!=NULL && s->dato.eq(d) ) {
      	s = removeFirst(s);
    }
    if(s==NULL)
    	return s;
    
	Nodoptr q = s;
	while(q->next != NULL) {
        while( q->next->dato.eq(d) ) {
    		Nodoptr r = q->next;
            q->next = q->next->next;
            delete r; 
        }
        q=q->next;
    }
    return s;   
}
//rimuove tutti gli elementi in cui il campo index contiene un valore pari
Nodoptr removeCond(Nodoptr s){
	if (s==NULL)
		return s; 
	
	Nodoptr q = s; 
	Nodoptr todel;
	//caso primo elemento 
	while (q->dato.index%2==0) {
		s = s->next;
		delete q;
		//caso di lista vuota (in seguito a cancellazione...)
		if (s==NULL)
			return s;
		q = s;
	}
	while(q->next != NULL){
		//rimuovo elementi con indice pari  
		if (q->next->dato.index%2==0){
			todel = q->next; //memorizzo elemento da cancellare
			q->next = q->next->next; 
			delete todel;                   
		} else {
			q=q->next; 
		}  
	}
	return s;     
}




