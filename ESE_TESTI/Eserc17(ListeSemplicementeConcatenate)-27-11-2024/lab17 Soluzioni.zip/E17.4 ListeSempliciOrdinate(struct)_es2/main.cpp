#include <cstdlib>
#include <iostream>
#include "list.h"
using namespace std;
#define N 3
#define K 20
int main(int argc, char *argv[])
{
    Dato d;
    int i,pos;
    // dichiarazione
    Nodoptr p[N];
    // inizializzazione
    for(i=0; i<N; i++){ 
		p[i]=NULL; 
	}
    for(i=0; i<K; i++){ 
    	//d.index=rand()%(9-1+1)+1; 
    	//d.value=rand()%(30-1+1)+1; 
    	d = Dato( rand()%(9-1+1)+1, (rand()%(300-10+1)+10)/10.0 );
    	pos =rand()%(2-0+1)+0; 
    	p[pos]= insertOrder(p[pos],d);      
    }
    for(i=0; i<N; i++){ 
		stampa(p[i]); 
	}
    //rimozione di un elemento in particolare per esempio dalla lista 0
    cout <<endl<< "valore value dell'elemento da cancellare dalla lista p[0]:";
    cin >>  d.value;
    p[0]= searchRemove(p[0],d); 
    stampa(p[0]);
    //rimozione tutti elementi indice pari dalla lista 1
    cout <<endl<< "rimozione tutti elementi con valore indice pari dalla lista p[1]"<<endl;
    p[1]= removeCond(p[1]); 
    stampa(p[1]);
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
