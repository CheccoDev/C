#ifndef __LISTA__
#define __LISTA__

#include <cstdlib>
#include <iostream>
using namespace std;

typedef struct Tdato{
	int i; 
	float v;	
	Tdato(){
		i=0; v=0.0;
	}
	Tdato(int _i, float _v){
		i = _i; 
		v = _v;
	}
	void stampa(){
		cout << "[ " << i << "-" << v << " ] " ;
	}
};

typedef struct Tnodo{
	Tdato dato; 
	Tnodo *next;
  
	Tnodo(){
  		next = NULL;
  	}
  	Tnodo(Tdato d){
  		dato = d;
  		next = NULL;
  	}
  	Tnodo(Tdato d, Tnodo* n){
  		dato = d;
		next = n;
  	}
  	void stampa(){
  		dato.stampa();
	}
};

typedef Tdato Dato;
typedef Tnodo Nodo;
typedef Tnodo* Nodoptr;

Nodoptr removeLast(Nodoptr s);
Nodoptr removeFirst(Nodoptr s);
void stampa(Nodoptr s);
Nodoptr insertFirst(Nodoptr s, Dato CurrD);
Nodoptr insertLast(Nodoptr s, Dato CurrD);
int lung(Nodoptr s);

#endif
