#include <cstdlib>
#include <iostream>
#include "lista_struct.h"
using namespace std;

int main(int argc, char *argv[])
{
    Nodo* p;     
	p = NULL;
	
	Nodo* x = new Nodo();
    x->dato.i = 13;
    x->next = NULL; 
    
    Dato miodato;
    //miodato.i=15; x = insertLast(x,miodato);
    miodato = Dato(15, 1.0); 
	x= insertFirst(x,miodato);
    stampa(x);
    miodato = Dato(10, 1.1);
	x = insertLast(x,miodato);
    stampa(x);
    miodato = Dato(16, 2.1);
	x = insertFirst(x,miodato);
    stampa(x);
    x = removeLast(x);
    stampa(x);
    cout << "lung="<<lung(x)<<endl;
    
    
    return EXIT_SUCCESS;
}



