#include <cstdlib>
#include <iostream>
#include "lista_struct.h"

Nodoptr removeLast(Nodoptr s){
	if (s==NULL){ 
		// nessun elemento in lista
		return NULL;
	}
	if (s->next==NULL){ 
		// 1 elemento in lista
		delete s; 
		return NULL;
	}
	Nodoptr p = s;
	while (p->next->next!=NULL){
		p=p->next;  
	} 
	delete p->next;
	p->next = NULL;
	return s;
}
Nodoptr removeFirst(Nodoptr s){
	Nodoptr n = s;
	if (s!=NULL){
		s= s->next;  
		delete n;        
	} 
	return s;   
}
void stampa(Nodoptr s){
	Nodoptr p = s;
	while (p!=NULL){
		p->stampa();
		p = p->next;    
	}
	cout << endl;
}
Nodoptr insertFirst(Nodoptr s, Dato currD){
	/*
	Nodoptr q = new Nodo();
	q->dato = currD;
	q->next = s; 
	return q;
	*/
	return new Nodo(currD, s);     
}

Nodoptr insertLast(Nodoptr s, Dato currD){
	if(s==NULL){
		// inserisce primo elemento
		/*
		Nodoptr q = new Nodo();
		q->dato = currD;
		q->next = s; 
		return q;
		*/
		return new Nodo(currD, NULL);
	}
	Nodoptr p = s;
	while (p->next!=NULL){ 
		p=p->next; 
	}
	p->next = new Nodo(currD, NULL);
	return s;
}
int lung(Nodoptr s){
	int l=0;
	if (s==NULL){ 
		return l; 
	}
	Nodoptr p=s;
	do{
		l++;
		p=p->next;       
	}while(p!=NULL);  
	return l;       
}
