#include <cstdlib>
#include <iostream>
#include "FIFO.h"
#define NELEM 5
using namespace std;

int main(int argc, char *argv[])
{
    /*
    CodaPtr p = new Coda(NELEM);
	Tdato d;
    cout << "coda vuota=" << p->isEmpty() << endl;
    cout << "coda piena=" << p->isFull() << endl;
    d.val = 15;
    p->put(d);
    if( !p->isEmpty() ){ d = p->get();}
    p->stampa();
    */
    CodaPtr c1 = new Coda(NELEM);
	cout << "La coda e' vuota? " << c1->isEmpty() << endl;
	cout << "La coda e' piena? " << c1->isFull() << endl;
	cout << "Contenuto della coda:" << endl; 
	c1->stampa();
	cout << "Put 1, ora la coda contiene:" << endl;
	if( !c1->isFull() )
		c1->put(Tdato(1));  
	c1->stampa();
	cout << "Put 2, 3, 4, 5; ora la coda contiene:" << endl;
	if( !c1->isFull() )
		c1->put(Tdato(2)); 
	if( !c1->isFull() )
		c1->put(Tdato(3)); 
	if( !c1->isFull() )
		c1->put(Tdato(4)); 
	if( !c1->isFull() )
		c1->put(Tdato(5));  
	c1->stampa();
	cout << "Put 6, ora la coda contiene:" << endl;
	if( !c1->isFull() )
		c1->put(Tdato(6)); //non viene inserito: coda piena
	c1->stampa();
	if( !c1->isEmpty() ){
		cout << "Get(C1):"; 	
		c1->get().stampa(); 
		cout << endl;
		cout << "Estratto un elemento, ora la coda contiene:" << endl;
		c1->stampa();
	}
	if( !c1->isEmpty() ){
		cout << "Get(C1): ";  get(c1).stampa();  cout << endl;
	}
	if( !c1->isEmpty() ){
		cout << "Get(C1): ";  get(c1).stampa();  cout << endl;
	}
	
	cout << "Contenuto della coda:" << endl;  
	c1->stampa();
	cout << "Put 6, 7, 8; ora la coda contiene:" << endl;
	if( !c1->isFull() )
		c1->put(Tdato(6)); 
	if( !c1->isFull() )
		c1->put(Tdato(7)); 
	if( !c1->isFull() )
		c1->put(Tdato(8)); 
	c1->stampa();
	cout << "Svuotiamo la coda:" << endl;
	if( !c1->isEmpty() ){
		cout << "Get(C1): ";  
		get(c1).stampa();  
		cout << endl;
	}
	
	if( !c1->isEmpty() ){
		cout << "Get(C1): ";  
		get(c1).stampa();  
		cout << endl;
	}
	if( !c1->isEmpty() ){
		cout << "Get(C1): ";  
		get(c1).stampa();  
		cout << endl;
	}if( !c1->isEmpty() ){
		cout << "Get(C1): ";  
		get(c1).stampa();  
		cout << endl;
	}
	if( !c1->isEmpty() ){
		cout << "Get(C1): ";  
		get(c1).stampa();  
		cout << endl;
	}
	cout << "Contenuto della coda:" << endl;
	c1->stampa();
	if( !c1->isEmpty() ){
		cout << "Get(C1): ";  
		get(c1).stampa();  
		cout << endl;
	}
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
