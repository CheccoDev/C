#include <cstdlib>
#include <iostream>
#include "FIFO.h"
using namespace std;

// prelievo in head
Tdato get(CodaPtr p){
   	Tdato d;
   	d = p->s[p->head];
   	p->n--;
   	p->head++;
   	p->head = p->head % p->dim;
   	return d;  
}

// inserimento in tail
void put(CodaPtr p, Tdato d){
	if (codaIsFull(p)){
		cout << "coda piena" << endl;
		return;
	}
	p->n++;
	p->s[p->tail]=d;
	p->tail++; //array va da 0 a dim-1
	p->tail = p->tail % p->dim;
}
bool codaIsEmpty(CodaPtr p){
  	return (p->n==0);     
}
bool codaIsFull(CodaPtr p){
  	return (p->n==p->dim);   
}
void stampa(CodaPtr p){
	p->stampa();
	cout << endl;
} 
