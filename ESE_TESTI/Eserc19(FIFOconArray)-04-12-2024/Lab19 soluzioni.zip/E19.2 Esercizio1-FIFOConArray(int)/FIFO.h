// Definizione dell�ADT(Abstract Data Type) Coda
//===============================================
#ifndef __FIFOH__
#define __FIFOH__

#include <iostream>
using namespace std;
typedef struct TipoCoda {
	int n;    // numero elementi nella coda
	int dim;  // dimensione max coda
	int head; // elemento in testa
	int tail; // elemento in coda
	int * s;  // elementi -- ARRAY
	TipoCoda () { // costruttore
		dim = 3;
		n = 0;
		head = 0;
		tail = 0;
		s = new int[3];
	}
	TipoCoda (int x) { // costruttore
		dim = x;
		n = 0;
		head = 0;
		tail = 0;
		s = new int[x];
	}
	~TipoCoda () { // distruttore
		delete s;
	}
	void stampa(){
		if(n==0) return;
		int i=head;
		do{
			cout << s[i] << " "; 
			i = (++i)%dim;
		}while(i!=tail);
	}
}TipoCoda;

// Definizione dei tipi
typedef TipoCoda Coda;
typedef TipoCoda *CodaPtr;

// Metodi del tipo di dato astratto Coda FIFO

// Verifica se la coda e' vuota o no
bool codaIsEmpty(CodaPtr p);

// Verifica se la coda e' piena o no
bool codaIsFull(CodaPtr p);

// Inserisce l�elemento d nella coda aumentandone la dimensione
void put(CodaPtr p, int x);

// Rimuove un elemento dalla coda, diminuendone la dimensione
int get(CodaPtr p);

// Stampa il contenuto della coda
void print(CodaPtr p);

#endif

