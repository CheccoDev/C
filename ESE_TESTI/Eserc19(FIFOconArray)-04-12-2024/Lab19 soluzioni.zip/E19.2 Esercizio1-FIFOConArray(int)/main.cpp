#include <cstdlib>
#include <iostream>
#include "FIFO.h"
using namespace std;

#define N_ELEM 5
int main(int argc, char *argv[])
{
    CodaPtr c1 = new Coda(N_ELEM);
    cout << "La coda e' vuota? " << codaIsEmpty(c1) << endl;
    cout << "La coda e' piena? " << codaIsFull(c1) << endl;
    cout << "Contenuto della coda:" << endl;
    print(c1);
    cout << "Put 1, ora la coda contiene:" << endl;
    put(c1,1); 
    print(c1);
    cout << "Put 2, 3, 4, 5; ora la coda contiene:" << endl;
    if(!codaIsFull(c1))
		put(c1,2); 
	if(!codaIsFull(c1))
		put(c1,3); 
	if(!codaIsFull(c1))
		put(c1,4); 
	if(!codaIsFull(c1))
		put(c1,5); 
    print(c1);
    cout << "Put 6, ora la coda contiene:" << endl;
    if(!codaIsFull(c1))
		put(c1,6); 
	print(c1);  //non viene inserito: coda piena
    if(!codaIsEmpty(c1)){
		cout << "Get(c1): " << get(c1) << endl;
	    cout << "Estratto un elemento, ora la coda contiene:" << endl;
    	print(c1);
	}
	if(!codaIsEmpty(c1))
    	cout << "Get(c1): " << get(c1) << endl;
    if(!codaIsEmpty(c1))
    	cout << "Get(c1): " << get(c1) << endl;
    if(!codaIsEmpty(c1))
    	cout << "Contenuto della coda:" << endl;
    print(c1);
    cout << "Put 6, 7, 8; ora la coda contiene:" << endl;
    if(!codaIsFull(c1))
		put(c1,6); 
	if(!codaIsFull(c1))
		put(c1,7); 
	if(!codaIsFull(c1))
		put(c1,8);
    print(c1);
    cout << "(notare che la coda e' gestita come array circolare)" << endl;
    cout << "Svuotiamo la coda:" << endl;
    if(!codaIsEmpty(c1))
    	cout << "Get(c1): " << get(c1) << endl;
    if(!codaIsEmpty(c1))
    	cout << "Get(c1): " << get(c1) << endl;
    if(!codaIsEmpty(c1))
    	cout << "Get(c1): " << get(c1) << endl;
    if(!codaIsEmpty(c1))
    	cout << "Get(c1): " << get(c1) << endl;
    if(!codaIsEmpty(c1))
    	cout << "Get(c1): " << get(c1) << endl;
    cout << "Contenuto della coda:" << endl;
    print(c1);
    if(!codaIsEmpty(c1)){
    	cout << "Get(c1): " << endl;
    	get(c1); //non viene prelevato alcun valore: coda vuota
	}else{
		cout << "No Get(c1): coda era vuota" << endl;
	}

    return EXIT_SUCCESS;
}
