#include <iostream>
#include "FIFO.h"
using namespace std;

bool codaIsEmpty(CodaPtr p) {  
	return (p->n == 0); 
}

bool codaIsFull(CodaPtr p) {  
	return (p->n == p->dim); 
}

void put(CodaPtr p, int x) {  
	//cout << "Coda:" << p->tail << " Testa:" << p->head <<  " Value:" << x << endl;
	if (codaIsFull(p)) {
		cout << "Coda piena, " << x << " non iserito" << endl;
	}
	else {
		p->n++;
		p->s[p->tail] = x;
		p->tail = (p->tail + 1) % (p->dim);
	}
	//cout << "Dopo Coda:" << p->tail << " Testa:" << p->head <<  " Value:" << x << endl;
}
 
int get(CodaPtr p) { 
	//cout << "   Coda:" << p->tail << " Testa:" << p->head << " "<<p->s[p->head] << endl;
	if (codaIsEmpty(p)) 
	{cout << "Coda vuota" << endl;}
	else {
		int r = p->s[p->head];
		p->n--;
		p->head = p->head + 1; p->head = p->head % p->dim;
		//cout << "   Coda:" << p->tail << " Testa:" << p->head << endl;
		return r;
	}
}

void print(CodaPtr p) {
	int i;
	if (codaIsEmpty(p)) {
		cout << "La coda e' vuota" << endl;
		return;
	}
	//cout << "Testa:" << p->head  << " Coda:" << p->tail <<  endl;
	i=p->head;
	// cout <<"[" << p->s[i] << "]"; 
	do{
		//cout <<"[" << p->s[i] << "]"; 
		cout << i << "->[" << p->s[i] << "] ";
		i=++i % (p->dim);
	}while (i!=p->tail);
	cout <<endl;
}

