#include <cstdlib>
#include <iostream>
#include "FIFO.h"
using namespace std;

#define N_MAX_ELEM 10
#define K 40

int isDispari(int n) {
	return n%2;
    //return ((int)(n/2))*2 != n;
    // return n%2==0 ? false : true;
    // return n%2!=0 ? true : false;
    // return n%2!=0;
    // return n%2;    
}

int main(int argc, char *argv[])
{
    CodaPtr P = new Coda(N_MAX_ELEM);
    CodaPtr D = new Coda(N_MAX_ELEM);
    Tdato dd;
    
    int num, count = 0;
    srand(12);
    for (count = 0; count < K; count ++) {
        num = rand()%9+1;
        dd = Tdato(num);
        cout << endl;
        cout << count+1 << ") Numero: " << num << endl;
        if (isDispari(num)) { // num e' dispari
            if (num < 6) {
                if (!codaIsFull(D)) { // !D->isFull()
                    put(D,dd);
                    //D->put(dd)
                    cout << "D: ";
                    stampa(D); 
					// D->stampa();
					// D->stampa() --> stampa() � metodo di TipoCoda
                } else {
                    cout << "D � piena, scarto il valore " << num << endl;
                }
            } else {
                if (!codaIsEmpty(D)) { // !D->isEmpty()
                    cout << "D (estratto "; 
					get(D).stampa(); 
					// D->get().stampa();
					// D->get().stampa() --> stampa() � metodo di Tdato
					cout << "): ";
                    stampa(D); 
					// D->stampa();
                    // D->stampa() --> stampa() � metodo di TipoCoda
                } else { cout << "D e' vuota" << endl; }
            }
        } else { // num e' pari
            if (num < 5) {
                if (!codaIsFull(P)) { // !P->isFull()
                    put(P,dd);
                    // P->put(dd)
                    cout << "P: ";
                    stampa(P);
                    // P->stampa();
					// P->stampa() --> stampa() � metodo di TipoCoda
                } else {
                    cout << "P � piena, scarto il valore " << num << endl;
                }
            } else {
                if (!codaIsEmpty(P)) {
                    cout << "P (estratto " ;
					get(P).stampa();
					// P->get().stampa();
	                // P->get().stampa(); --> stampa() � metodo di Tdato
					cout << "): ";
                    stampa(P);
                    // P->stampa();
                    // P->stampa() --> stampa() � metodo di TipoCoda
                } else { cout << "P e' vuota" << endl; }
            }
        }
    } // end for

    cout << endl << "Coda P: ";
    stampa(P);
    // P->stampa();
    // P->stampa() --> stampa() � metodo di TipoCoda
    cout << endl << "Coda D: ";
    stampa(D);
    // D->stampa();
    // D->stampa() --> stampa() � metodo di TipoCoda
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
