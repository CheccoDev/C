#include <iostream>

using namespace std;

typedef struct Tdato{
	int val; 
	Tdato(){
		val = 0;
	}
	Tdato(int x){
		val = x;
	}
	void stampa(){
		cout << val << " ";
	}     
}Tdato;

typedef struct TipoCoda{
	int head, tail;  //inserimento prelevamento
	int dim; //num elementi array==coda
	int n; //numero elementi presenti nella coda
	//int* s;
	Tdato* s;
	TipoCoda(int x){ //x = dimensione array==coda
		head=0; 
		tail=0;
		dim = x;
		n = 0;
		//s = new int[x]; 
		s = new Tdato[x];       
	}
	TipoCoda(){ //3 = dimensione array==coda
		head=0; 
		tail=0;
		dim = 3;
		n = 0;
		//s = new int[x]; 
		s = new Tdato[3];       
	}
	~TipoCoda(){
		delete s;
	}
	void stampa(){
		if(n==0) return;
		int i = head;
		do{
			s[i].stampa();
			i = (++i)%dim;
		}while(i!=tail);
		cout << endl;
	}
	bool isEmpty(){
		return n == 0;
	}
	bool isFull(){
		return n == dim;
	}
	// controllo se spazio disponibile fatto da funzione chiamante
	void put(Tdato d){
		n++;
    	s[tail]=d;
    	tail = (++tail) % dim;
	}
	// controllo se coda non vuota fatto da funzione chiamante
	Tdato get(){
		Tdato d = s[head];
		head = ++head %dim;
		n--;
		return d;
	}
}TipoCoda;
typedef TipoCoda Coda;
typedef TipoCoda* CodaPtr;

/* funzioni */
bool codaIsEmpty(CodaPtr p);
bool codaIsFull(CodaPtr p);
void put(CodaPtr p, Tdato d);
Tdato get(CodaPtr p);
void stampa(CodaPtr p);


