#include <cstdlib>
#include <iostream>
#include "FIFO.h"

#define NELEM 5
using namespace std;

int main(int argc, char *argv[])
{
    
    /*
    CodaPtr p = new Coda(NELEM);
	Tdato d;
    cout << "coda vuota=" << CodaIsEmpty(p)<< endl;
    cout << "coda piena=" << CodaIsFull(p)<< endl;
    d.val = 15;
    Put(p,d);
    if (codaIsEmpty(p)==false){ d = Get(p);}
    */
    CodaPtr c1 = new Coda(NELEM);
	cout << "La coda e' vuota? " << codaIsEmpty(c1) << endl;
	cout << "La coda e' piena? " << codaIsFull(c1) << endl;
	cout << "Contenuto della coda:" << endl; 
	stampa(c1);
	cout << "Put 1, ora la coda contiene:" << endl;
	if(!codaIsFull(c1))
		put(c1, Tdato(1));  
	stampa(c1);
	cout << "Put 2, 3, 4, 5; ora la coda contiene:" << endl;
	if(!codaIsFull(c1))
		put(c1, Tdato(2)); 
	if(!codaIsFull(c1))
		put(c1, Tdato(3)); 
	if(!codaIsFull(c1))
		put(c1, Tdato(4)); 
	if(!codaIsFull(c1))
		put(c1, Tdato(5));  
	stampa(c1);
	cout << "Put 6, ora la coda contiene:" << endl;
	if(!codaIsFull(c1))
		put(c1, Tdato(6)); //non viene inserito: coda piena
	stampa(c1);
	if(!codaIsEmpty(c1)){
		cout << "Get(C1): ";  
		get(c1).stampa();  
		cout << endl;
	}
	cout << "Estratto un elemento, ora la coda contiene:" << endl;
	stampa(c1);
	if(!codaIsEmpty(c1)){
		cout << "Get(C1): ";  
		get(c1).stampa();  
		cout << endl;
	}
	if(!codaIsEmpty(c1)){
		cout << "Get(C1): ";  
		get(c1).stampa();  
		cout << endl;
	}
	cout << "Contenuto della coda:" << endl;  
	stampa(c1);
	cout << "Put 6, 7, 8; ora la coda contiene:" << endl;
	if(!codaIsFull(c1))
		put(c1, Tdato(6)); 
	if(!codaIsFull(c1))
		put(c1, Tdato(7)); 
	if(!codaIsFull(c1))
		put(c1, Tdato(8)); 
	stampa(c1);
	cout << "Svuotiamo la coda:" << endl;
	
	if(!codaIsEmpty(c1)){
		cout << "Get(C1): ";  
		get(c1).stampa();  
		cout << endl;
	}
	
	if(!codaIsEmpty(c1)){
		cout << "Get(C1): ";  
		get(c1).stampa();  
		cout << endl;
	}
	if(!codaIsEmpty(c1)){
		cout << "Get(C1): ";  
		get(c1).stampa();  
		cout << endl;
	}
	if(!codaIsEmpty(c1)){
		cout << "Get(C1): ";  
		get(c1).stampa();  
		cout << endl;
	}
	if(!codaIsEmpty(c1)){
		cout << "Get(C1): ";  
		get(c1).stampa();  
		cout << endl;
	}
	cout << "Contenuto della coda:" << endl;
	stampa(c1);
	if(!codaIsEmpty(c1)){
		cout << "Get(C1): ";  
		get(c1).stampa();  
		cout << endl;
	}else{
		cout << "No Get(c1): coda vuota"<<endl;
	}
	
    return EXIT_SUCCESS;
}
