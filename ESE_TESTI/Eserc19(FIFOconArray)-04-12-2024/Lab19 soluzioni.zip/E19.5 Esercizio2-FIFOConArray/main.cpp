#include <cstdlib>
#include <iostream>
#include "FIFO.h"
using namespace std;

#define N_MAX_ELEM 10
#define K 40

int main(int argc, char *argv[])
{
    CodaPtr c = new Coda(N_MAX_ELEM);
    Tdato d;
    int num, ni, count = 0;
    srand(12);
    for (count = 0; count < K; count ++) {
    	//cin >> num;
        num = rand()%100;
        cout << count+1 << ") Numero: " << num << endl;
        ni = rand()%(20-1+1)+1;
        if( ni > 10 ) {
        	d = Tdato(num);
        	if( !codaIsFull(c) )
        		put(c, d);
        		// c->put(d);
        } 
        stampa(c);
		// c->stampa();
		ni = rand()%(20-1+1)+1;
        if( ni < 10 ) {
        	if( !codaIsEmpty(c) )
        		d = get(c);
        		// d = c->get();
        }
		stampa(c);		
		// c->stampa();
		cout << endl;
	}
		
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
