#include <cstdlib>
#include <iostream>
#include "FIFO.h"
using namespace std;

// prelievo in head
Tdato get(CodaPtr p){
   	Tdato d;
   	d = p->s[p->head];
   	p->n--;
   	p->head++;
   	p->head = p->head % p->dim;
   	return d;  
}

// inserimento in tail
void put(CodaPtr p, Tdato d){
	if (codaIsFull(p)){
		cout << "coda piena" << endl;
		return;
	}
	p->n++;
	p->s[p->tail]=d;
	p->tail++; //array va da 0 a dim-1
	p->tail = p->tail % p->dim;
}
bool codaIsEmpty(CodaPtr p){
  	return (p->n==0);     
}
bool codaIsFull(CodaPtr p){
  	return (p->n==p->dim);   
}
void stampa(CodaPtr p){
	p->stampa();
	cout << endl;
}

int casuale(int min, int max){
	return rand()%(max-min+1)+min;
}
Tdato dato_casuale(){
	return Tdato(casuale(-10, 100));
}
void scrivi_file(char nome_file[], Tdato d){
	FILE* f = fopen(nome_file, "a"); // APPEND
	if(f==NULL)
		return;
	fprintf(f, "%d\n", d.val);
	fclose(f);
}
bool code_vuote(CodaPtr v[], int dim){
	int i;
	for(i=0 ; i<dim; i++){
		if( !v[i]->isEmpty() ){
			return false;
		}
	}
	return true;
}

int coda_lunga(CodaPtr v[], int dim){
	// se tutte code vuote restituisco -1
	// valore che indica errore
	if( code_vuote(v, dim) ){
		return -1;
	}
	int i, i_max;
	i_max = -1;
	// cercare prima coda NON vuota
	// la prima coda NON vuota � il mio massimo
	i=0; 
	while(i<dim && i_max==-1){
		if( !v[i]->isEmpty() )
			i_max = i;
		i++;
	}
	// continuo con le altre code
	while(i<dim){
		if( !v[i]->isEmpty() )
			if( v[i]->n > v[i_max]->n  )
				i_max = i;
		i++;
	}
	return i_max;
}

int dato_massimo(CodaPtr v[], int dim){
	// se tutte code vuote restituisco -1
	// valore che indica errore
	if( code_vuote(v, dim) ){
		return -1;
	}
	int i, i_max;
	i_max = -1;
	// cercare prima coda NON vuota
	// la prima coda NON vuota � il mio massimo
	i=0; 
	while(i<dim && i_max==-1){
		if( !v[i]->isEmpty() )
			i_max = i;
		i++;
	}
	// continuo con le altre code
	while(i<dim){
		if( !v[i]->isEmpty() )
			if( v[i]->s[ v[i]->head ].val > v[i_max]->s[ v[i]->head ].val  )
				i_max = i;
		i++;
	}
	return i_max;
}

 
