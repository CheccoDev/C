#include <cstdlib>
#include <iostream>
#include "FIFO.h"
using namespace std;

#define N_CODE 3
#define N_ELEM 6
#define K 10

int main(int argc, char *argv[])
{
    CodaPtr p[N_CODE];
    // modo 2: allocazione dinamica di p
    //CodaPtr *p = new CodaPtr[N_CODE];
    
	Tdato x;
	int i, pos;
	
	for(i=0 ; i<N_CODE ; i++){
		p[i] = new Coda(N_ELEM);
	}
    
    for(i=0 ; i<K; i++){
    	x = dato_casuale();
		pos = casuale(0, N_CODE-1);
    	if( !p[pos]->isFull() ){
    		p[pos]->put(x);
		}else{
			scrivi_file("scarti.txt", x);
		}
	}
    
    if( !code_vuote(p, N_CODE) ){
    	printf("coda con dato massimo: %d\n", dato_massimo(p, N_CODE) );
    	printf("coda pi� lunga: %d\n", coda_lunga(p, N_CODE) );
	}
    
    for(i=0 ; i<N_CODE ; i++){
    	printf("\ncoda %d\n", i);
		p[i]->stampa();
	}
    
    for(i=0 ; i<N_CODE ; i++){
    	p[i]->~TipoCoda();
	}
    // se p definito in modo 2, serve aggiungere
	// delete[] p;
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
