#include <iostream>

using namespace std;

typedef struct Tdato{
	int val; 
	Tdato(){
		val = 0;
	}
	Tdato(int x){
		val = x;
	}
	void stampa(){
		cout << val << " ";
	}     
}Tdato;

typedef struct TipoCoda{
	int head, tail;  //inserimento prelevamento
	int dim; //num elementi array==coda
	int n; //numero elementi presenti nella coda
	//int* s;
	Tdato* s;
	TipoCoda(int x){ //x = dimensione array==coda
		head=0; 
		tail=0;
		dim = x;
		n = 0;
		//s = new int[x]; 
		s = new Tdato[x];       
	}
	TipoCoda(){ //3 = dimensione array==coda
		head=0; 
		tail=0;
		dim = 3;
		n = 0;
		//s = new int[x]; 
		s = new Tdato[3];       
	}
	~TipoCoda(){
		delete s;
	}
	void stampa(){
		if(n==0) return;
		int i = head;
		do{
			s[i].stampa();
			i = (++i)%dim;
		}while(i!=tail);
		cout << endl;
	}
	bool isEmpty(){
		return n == 0;
	}
	bool isFull(){
		return n == dim;
	}
	// controllo se spazio disponibile fatto da funzione chiamante
	void put(Tdato d){
		n++;
    	s[tail]=d;
    	tail = (++tail) % dim;
	}
	// controllo se coda non vuota fatto da funzione chiamante
	Tdato get(){
		Tdato d = s[head];
		head = ++head %dim;
		n--;
		return d;
	}
}TipoCoda;
typedef TipoCoda Coda;
typedef TipoCoda* CodaPtr;

/* funzioni */
bool codaIsEmpty(CodaPtr p);
bool codaIsFull(CodaPtr p);
void put(CodaPtr p, Tdato d);
Tdato get(CodaPtr p);
void stampa(CodaPtr p);

int casuale(int min, int max);
Tdato dato_casuale();
//Restituisce un dato il cui campo val � inizializzato in modo casuale tra -10 e +100
void scrivi_file(char nome_file[], Tdato d);
//Input: nome del file su cui stampare e dato da salvare. Aggiunge al contenuto del file indicato il contenuto del campo val di Tdato
//Un valore per ogni riga
bool code_vuote(CodaPtr v[], int dim);
//Input: array di puntatori a TipoCoda e sua dimensione effettiva. Restitusice vero se tutte le code dell�array v sono vuote
int dato_massimo(CodaPtr v[], int dim);
//Input: array di puntatori a TipoCoda e sua dimensione effettiva. Restituisce l�indice della coda dell�array v che ha il dato da estrarre di valore massimo
int coda_lunga(CodaPtr v[], int dim);
//Input: array di puntatori a TipoCoda e sua dimensione effettiva. Restituisce l�indice della coda dell�array v che ha il dato da estrarre di valore massimo


