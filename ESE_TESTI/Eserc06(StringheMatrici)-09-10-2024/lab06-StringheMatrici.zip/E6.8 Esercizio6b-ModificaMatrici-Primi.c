/*
Definire una matrice quadrata NxN (con N=4)
Inserire da tastiera nella matrice dei valori compresi tra 0 e VALORE_MAX-1.
Stampare a video la matrice
Modificare il contenuto della matrice in modo che:
ad ogni numero primo sia assegnato il valore -1.
Stampare a video la matrice
*/
#include <stdio.h>
#define N 4

// con funzione --> funzioni trattate in lab successivi
int primo(int n){
 int c = 2; 
 while (c < n) {
	if (n % c == 0) {
		return 0; 
	}
	c++; 
  }
 return 1;
}

int main(){
	int a[N][N]={ {0,3,3,1} , {4,9,1,4} , {3,8,5,8} , {1,2,4,8} };
	int i, j, x, primo; 
	//init
	// fatta in modo statico per evitare - in fase di test -
	// di inserire i dati.
	//for (i=0; i<N; i++) {
	//	for (j=0; j<N; j++) {
	//		do{
	//			scanf("%d", &a[i][j]);
	//			if(a[i][j]<0 || a[i][j]>=VALORE_MAX){
	//				printf("errore. re-inserisci:");
	//			}
	//		}while(a[i][j]<0 || a[i][j]>=VALORE_MAX);
	//	}
	//}
	//stampa
	for (i=0; i<N; i++) {
		for (j=0; j<N; j++) {
			printf("%2d", a[i][j]);
		}
		printf("\n");
	}
	//modifica	
	for (i=0; i<N; i++) {
		for (j=0; j<N; j++) {
			//if (a[i][j]>6) { a[i][j]=5; }
			//if (a[i][j]>2 && a[i][j]<9) { a[i][j]=0; }
			// con funzione --> funzioni trattate in lab successivi
			// if (primo(a[i][j])) { a[i][j]=-1; }
			primo = 1;
			x = 2;
			while(primo && x<a[i][j]){
				if(a[i][j]%x==0){
					primo = 0;
				}
				x++;
			}
			if(primo){
				a[i][j]=-1;
			}
		}
	}
	printf("\n---------------------\n");
	//stampa
	for (i=0; i<N; i++) {
		for (j=0; j<N; j++) {
			printf("%2d", a[i][j]);
		}
		printf("\n");
	}
	//system("PAUSE");
	return 0;
}
