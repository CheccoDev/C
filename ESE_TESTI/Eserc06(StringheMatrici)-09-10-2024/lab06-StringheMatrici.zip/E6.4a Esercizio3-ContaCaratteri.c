/*
Chiedere all'utente un carattere alla volta
Contare le occorrenze di 
- ogni cifra 0-9, 
- caratteri di spaziatura (spazio, carattere di tabulazione e new line).
Terminare quando l'utente inserisce il carattere q.
Stampare a video le occorrenze relative a
- ogni cifra 0-9
- caratteri di spaziatura (nwhite)
- altri caratteri (nother)
*/
#include <stdio.h>
#define NDIG 10
int main (int argc, const char * argv[]) {
    int c, i, nwhite, nother;    
    int ndigit[NDIG];
    nwhite = 0;
    nother = 0;
    for (i=0; i<NDIG; i++){
    	ndigit[i]=0;
    }
    //inserire il carattere 'q' per terminare 
    //non serve fflush perch� uso getchar
    while ((c=getchar()) != 'q'){
    	if (c >= '0' &&  c<= '9') {
    	  ++ndigit[c -'0'];
    	} else {
         if (c == ' ' ||  c == '\n' || c == '\t'){
    	    ++nwhite;
    	  } else {
    	    ++nother;
         }
       }
    }
    printf("cifre =");
    for (i = 0; i < NDIG; ++i){ 
        printf(" %d",ndigit[i]); 
    }
    printf(", spaziature = %d, altri = %d\n",nwhite,nother);    

	system("PAUSE");
	return 0;
}
