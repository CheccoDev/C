/*
Scrivere un programma che legge un carattere alla volta da tastiera 
e lo stampa immediatamente a video
Uso di getchar(), putchar(char c)
*/
#include <stdio.h>

int main (int argc, const char * argv[]) {
	char c;
	//serve fflush perch� uso scanf
	printf("car="); fflush(stdin); scanf("%c",&c);
	while (1) {
		printf("car letto=%c\n",c);
		printf("car="); fflush(stdin); scanf("%c",&c);
	}
	
	system("PAUSE");
	return 0;
}
