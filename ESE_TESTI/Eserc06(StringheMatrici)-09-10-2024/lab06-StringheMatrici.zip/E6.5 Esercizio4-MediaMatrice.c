/*
Inizializzare con valori casuali (0, 100 compresi) una matrice MAXxMAX.
Stampare la matrice.
Calcolare e stampare la media dei valori.
Stampare le coordiante delle celle il cui valore � maggiore della media.
*/
#include <stdio.h>
#include <stdlib.h>
#define MAX 8
int main(int argc, char *argv[])
{
  int mat[MAX][MAX];
  int i,j, somma;
  float media;
  srand(time(0));
  //init
  for(i=0;i<MAX;i++){
     for(j=0;j<MAX;j++){
        mat[i][j]=rand()%(100-0+1)+0;
     }               
  }    
  //stampa
  for(i=0;i<NR;i++){
     for(j=0;j<NC;j++){
        printf("%d ",mat[i][j]);
     }  
     printf("\n");             
  }  
  //calcolo media
  somma = 0;
  for(i=0;i<NR;i++){
     for(j=0;j<NC;j++){
        somma += mat[i][j];
     }              
  }  
  media = (float)somma/(NR*NC);   
  //stampa posizione
  for(i=0;i<NR;i++){
     for(j=0;j<NC;j++){
        if (m[i][j]>media) {
           printf("[%d,%d]\n",i,j);
        }
     }              
  } 
  //system("PAUSE");	
  return 0;
}
