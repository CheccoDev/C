/*
Chiedere all'utente una parola.
Controllare se la parola � palindroma o meno.
*/
#include <stdio.h>
#define NCAR 20

int main (int argc, const char * argv[]) {
	char stringa[NCAR];
	int len = 0, i, j;
	int ispalindrome=1;
	printf("Inserire la stringa: ");
	fflush(stdin);
	//non servirebbe fflush perch� faccio un'unica acquisizione dati
	gets(stringa); //oppure scanf("%s", stringa); 
	while(stringa[len]!='\0'){
		len++;
	}
	/*
	oppure
	while(stringa[len]){
		len++;
	}
	oppure
	while(stringa[len++]){
		;
	}
	oppure
	while(stringa[len++]); // notare il ; dopo il ciclo while
	*/
	
	i = 0; //primo carattere 
  	j=len-1; //ultimo carattere 
	while(i <= j && ispalindrome){
		if(stringa[i] != stringa[j]){
			ispalindrome = 0;
        }
		i++;
		j--;
	}              
	if(ispalindrome){
		printf("La stringa %s e' palindroma!\n", stringa);
	} else {
		printf("La stringa %s non e' palindroma!\n", stringa);
    }
    //system("PAUSE");
    return 0;
}
