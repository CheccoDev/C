/*
Date due matrici A e B, calcolare il prodotto AxB.
*/
#include <stdio.h>
#define M 2
#define N 3
#define P 2

int main (int argc, const char * argv[]) {
	int a[M][N]={{1,0,2},{-1,3,1}};
	int b[N][P]={{3,1},{2,1},{1,0}};
	int i,j,k,cij; 
	
	for (i=0; i<M; i++) {
		for (j=0; j<P; j++) {
			cij=0;             /* calcola l’elemento Cij */
			for (k=0; k<N; k++){    
				cij=cij+a[i][k]*b[k][j];
			}
			printf("%d ", cij);
		}
		printf("\n");
	}
    return 0;
}
