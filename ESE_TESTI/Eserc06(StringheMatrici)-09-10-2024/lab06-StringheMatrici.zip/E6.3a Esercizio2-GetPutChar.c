/*
Scrivere un programma che legge un carattere alla volta da tastiera 
e lo stampa immediatamente a video
Uso di getchar(), putchar(char c)
*/
#include <stdio.h>

int main (int argc, const char * argv[]) {
	int c;
	//non serve fflush perch� uso getchar
	c = getchar();
	while (c != EOF) {
		putchar(c);
		c = getchar();
	}
	
	/* oppure
	while ( (c = getchar()) != EOF) {
		putchar(c);
	}
	*/
	
	system("PAUSE");
	return 0;
}
