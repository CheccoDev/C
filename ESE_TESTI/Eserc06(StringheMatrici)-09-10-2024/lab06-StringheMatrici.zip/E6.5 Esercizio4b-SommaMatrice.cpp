/*Definire una matrice m di interi di dimensione NR (8) x NC (8)
    #define NR 8
    #define NC 8
 (1) Inizializzare la matrice con numeri casuali compresi tra VMIN 0 e VMAX 100
 (2) Stampare la matrice in modo opportuno
 (3) Calcolare la media di tutti i valori della matrice
 (4) Stampa a video la posizione delle celle della matrice m il cui valore è minore della media
 (5) Stampa a video solo le celle della matrice m il cui valore è maggiore della media, altrimenti stampa X
 (6) Chiedere all'utente una valore di soglia SO e un valore k.vStampare a video la posizione del primo elemento della sequenza di k elementi la cui somma è maggiore delle soglia SO
 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define NR 5
#define NC 5
#define VMIN 0
#define VMAX 10

int main(int argc, const char * argv[]) {
    
    int mat[NR][NC];
    int somma;
    float media;
    int min;
    int max;
    
    int SO, k, contatore;
    srand(time(0));
    
    //Inizializzo la matrice con valori casuali tra 0 e 100
    for(int i=0; i<NR; i++){
        for(int j=0; j<NC; j++){ 
            mat[i][j] = rand()%(VMAX - VMIN + 1) + VMIN;  
        }
    }
    
    //Stampo la matrice
    printf("Matrice\n");
    for(int i=0; i<NR; i++){
        for(int j=0; j<NC; j++){
            printf("%3d", mat[i][j]);
        }
        printf("\n");
    }
    
    printf("Inserisci SO: ");
    scanf("%d", &SO);
    printf("Inserisci k: ");
    scanf("%d", &k);
    
    contatore=0; //contatore celle adiacenti (anche su pi� righe)
    for(int i = 0; i<NR; i++){
        for(int j = 0; j<NC; j++){
        	somma = 0;
        	printf("Verifico da posizione [%d,%d]\n",i,j);
        	for(contatore=0; contatore<k; contatore++){
        		//verifico di non essere uscito dai limiti della riga corrente
        		if (j+contatore>=NC) { break; }
        		somma += mat[i][j+contatore];
			 	printf(" [%d,%d]=%d somma=%d (%d)\n",i,j+contatore,mat[i][j+contatore],somma,contatore);
			 	if(somma >= SO){
                	printf(" Pos: %d %d\n\n", i, j);
                	break;
            	}
			}   
           
        }
    }
    
    printf("\n");
    return 0;
}
