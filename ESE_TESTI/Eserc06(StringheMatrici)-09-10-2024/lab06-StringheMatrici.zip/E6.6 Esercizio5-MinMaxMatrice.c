/*
Inizializzare matrice NRxNC con valori casuali 18-30 (estremi inclusi).
Stampare matrice.
Stampare il valore minimo, il massimo e la media.
Stampare la matrice: stampare il valore se � >25 altrimenti stampare x. 
*/
#include <stdio.h>
#include <stdlib.h>
#define NR 4
#define NC 4
int main(int argc, char *argv[]){
  int mat[NR][NC];
  int i,j;
  int somma, min, max;
  float media;
  srand(time(0));
  //init
  for(i=0;i<NR;i++){
     for(j=0;j<NC;j++){
        mat[i][j]=rand()%(30-18+1)+18;
     }               
  }    
  //stampa
  for(i=0;i<NR;i++){
     for(j=0;j<NC;j++){
        printf("%3d",mat[i][j]);
     }  
     printf("\n");             
  } 
  printf("\n");
  //stampa con vincoli
  for(i=0;i<NR;i++){
     for(j=0;j<NC;j++){
        if (mat[i][j]<=25){
          printf(" X ");                 
        }else{
          printf("%3d",mat[i][j]);
        }
     }  
     printf("\n");             
  }
  printf("\n");  
  //calcolo media, min e max
  somma = 0;
  min = mat[0][0];
  max = mat[0][0];
  for(i=0;i<NR;i++){
     for(j=0;j<NC;j++){
        somma += mat[i][j];
        if (min > mat[i][j]) { min = mat[i][j]; }
        if (max < mat[i][j]) { max = mat[i][j]; }
     }              
  }  
  media = (float)somma/(NR*NC); 
  printf("media = %5.2f \n",media);
  printf("min = %d \nmax = %d \n",min, max);  
  system("PAUSE");	
  return 0;
}
