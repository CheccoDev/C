/*
Definire una matrice quadrata NxN (con N=4)
Inserire da tastiera nella matrice dei valori compresi tra �A� e �M�.
Stampare a video la matrice
Modificare il contenuto della matrice in modo che:
ad ogni carattere compreso tra �F� ed �I� sia assegnato il carattere �Z�.
Stampare a video la matrice
*/
#include <stdio.h>
#define N 4

int main(){
	char a[N][N]={'A','G','F','K','D','G','B','E','G','H','A','E','K','J','C','E'};
	int i, j;
	//init
	// fatta in modo statico per evitare - in fase di test -
	// di inserire i dati.
	//for (i=0; i<N; i++) {
	//	for (j=0; j<N; j++) {
	//		//fflush();
	//		//scanf("%c", &a[i][j]);
	//		a[i][j]=getchar();
	//		do{
	//			//fflush();
	//			//scanf("%c", &a[i][j]);
	//			a[i][j]=getchar();
	//			if(a[i][j]<0 || a[i][j]>=VALORE_MAX){
	//				printf("errore. re-inserisci:");
	//			}
	//		}while(a[i][j]<0 || a[i][j]>=VALORE_MAX);
	//	}
	//} 
	//stampa
	for (i=0; i<N; i++) {
		for (j=0; j<N; j++) {
			printf("%c ", a[i][j]);
		}
		printf("\n");
	}
	//modifica	
	for (i=0; i<N; i++) {
		for (j=0; j<N; j++) {
			if (a[i][j]>='F' && a[i][j]<='I') { a[i][j]='Z'; }
		}
	}
	printf("\n---------------------\n");
	//stampa
	for (i=0; i<N; i++) {
		for (j=0; j<N; j++) {
			printf("%c ", a[i][j]);
		}
		printf("\n");
	}
	//system("PAUSE");
	return 0;
}
