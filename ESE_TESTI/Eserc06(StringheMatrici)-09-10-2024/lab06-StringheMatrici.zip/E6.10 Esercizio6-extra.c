/*
Inserire da tastiera in un array bidimensionale denominato 
M(4x4) dei valori (compresi tra 0 e VALORE_MAX-1).
Verificare se esistono 2 numeri consecutivi uguali tra loro 
(esempio M[0][1] e M[0][2], in caso affermativo stampare il valore.
Verificare se esistono 2 numeri consecutivi 
la cui somma � pari a 5 (esempio M[1][2]+M[1][3]), 
in caso affermativo stamparne il valore.
*/
#include <stdio.h>
#define N 4
#define VALORE_MAX 10
int main(){
	int a[N][N]={0,3,3,1,4,9,1,4,3,8,5,8,1,2,4,8};
	int i, j, x, primo; 
	//init
	// fatta in modo statico per evitare - in fase di test -
	// di inserire i dati.
	//for (i=0; i<N; i++) {
	//	for (j=0; j<N; j++) {
	//		do{
	//			scanf("%d", &a[i][j]);
	//			if(a[i][j]<0 || a[i][j]>=VALORE_MAX){
	//				printf("errore. re-inserisci:");
	//			}
	//		}while(a[i][j]<0 || a[i][j]>=VALORE_MAX);
	//	}
	//}
	//stampa
	for (i=0; i<N; i++) {
		for (j=0; j<N; j++) {
			printf("%2d", a[i][j]);
		}
		printf("\n");
	}
	// cerca valori uguali adiacenti 
	/*
	// orizzontale
	for (i=0; i<N; i++) {
		for (j=0; j<N-1; j++) {
			if(a[i][j]==a[i][j+1]){
				printf("%d in pos %d %d\n", a[i][j], i, j);
			}
		}
	}
	// verticale
	for (i=0; i<N-1; i++) {
		for (j=0; j<N; j++) {
			if(a[i][j]==a[i+1][j]){
				printf("%d in pos %d %d\n", a[i][j], i, j);
			}
		}
	}
	*/
	// verticale e orizzontale
	for (i=0; i<N; i++) {
		for (j=0; j<N; j++) {
			if((i+1<N && a[i][j]==a[i+1][j]) || (j+1<N && a[i][j]==a[i][j+1])){
				printf("%d in pos %d %d\n", a[i][j], i, j);
			}
		}
	}
	printf("\n---------------------\n");
	// cerca valori adiacenti la cui somma � 5
	for (i=0; i<N; i++) {
		for (j=0; j<N; j++) {
			if((j+1<N && a[i][j]+a[i][j+1]==5) || (i+1<N && a[i][j]+a[i+1][j]==5)){
				printf("%d in pos %d %d\n", a[i][j], i, j);
			}
		}
	}
	//system("PAUSE");
	return 0;
}
