/*
Date due matrici A e B, calcolare e stampare la somma A+B.
*/
#include <stdio.h>
#define NR 3
#define NC 3

int main (int argc, const char * argv[]) {

	int m1[NR][NC]={{1,3,2},{1,0,0},{1,2,2}};
	int m2[][NC]={{0,0,5},{7,5,0},{2,1,1}};
    int s[NR][NC];
	int i,j; 
	//inizializzo la matrice somma
	 for (i=0; i<NR; i++) {
		for (j=0; j<NC; j++) {
			s[i][j] = m1[i][j]+m2[i][j];
		}
	}
	//stampo la matrice somma
	for (i=0; i<NR; i++) {
		for (j=0; j<NC; j++) {
			printf("%d  ", s[i][j]);
		}
		printf("\n");
	}
	system("PAUSE");
	return 0;
}
