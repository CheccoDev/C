/*
Scrivere un programma che popola un matrice NxN (N=5) 
con valori cauali tra 0 e VAL_MAX-1.
Stampare la matrice
Stampare l�indice della riga la cui somma � massima
Stampare l�indice della colonna la cui somma � massima
*/
#include <stdio.h>
#define N 5  
#define VAL_MAX 10

int main (int argc, const char * argv[]) {
	int mat[N][N]; //valori tra 0 e VALORE_MAX 
	int i, j;
	int i_max, j_max, somma_max, somma;
	/* Inizializzazione occorrenze di ogni possibile valore */
	for(i=0; i<N ; i++){
		for(j=0 ; j<N ; j++){
			mat[i][j]=rand()%VAL_MAX;
		} 
    }
	/* stampa  */
	for(i=0; i<N ; i++){
		for(j=0 ; j<N ; j++){
			printf("%d ", mat[i][j]);
		}
		printf("\n");
    }
    /* riga con somma massima */
    i_max = 0;
    somma_max = 0;
    for(j=0 ; j<N ; j++){
    	somma_max += mat[i_max][j];
	}
    for(i=1; i<N ; i++){
		somma=0;
		for(j=0 ; j<N ; j++){
			somma += mat[i][j];
		}
		if(somma > somma_max){
			i_max = i;
			somma_max = somma;
		}
    }
    printf("riga max: %d (%d)\n", i_max, somma_max);
    /* colonna con somma massima */
    j_max = 0;
    somma_max = 0;
    for(i=0 ; i<N ; i++){
    	somma_max += mat[i][j_max];
	}
    for(j=1; j<N ; j++){
		somma=0;
		for(i=0 ; i<N ; i++){
			somma += mat[i][j];
		}
		if(somma > somma_max){
			j_max = j;
			somma_max = somma;
		}
    }
	printf("colonna max: %d (%d)\n", j_max, somma_max);
    
	system("PAUSE");
	return 0;
}
