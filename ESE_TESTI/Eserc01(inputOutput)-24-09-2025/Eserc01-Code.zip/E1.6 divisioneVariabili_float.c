#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  float d1, d2;
  float ris;
  printf("dividendo? ");
  scanf("%f", &d1);
  printf("divisore? ");
  scanf("%f", &d2);
  ris = d1/d2;
  printf("la divisione tra %f e %f vale %f\n", d1, d2, ris);
  
  system("PAUSE");	
  return 0;
}
