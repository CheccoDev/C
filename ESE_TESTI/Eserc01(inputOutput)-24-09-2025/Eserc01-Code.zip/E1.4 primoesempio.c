#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  //dichiarazione variabili
  int a;
  //inizializzazione variabili
  a = 5.99999999;

  //visualizzazione contenuto variabile
  printf("primo esercizio!\n");
  printf("valore di a=%d \n",a);
  
  /*utilizzo variabile
   a = a / 2; 
  */
  a = a / 2;
  //visualizzazione contenuto variabile
  printf("valore di a=%d \n",a);
  
  printf("fine esercizio\n");
  
  system("PAUSE");	
  return 0;
}
