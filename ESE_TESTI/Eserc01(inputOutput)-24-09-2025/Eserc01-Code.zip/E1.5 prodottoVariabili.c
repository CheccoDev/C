#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  int x,y,z;
  printf("Valore di x?\n");
  scanf("%d",&x);
  printf("Valore di y?\n");
  scanf("%d",&y);
  z=x*y;
  printf("il prodotto di %d * %d e': %d\n",x,y,z);
  system("PAUSE");	
  return 0;
}