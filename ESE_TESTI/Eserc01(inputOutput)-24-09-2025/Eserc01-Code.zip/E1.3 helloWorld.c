#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  printf("primo esempio codice C\n");
  printf("seconda riga\n");
  system("PAUSE");	
  return 0;
}
