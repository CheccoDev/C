#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  float fah, cel, tmp;
  printf("Digitare la temperatura in Fahrenheit: ");
  scanf("%f", &fah);
  tmp = 5.0/9.0;
  // tmp = (float)5/9;
  // tmp = 5/(float)9;
  // attenzione: non si usa
  // tmp = 5/9;
  cel = tmp * (fah - 32.0);
  printf("Il valore in Celsius di %f e' %f\n",fah, cel); 
  system("PAUSE");	
  return 0;
}
