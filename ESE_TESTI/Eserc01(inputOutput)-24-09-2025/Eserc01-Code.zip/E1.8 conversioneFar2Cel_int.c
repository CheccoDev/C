// codice errato per utilizzo di valori int e non float
// per memorizzare i risultati delle operazioni
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  int fah, cel, tmp;
  printf("Digitare la temperatura in Fahreneit: ");
  scanf("%d", &fah);
  tmp = 5/9;
  printf("attenzione: 5/9 = %d\n", tmp);
  cel = tmp * (fah - 32.0);
  printf("Il valore in Celsius di %d e' %d\n", fah, cel); 
  system("PAUSE");	
  return 0;
}
