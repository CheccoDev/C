#include <stdio.h>
#include <stdlib.h>

int main()
{
  int d1, d2;
  int ris;
  float fris;
  printf("dividendo? ");
  scanf("%d", &d1);
  printf("divisore? ");
  scanf("%d", &d2);
  ris = d1/d2;
  printf("la divisione (int) tra %d e %d vale %d\n", d1, d2, ris);
  //N.B. sccivendo:
  //fris = d1/d2; 
  //il risultato d1/d2 viene convertito in intero (troncato!) dal compilatore,
  fris = (float)d1/d2;
  // oppure
  // fris = d1/(float)d2;
  printf("la divisione (float) tra %d e %d vale %f\n", d1, d2, fris);
  
  system("PAUSE");	
  return 0;
}
