#include <iostream>
#include <ctime>
#include <bits/stdc++.h>
#define N 10
using namespace std;
typedef struct Tdato{
  int dato; 
  char *c;
}Tdato;

int random(int min, int max);

int main (int argc, char * const argv[]) {
	Tdato v1[N];	//Allocazione statica nello stack
	Tdato *v2;
	v2 = NULL;
	v2 = new Tdato[N]; //Allocazione dinamoca nell'heap
	srand (time(0));
	//inizializzazione v1 valori random
	for(int i=0; i<N ; i++){
		v1[i].dato = random(1,9);
		v1[i].c = new char[20];
		strcpy(v1[i].c, "abcd"); //necessaria libreria #include <bits/stdc++.h>
		//v1[i].c = "abcd";
		//[Warning] deprecated conversion from string constant to 'char*'
		//in genere si usa la libreria string!!
	}
	//inizializzazione v2 valori random (identica a v1!!!!)
	for(int i=0; i<N ; i++){
		v2[i].dato = random(1,9);
		v2[i].c = new char[20];
		v2[i].c = "abcd";
	}

	//stampa v1
	for(int i=0; i<N ; i++){
		cout << v1[i].dato << "[" << v1[i].c << "]" << endl;
	}
	//stampa v2
	for(int i=0; i<N ; i++){
		cout << v2[i].dato << "[" << v2[i].c << "]" << endl;
	}	
	
	//inizializzazione v1 valori "da tastiera"
	for(int i=0; i<N ; i++){
		//inizializzazione array v1 da tastiera (C++)
		cout << "v1 dato="; cin >> v1[i].dato;
		cout << "v1 c=";    fflush(stdin);  //cin >> v1[i].c;
		gets(v1[i].c); /* se vogliamo anche spazi */
	}

	//deallocazione
	for(int i=0; i<N; ++i){
		delete [] v1[i].c;
	}
	for(int i=0; i<N; ++i){
		delete [] v2[i].c;
	}
	delete [] v2;
		
	system("PAUSE");
    //getchar(); //oppure alternativamente
    return 0;
}

int random(int min, int max){
	return rand()%(max-min+1)+min;
}
