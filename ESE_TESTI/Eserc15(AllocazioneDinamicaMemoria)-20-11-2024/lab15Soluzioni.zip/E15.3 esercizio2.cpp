#include <iostream>
#include <ctime>
#define N 10
using namespace std;

int random(int min, int max);

int main (int argc, char * const argv[]) {
	char v1[N];	//Allocazione statica nello stack
	char *v2;
	v2 = NULL;
	v2 = new char[N]; //Allocazione dinamoca nell'heap
	srand (time(0));
	//inizializzazione v1
	for(int i=0; i<N-1 ; i++){
	  v1[i] = random('a','z');
	  //forme alternative valide 
	  *( v1+i ) = random('a','z');
	  *( i+v1 ) = random('a','z');
	  i[v1] = random('a','z');
	}
	v1[N-1]='\0';
	//inizializzazione v2 (identica a v1!!!!)
	for(int i=0; i<N-1 ; i++){
	  v2[i] = random('a','z');
	  //forme alternative valide 
	  *( v2+i ) = random('a','z');
	  *( i+v2 ) = random('a','z');
	  i[v2] = random('a','z');
	}
	v2[N-1]='\0';
	//stampa v1 (� possibile usare la forma usata per stampare v2)
	for(int i=0; i<N ; i++){
		//stampa modalita C
		printf("[%c]",v1[i]);
	}
	printf("\n");
	
	//inizializzazione array v1 da tastiera (C)
	printf("v1="); fflush(stdin); scanf("%s",v1);	
	//gets(v1) /* se vogliamo anche spazi */
	//inizializzazione array v2 da tastiera (C++)
	cout << "v2="; fflush(stdin);  cin >> v2;
	//gets(v2) /* se vogliamo anche spazi */
		
	//stampa v2 (� possibile usare la forma usata per stampare v1)
	//NOTA vengono stampati tutti i valori dell'array anche se NON inizializzati
	for(int i=0; i<N ; i++){
		//forma alternativa valida per la stampa (C++) 
		cout << "[" << v2[i] << "]";
	}
	cout << endl;	
	//stampa intero array di caratteri (2 forme equivalenti)
	//NOTA vengono stampati solo i valori dell'array inizializzati
	printf("[%s]\n",v1);
	cout << "[" << v2 << "]" << endl;

	delete[] v2;
	// delete v2
	
	#include <string>
	string v3;
	cout << "v3="; fflush(stdin);  cin >> v3;
	cout << "[" << v3 << "]" << endl;
		
	system("PAUSE");
    //getchar(); //oppure alternativamente
    return 0;
}

int random(int min, int max){
	return rand()%(max-min+1)+min;
}
