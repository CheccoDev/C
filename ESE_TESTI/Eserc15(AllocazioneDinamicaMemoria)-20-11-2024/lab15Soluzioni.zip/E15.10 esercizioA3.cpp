#include <cstdlib>
#include <iostream>
#define LEN 10

using namespace std;
//calcolo la lunghezza della sequenza di char in memeoria
int mystrlen(char* s){
	int len=0;
	while(s[len]){len++;}   
	return len;
}

int main(int argc, char * const argv[]) {
    char* s1="Stringa1";
    char s2[100];
    char s3[100];
    char s4[]="Stringa4";
    char* s5;
    char* s6;
    int i;
	
	// s2 array
	for(i=0 ; i<LEN ; i++)
		s2[i]='a'+i;
	// s3 stringa
	for(i=0 ; i<LEN ; i++)
		s3[i]='a'+i;
    s3[i]='\0';
	// s5 array
	s5 = new char[100];
	for(i=0 ; i<LEN ; i++)
		s5[i]='a'+i;
	// s6 stringa
	s6 = new char[100];
	for(i=0 ; i<LEN ; i++)
		s6[i]='a'+i;
    s6[i]='\0';
    
    printf("\nStringhe\n");
    printf("s1: %s\n", s1);
    printf("s2: %s\n", s2);
    printf("s3: %s\n", s3);
    printf("s4: %s\n", s4);
    printf("s5: %s\n", s5);
    printf("s6: %s\n", s6);
	printf("\nLunghezze\n");
	printf("s1: %d\n", mystrlen(s1));
	printf("s2: %d\n", mystrlen(s2));
	printf("s3: %d\n", mystrlen(s3));
	printf("s4: %d\n", mystrlen(s4));
	printf("s5: %d\n", mystrlen(s5));
	printf("s6: %d\n", mystrlen(s6));
		
	delete s5;  
	delete s6;	
	//system("PAUSE");
	getchar();	
	return 0;
}
