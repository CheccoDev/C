#include <iostream>
#include <ctime>
#define N 10
using namespace std;

int random(int min, int max);

int main (int argc, char * const argv[]) {
	int v1[N];	//Allocazione statica nello stack
	int *v2;
	v2 = NULL;
	v2 = new int[N]; //Allocazione dinamoca nell'heap
	srand (time(0));
	//inizializzazione v1
	for(int i=0; i<N ; i++){
	  v1[i] = random(1,9);
	  //forme alternative valide 
	  *( v1+i ) = random(1,9);
	  *( i+v1 ) = random(1,9);
	  i[v1] = random(1,9);
	}
	//inizializzazione v2 (identica a v1!!!!)
	for(int i=0; i<N ; i++){
	  v2[i] = random(1,9);
	  //forme alternative valide 
	  *( v2+i ) = random(1,9);
	  *( i+v2 ) = random(1,9);
	  i[v2] = random(1,9);
	}
	//stampa v1 (� possibile usare la forma usata per stampare v2)
	for(int i=0; i<N ; i++){
		//stampa modalita C
		printf("[%d]",v1[i]);
	}
	printf("\n");
	//stampa v2 (� possibile usare la forma usata per stampare v1)
	for(int i=0; i<N ; i++){
		//forma alternativa valida per la stampa (C++) 
		cout << "[" << v2[i] << "]";
	}
	cout << endl;	

	delete[] v2;
	// delete v2
	system("PAUSE");
    //getchar(); //oppure alternativamente
    return 0;
}

int random(int min, int max){
	return rand()%(max-min+1)+min;
}
