#include <iostream>
#include <cstdlib>

#define MAX 50
#define NOME_F1 "file1.dat"
#define NOME_F2 "file2.dat"

using namespace std;

void popola(int *a, int dim);

int main (int argc, char * const argv[]) {
    FILE *fp1, *fp2;
	int a1len=0, i, offset;
	int array2[MAX];
	
	/***************************
		Array1
	*/
	do {
		printf("\nQuale lunghezza deve avere l'array1 (min 1 max %d)? ", MAX);
		scanf("%d",&a1len);
	} while (a1len<1 || a1len>MAX);
	// allocazione dinamica array1
	int *array1 = new int[a1len];
	popola(array1, a1len);
	if ((fp1=fopen(NOME_F1, "wb"))==NULL) {
		printf("\nErrore apertura file %s", NOME_F1);
		//system("PAUSE");
		getchar();
		exit(1);
	}
	fwrite(array1, sizeof(int), a1len, fp1);
	/*
	if(fwrite(array1, sizeof(int), a1len, fp1)!= a1length) {
		fprintf(stderr,"\n Errore di scrittura sul file %s\n", NOME_F1);
		//system("PAUSE");
		getchar();
		exit(1);
	}
	*/
	fclose(fp1);
	
	/***************************
	 Array2
	*/
	for (i=0; i<MAX; i++) {
		array2[i] = i*10;
	}
	if((fp2 = fopen(NOME_F2, "wb"))==NULL) {
		printf("Errore di apertura del file %s\n", NOME_F2);
		//system("PAUSE");
		getchar();
		exit(1);
	}
	if(fwrite(array2, sizeof(int), MAX, fp2)!= MAX) {
		printf("\n Errore di scrittura sul file %s\n", NOME_F2);
		//system("PAUSE");
		getchar();
		exit(1);
	}
	fclose(fp2);
	
	/***************************
	 Lettura elementi da array1 e array2
	*/
	if((fp1 = fopen(NOME_F1, "rb"))==NULL) {
		printf("Errore di apertura del file %s\n", NOME_F1);
		//system("PAUSE");
		getchar();
		exit(1);
	}
	if((fp2 = fopen(NOME_F2,"rb"))==NULL) {
		printf("Errore di apertura del file %s\n", NOME_F2);
		//system("PAUSE");
		getchar();
		exit(1);
	}
	
	do {
		printf("\nInserisci quale elemento vuoi leggere nei file, tra 0-%d, oppure -1 per uscire: ",MAX-1);
		scanf("%d",&offset);
		// check su file1
		if (offset>=0 && offset<a1len) {
			if (fseek(fp1, sizeof(int)*offset, SEEK_SET) != 0) {
				printf("\nErrore in fseek su file %s", NOME_F1);
				//system("PAUSE");
				getchar();
				exit(1);
			}
			fread(&i, sizeof(int), 1, fp1);
			printf("\nL'elemento %d in file %s vale %d", offset, NOME_F1, i);
		}else {
			printf("\nIl file %s ha dimensione minore", NOME_F1);
		}
		// check su file2
		if (offset>=0 && offset<MAX) {
			if (fseek(fp2, sizeof(int)*offset, SEEK_SET) != 0) {
				printf("\nErrore in fseek su file %s", NOME_F2);
				//system("PAUSE");
				getchar();
				exit(1);
			}
			fread(&i, sizeof(int), 1, fp2);
			printf("\nL'elemento %d in file %s vale %d", offset, NOME_F2, i);
		}else {
			printf("\nIl file %s ha dimensione minore", NOME_F2);
		}
	} while (offset>=0);
	fclose(fp1);
	fclose(fp2);
	
	getchar();
    return 0;
}

void popola(int *a, int dim){
	int i;
	for (i=0; i<dim; i++) {
		a[i]=rand()%(10*MAX);
	}
}