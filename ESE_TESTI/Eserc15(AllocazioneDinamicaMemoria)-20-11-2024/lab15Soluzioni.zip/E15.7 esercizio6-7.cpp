#include <cstdlib>
#include <iostream>
#define N 10
using namespace std;
typedef struct{
  int k; 
  char c;
}Tdato;
typedef struct{
  int n; 
  Tdato *p;
}Tnodo;
int random(int min,int max){
   return rand()%(max-min+1)+min;   
}
int main(){
  int dim;
  //Tnodo v[N];				//esercizio 6
  Tnodo *v= new Tnodo[N];	//esercizio 7
  for(int i=0; i<N; i++){
     dim = random(2,8);
     v[i].n = dim; 
     v[i].p = new Tdato[dim];      
  }
  //inizializzo array p
  for(int i=0; i<N; i++){
     for(int j=0; j<v[i].n; j++){
        v[i].p[j].c = random('a','z');
        v[i].p[j].k = random(0,99);      
     }        
  }
  //stampa
  for(int i=0; i<N; i++){
     for(int j=0; j<v[i].n; j++){
       printf("[%c,%d]",v[i].p[j].c, v[i].p[j].k);
     }
     printf("\n");
   }
  //disallocazione
  for(int i=0; i<N; i++){
     delete[] v[i].p;     
  }
  delete[] v;
  system("PAUSE");  return EXIT_SUCCESS;
}
