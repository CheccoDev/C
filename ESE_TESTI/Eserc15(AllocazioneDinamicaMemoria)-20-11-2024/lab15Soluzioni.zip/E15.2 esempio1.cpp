#include <iostream>

using namespace std;

typedef struct{
	char* s;
} s1;


int main (int argc, char * const argv[]) {
	s1 elem;
	elem.s = new char[10];
	printf("elem.s="); scanf("%s",elem.s);
	printf("elem.s=%s\n",elem.s);
	printf("dim char: %d\n",(int)sizeof(char));
	printf("dim char*: %d\n",(int)sizeof(char*));
	printf("dim s1: %d\n",(int)sizeof(s1)); 
	printf("dim elem: %d\n",(int)sizeof(elem));
	printf("dim elem.s: %d\n",(int)sizeof(elem.s));
	
	delete elem.s;
            	
	int v1[10]; //allocato nello stack
	int* v2;    //variabile nello stack
	v2 = new int[10]; //allocato nell'heap
	printf("dim int: %d\n",(int)sizeof(int)); 
	printf("dim int*: %d\n",(int)sizeof(int*));
    printf("dim v1: %d\n",(int)sizeof(v1));
	printf("dim v2: %d\n",(int)sizeof(v2));

    delete v2;
	system("PAUSE");
    //getchar(); //oppure alternativamente
    return 0;
}
