#include <iostream>
#include <stdio.h>
#include <cstdlib>
using namespace std;

#define N 3
#define C 5

int main() {
  char temp[101];
  char **dizionario;
  dizionario = new char*[N];
  system("PAUSE");

  int lunghezza;

  for(int i=0; i<N; i++){
    lunghezza = 0;  
    printf("inserire una stringa: ");
    fflush(stdin); scanf("%s", temp);
    //calcolo della lughezza
    while(temp[lunghezza] !='\0'){lunghezza++;}
    //alloco una spazio adeguato per la stringa
    dizionario[i] = new char[lunghezza+1];
    for(int k=0; k<=lunghezza; k++){
      dizionario[i][k] = temp[k];
    }
    //printf("%s\n", dizionario[i]);
  } 

  for(int i=0; i<N; i++){
    printf("%s\n", dizionario[i]);
  }
  
  //dealloco
  for(int i=0; i<N; i++){
    delete [] dizionario[i];
  }

  delete[] dizionario;

}

