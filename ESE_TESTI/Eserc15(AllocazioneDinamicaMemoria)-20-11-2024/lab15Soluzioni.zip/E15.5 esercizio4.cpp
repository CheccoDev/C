#include <iostream>
#include <stdio.h>
#include <cstdlib>
using namespace std;

#define R 10
#define C 5

int main() {
  int **m;
  //*m = new int[C];  //indirizzi array orrizontale
  m = new int*[C];  //indirizzi array orrizontale
  for(int i=0; i<C; i++){ 
    m[i] = new int[R]; //indirizzo array verticale
  }

  //init
  for(int i=0; i<C; i++){
    for(int j=0; j<R; j++){
       m[i][j]= rand()%(9-1+1)+1;
       //m[i] � l'indirizzo dell'array verticale
       //m[i][j] scorro i valori delle array verticali
    }
  } 

  //stampo
  for(int i=0; i<C; i++){
    for(int j=0; j<R; j++){
       cout << m[i][j] << " "; 
    }
    cout << endl;
  } 

  //dealloco
  for(int i=0; i<C; i++){
    delete [] m[i];
  }

  delete [] m;
  system("PAUSE");
}
