#include <iostream>

using namespace std;

typedef struct{
	char* nome;
	char codice[6];
}tAzienda;
typedef struct{
	tAzienda v[100];
	int n_aziende;
}tDB;

void inizializza_database(tDB* pdb);
void inizializza_azienda(tAzienda* pa, char* nome, char* codice);
void aggiungi_azienda(tDB* p, char* nome, char* codice);
void cancella_database(tDB* p);
void stampa(tDB elem);
void salva_su_file(tDB elem, char* nome_file);
void salva_su_file_b(tDB elem, char* nome_file);

int main (int argc, char * const argv[]) {
    tDB database;
    char buffer[100];
    char codice[6];
    int i=0;
	
    inizializza_database(&database);
    while(i<5){  
		printf("Nome azienda: ");
		gets(buffer);
		printf("Codice azienda (5 caratteri): ");
		gets(codice);
		aggiungi_azienda(&database, buffer, codice);
		i++;
    }
	
	stampa(database);
	
    printf("Nome file:");
    scanf("%s", buffer);
    salva_su_file(database, buffer);
	
	printf("Nome file:");
    scanf("%s", buffer);
    salva_su_file_b(database, buffer);
	
    cancella_database(&database);

	//system("PAUSE");
	getchar();
    return 0;
}

void inizializza_database(tDB* pdb){
	pdb->n_aziende=0;
}
void inizializza_azienda(tAzienda* pa, char* nome, char* codice){
	pa->nome = new char[strlen(nome)];
	strcpy(pa->nome, nome);
	strcpy(pa->codice, codice);
}
void aggiungi_azienda(tDB* p, char* nome, char* codice){
	inizializza_azienda(&(p->v[p->n_aziende]), nome, codice);
	p->n_aziende++;
}
void cancella_database(tDB* p){
	int i;
	for (i=0; i<p->n_aziende; i++) {
		delete p->v[i].nome;
	}
}
void stampa(tDB e){
	int i;
	for (i=0; i<e.n_aziende; i++) {
		printf("%s - %s\n", e.v[i].nome, e.v[i].codice);
	}
}
void salva_su_file(tDB e, char* nome_file){
	FILE* fp;
	int i;
	if ((fp=fopen(nome_file, "w"))==NULL) {
		printf("\nErrore apertura file\n");
		return;
	}
	for (i=0; i<e.n_aziende; i++) {
		fprintf(fp, "%s %s\n", e.v[i].nome, e.v[i].codice);
	}
	fclose(fp);
}
void salva_su_file_b(tDB e, char* nome_file){
	FILE* fp;
	if ((fp=fopen(nome_file, "wb"))==NULL) {
		printf("\nErrore apertura file\n");
		return;
	}
	fwrite(e.v, sizeof(tAzienda), 5, fp);
	fclose(fp);
}