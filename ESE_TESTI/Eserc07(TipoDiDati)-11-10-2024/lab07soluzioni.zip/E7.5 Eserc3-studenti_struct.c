#include <stdio.h>
#include <stdlib.h>

#define NUM_STUDENTI 3
#define NUM_ESAMI 4
#define NUM_CAR 50

typedef struct Tstudente{
	char cognome[NUM_CAR];
	char nome[NUM_CAR];
	int esami[NUM_ESAMI];
}Tstudente;

int main (int argc, const char * argv[]) {
	Tstudente studente[NUM_STUDENTI];
	int somma, i, j;
	float media, sommamedie;
	for (i = 0; i < NUM_STUDENTI; i++){
		printf("\t***Inserimento dati studenti***\n");
		printf("Inserisci il cognome dello studente:\t");
		scanf("%s",studente[i].cognome); //gets(studente[i].cognome)
		printf("Inserisci il nome dello studente:\t");
		scanf("%s",studente[i].nome);   //gets(studente[i].nome)
		
		for (j = 0; j < NUM_ESAMI; j++){
			printf("Inserire il voto dell'esame %d:", j);
			scanf("%d", &studente[i].esami[j]);
			//studente[i].esami[j] = rand()%(30-18+1)+18;
		}
	}
	/*Analisi dei dati*/
	/* Media di ogni studente*/
	sommamedie = 0;
	for (i = 0; i < NUM_STUDENTI; i++) {
		somma = 0;
		for (j = 0; j < NUM_ESAMI; j++)
			somma += studente[i].esami[j];
		media = (float)somma / NUM_ESAMI;
		sommamedie += media;
		printf("La media di %s e' %f\n", studente[i].cognome, media);
	};
	printf("La media delle medie e' %f\n", sommamedie/NUM_STUDENTI);
	
    /* Media di ogni esame */
	for (i = 0; i < NUM_ESAMI; i++) {
		somma = 0;
		for (j = 0; j < NUM_STUDENTI; j++)
			somma += studente[j].esami[i];
		media = (float)somma / NUM_ESAMI;
		printf("La media dell'esame %d e' %f\n", i, media);
	}
	
	system("PAUSE");
	return 0;
}
