#include <stdio.h>
#include <stdlib.h>

#define NUM_STUDENTI 10
#define NUM_ESAMI 20
#define NUM_CAR 50

typedef char Stringa[LEN_MAX_STR];
typedef int Esami[NUM_ESAMI];
typedef struct Tstudente {
	Stringa cognome;
	Stringa nome;
	Esami esami;
}Tstudente;

int main (int argc, const char * argv[]) {
	Tstudente studente[NUM_STUDENTI];
	int somma, i, j, esamifatti;
	float media, sommamedie;
	
	/* Inizializzare/Azzerare struttura dati */
	for (i = 0; i < NUM_STUDENTI; i++) {
		for(j=0 ; j<NUM_ESAMI ; j++){
			studente[i].esami[j] = 0;
		}
	}
	printf("\t***Inserimento dati studenti***\n");
	for (i = 0; i < NUM_STUDENTI; i++) {
		studente[i].cognome[0] = rand()%('Z'-'A'+1)+'A';
		studente[i].cognome[1] = rand()%('z'-'a'+1)+'a';
		studente[i].cognome[2] = '\0';
		studente[i].nome[0] = rand()%('Z'-'A'+1)+'A';
		studente[i].nome[1] = rand()%('z'-'a'+1)+'a';
		studente[i].nome[2] = '\0';
		
		esamifatti = rand()%NUM_ESAMI;
		for(j=0 ; j<esamifatti ; j++){
			studente[i].esami[j] = rand()%(30-18+1)+18;
		}
	}
	/* Stampa struttura dati */
	for (i = 0; i < NUM_STUDENTI; i++) {
        printf("%s %s \n voti:", studente[i].cognome, studente[i].cognome);
		for(j=0 ; j<NUM_ESAMI ; j++){
			printf("%3d", studente[i].esami[j]);
		}
		printf("\n");
	}

	/* Analisi dei dati */
	/* Media di ogni studente */
	sommamedie = 0;
	for (i = 0; i < NUM_STUDENTI; i++) {
		somma = 0;
		esamifatti = 0;
		for (j = 0; j < NUM_ESAMI; j++){
			if (studente[i].esami[j] != 0) {
				esamifatti++;
				somma += studente[i].esami[j];
			}
		}
		if (somma == 0) {
			media = 0;
		}else {
			media = (float)somma / esamifatti;
		}
		sommamedie += media;
		printf("La media di %s e' %f\n", studente[i].cognome, media);
	}
	printf("La media delle medie e' %f\n", sommamedie/NUM_STUDENTI);
	
	/* Media di ogni esame */
	for (i = 0; i < NUM_ESAMI; i++) {
		somma = 0; 
		esamifatti = 0;
		for (j = 0; j < NUM_STUDENTI; j++)
			if (studente[j].esami[i] != 0) {
				somma += studente[j].esami[i];
				esamifatti++;
			}
		if (somma == 0) {
			media = 0;
		}else {
			media = (float)somma / esamifatti;
		}
		printf("La media dell'esame %d e' %f\n", i, media);
	}
	
    system("PAUSE");	 // o fare uno scanf("%d", &i); per i s.o. che non permettono il comando system
	return 0;
}
