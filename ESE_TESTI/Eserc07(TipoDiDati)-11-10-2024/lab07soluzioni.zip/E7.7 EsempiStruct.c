#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
	
	/*Dichiaro direttamente la struttura e quali sono le variabili che 
	  hanno quella struttura non posso per� creare nuove variabili con 
	  la stessa struttura in altre parti del codice, perch� non c'� un 
	  riferimento per richiamarla*/
	struct {
		char nome[30];
		char cognome[30];
	} persona_1, persona_2;

	/* Dichiaro direttamente la struttura e quali sono le variabili che 
	   hanno quella struttura. Assegno anche un nome alla struttura 
	   (Persona) Posso creare nuove variabili con la stessa struttura in 
	   altre parti del codice, perch� c'� un riferimento per richiamarla*/
	struct Persona {
		char nome[30];
		char cognome[30];
	} persona_3, persona_4;

	struct Persona persona_5, persona_6;

	/* Dichiaro direttamente la struttura e gli assegno un alias (Punto)
	   Posso creare nuove variabili usando l'alias creato, ma non posso 
	   creare nuovi alias usando la stessa struttura perch� la struttura
	   non ha un riferimento per richiamarla*/
	typedef struct{
		float x;
		float y;
	} Punto;
	
	Punto punto_1, punto_2;

	/* Dichiaro direttamente la struttura, gli assegno un nome (Retta) e 
	   gli assegno un alias (AliasRetta)
	   Posso creare nuove variabili usando l'alias creato, e posso creare 
	   nuovi alias usando la stessa struttura perch� ha un riferimento per 
	   richiamarla*/	
	typedef struct Retta {
		float m;
		float q;
	} AliasRetta;
	// ------------------------------------------------------
	AliasRetta retta_1, retta_2;

	typedef struct Retta DoppiaLinea[2];

	typedef AliasRetta TriplaLinea[3];

	DoppiaLinea doppia_1, doppia_2;
	TriplaLinea tripla_1, tripla_2;
}
