#include <stdio.h>
#include <stdlib.h>

#define NUM_STUDENTI 3
#define NUM_ESAMI 4

int main (int argc, const char * argv[]) {
	int tabella_voti[NUM_STUDENTI][NUM_ESAMI];
	int studente, esame;
	int somma;
	float media;
	/* Inserimento dati */
	for (studente = 0; studente < NUM_STUDENTI; studente++){
		printf("Inserimento dati studente %d\n", studente);
		for (esame = 0; esame < NUM_ESAMI; esame++){
			printf("Inserire il voto dell'esame %d:", esame);
			//scanf("%d", &tabella_voti[studente][esame]);
			/* Oppure tramite numeri casuali */
			tabella_voti[studente][esame]=rand()%(30-18+1)+18;
		} 
	}
	printf("\n\n");
	/* Media di ogni studente */
	for (studente = 0; studente < NUM_STUDENTI; studente++){
		somma = 0;
		for (esame = 0; esame<NUM_ESAMI; esame++){
			somma += tabella_voti[studente][esame];
		}
		media = (float)somma / NUM_ESAMI;
		printf("Studente %d, media %f\n", studente, media);
	}
	/* Media di ogni esame */
	for (esame = 0; esame < NUM_ESAMI; esame++){
		somma = 0;
		for (studente = 0; studente<NUM_STUDENTI; studente++){
			somma += tabella_voti[studente][esame];
		}
		media = (float)somma / NUM_STUDENTI;
		printf("La media dell'esame %d e' %f\n", esame, media);
	}

	system("PAUSE");
	return 0;
}
