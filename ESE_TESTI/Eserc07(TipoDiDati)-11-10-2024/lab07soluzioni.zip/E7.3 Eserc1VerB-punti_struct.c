#include <stdio.h>
#include <stdlib.h>
#include <math.h> /*libreria matematica*/
#define NPUNTI 100
typedef struct Tpunto{
    float x, y;
} Tpunto;

int main (int argc, const char * argv[]) {
    Tpunto punti[NPUNTI];
	float x, y, dist_min, dist, deltax, deltay;
	int i, p_min;

	/* OPZIONE1 e OPZIONE2 sono alternative */
	/*OPZIONE1: inizializzazione con valori casuali */
	for(i=0 ; i<NPUNTI ; i++){
		m[i][0] = (rand()%100000)/1000.0;
		m[i][1] = 1.0*(rand()%100000)/1000;
	}
	for(i=0 ; i<NPUNTI ; i++) {
	    printf("[%f,%f]\n", m[i][0], m[i][1]);
    }
	/*OPZIONE2: inizializzazione con valori inseriti dall'utente */
	printf("coordinate [x y]");
	printf("x="); scanf("%f", &x);
	printf("y="); scanf("%f", &y);
	
	p_min=0; // definire minimo a priori
	deltax = punti[p_min].x - x;
	deltay = punti[p_min].y - y;
	dist_min = sqrt(deltax*deltax + deltay*deltay);
	for(i=1 ; i<NPUNTI ; i++){
		deltax = punti[i].x-x;
		deltay = punti[i].y-y;
		dist = sqrt(deltax*deltax + deltay*deltay);
		if(dist < dist_min){
			p_min = i;
			dist_min = dist;
		}
	}
	printf("\nPunto minima distanza: %f %f", 
		   punti[p_min].x, punti[p_min].y);

   system("PAUSE");
   return 0;
}
