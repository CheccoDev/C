#ifndef __AGENDA__
#define __AGENDA__

#define N_MAX_EVENTI 100

typedef struct { 
     int giorno;
     int mese;
     int anno;
     int ora;
     int minuti;
} TdataOra;

typedef enum {LEZIONE, PISCINA, APPUNTAMENTO, PALLAVOLO, STUDIO} Tattivita;

typedef struct {
   TdataOra inizio;
   TdataOra fine;
   Tattivita attivita;
} Tevento;

typedef struct{
   Tevento eventi [N_MAX_EVENTI];
   int n_eventi;
} Tagenda;

TdataOra inizializzaData(int anno, int mese, int giorno, int ora, int minuti);
void stampaData(TdataOra d);
void stampaAttivita(Tattivita a);
void stampaEvento(Tevento e);
void stampaAgenda(Tagenda a);
Tagenda inizializzaAgenda();
Tagenda aggiungiEvento(Tagenda a, Tevento e);
Tevento inizializzaEvento(TdataOra inizio, TdataOra fine, Tattivita attivita);

void p_aggiungiEvento(Tagenda* pa, Tevento e);
void p_stampaAgenda(Tagenda *a);
void p_inizializzaAgenda(Tagenda *a);

void cancellaUltimoEvento(Tagenda * pa);
void cancellaEvento(Tagenda * pa, int pos);
void inserisciEvento(Tagenda * pa, int pos, Tevento e);

#endif

