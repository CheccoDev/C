#include <stdio.h>
#include <stdlib.h>
#include "agenda.h"

int main(int argc, char *argv[])
{
	TdataOra d1, d2;
	Tevento e;
	Tagenda a;

	//a = inizializzaAgenda();
	p_inizializzaAgenda(&a);
	
	d1 = inizializzaData(2010,6,10,10,30);
	d2 = inizializzaData(2010,6,10,11,30);
	e = inizializzaEvento(d1,d2,PISCINA);
	//a = aggiungiEvento(a, e);
	p_aggiungiEvento(&a, e);
	
	d1 = inizializzaData(2010,6,11,14,30);
	d2 = inizializzaData(2010,6,11,16,0);
	e = inizializzaEvento(d1,d2,STUDIO);
	//a = aggiungiEvento(a, e);
	p_aggiungiEvento(&a, e);

	d1 = inizializzaData(2010,7,11,16,0);
	d2 = inizializzaData(2010,6,11,16,30);
	e = inizializzaEvento(d1,d2,APPUNTAMENTO);
	//a = aggiungiEvento(a, e);
	p_aggiungiEvento(&a, e);

	//stampaAgenda(a);
	p_stampaAgenda(&a);
	
	//cancellaUltimoEvento(&a);
	//cancellaEvento(&a,2); //provare con posizioni 1 e 2
	inserisciEvento(&a,0,e);
	p_stampaAgenda(&a);                           //

  system("PAUSE");	
  return 0;
}

