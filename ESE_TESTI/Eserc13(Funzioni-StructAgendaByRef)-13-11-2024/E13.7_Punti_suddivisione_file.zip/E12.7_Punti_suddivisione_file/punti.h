#ifndef __PUNTI__
#define __PUNTI__

#define MAX 100

typedef struct { 
    float x, y, z;
} Tpunto;

typedef struct {
   Tpunto punti[MAX];
   int dim;
} Tgrafico;

int casuale(int min, int max);
Tgrafico init();
Tpunto init_punto();
void stampa(Tgrafico a);
Tgrafico filtra(Tgrafico a, float limite);
int minore(Tpunto p, float limit);

void p_init(Tgrafico *a);
void p_init_punto(Tpunto *p);
void p_stampa(const Tgrafico *a);
Tgrafico p_filtra(const Tgrafico *a, float limite);

#endif

