#include <stdio.h>
#include <stdlib.h>
#include "punti.h"

int main(int argc, char *argv[])
{
	Tgrafico g;

/*	g = init();
	printf("\nPunti grafico\n");
	stampa(g);
	
	Tgrafico w;
	w = filtra(g, 12.25);
	printf("\nPunti filtrati\n");
	stampa(w);
*/
	p_init(&g);
	printf("\nPunti grafico\n");
	p_stampa(&g);
	
	Tgrafico w;
	w = p_filtra(&g, 12.25);
	printf("\nPunti filtrati\n");
	p_stampa(&w);
	
  	system("PAUSE");	
  	return 0;
}

