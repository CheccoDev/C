#include <stdio.h>
#include <stdlib.h>

const massimo = 100;

int main(int argc, char *argv[]){
	int valore, tentativo, indovinato, n, n_tentativo, continua, max_tentativi;
	max_tentativi=10;
	continua=1;
	  
	while(continua){
	  do {
		  printf("Inserisci il valore da indovinare (max %d)\n", massimo);
		  scanf("%d", &valore);
	  } while (valore > massimo);
	  system("CLS");

	  indovinato = 0;
	  n=0;
	
	  while (!indovinato && n<max_tentativi){
		  printf("Indovina il numero\n");
		  scanf("%d", &tentativo);
		  if (tentativo == valore){
			  printf("Non ci posso credere ;-) hai indovinato!\n");
			  indovinato = 1;
		  } else {
			  if (tentativo > valore){ 
				  printf("Il numero da indovinare e' piu' piccolo\n"); 
			  } else { 
				  printf("Il numero da indovinare e' piu' grande\n"); 
			  }
		  } 
		  n_tentativo++;
	  }
	  
	  if( !indovinato ) {
	    printf("Il numero era: %d\n", val);
	  }
	    
      printf("continua? 0:no, 1:si"); scanf("%d", &continua);
	}
	
	system("PAUSE");	
	return 0;
}



