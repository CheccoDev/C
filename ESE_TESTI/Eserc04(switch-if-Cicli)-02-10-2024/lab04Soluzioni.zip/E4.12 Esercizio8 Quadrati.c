#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]){
	int riga, colonna, n;
	printf("inserire il numero N\n");
	scanf("%d", &n);
	
	riga = 1;
	while (riga <= n){
		colonna = 1;
		while (colonna <= n){
			printf("x ");
			colonna = colonna + 1;
		}
		printf("\n");
		riga = riga + 1;
	}
	
/*
	riga = 0;
	while (riga < n){
		colonna = 0;
		while (colonna < n){
			printf("1 ");
			colonna = colonna + 1;
		}
		printf("\n");
		riga = riga + 1;
	}	
*/	
	
	printf("\n------------------------\n");
	riga=0;
	while (riga < n){
		colonna = 0;
		while (colonna < n){
			if(riga==colonna){
				printf("+ ");
			}else{
				if(colonna>riga){
					printf("o ");
				}else{
					printf("x ");
				}
			}
			colonna++;  // colonna = colonna+1;
		}
		printf("\n");
		riga++;  // riga = riga+1;
	}
	
	system("PAUSE");	
	return 0;
}

