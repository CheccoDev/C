#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]){
  int scelta;
  printf("scelta="); scanf("%d",&scelta);
  
  if(scelta==0){
    printf("0\n");              
  }else{
    if(scelta==1){
      printf("1\n");              
    }else{
       if(scelta==2){
          printf("2\n");              
       } else{
          printf("errata\n") ;   
       }  
    }    
  }
  
  if(scelta==0){ printf("0\n"); }
  if(scelta==1){ printf("1\n"); }
  if(scelta==2){ printf("2\n"); }
  if(scelta!=0 && scelta!=1 && scelta!=2){ printf("errata\n"); }
  
  switch (scelta){
    case 0: printf("0\n"); break;  
    case 1: printf("1\n"); break;
    case 2: printf("2\n"); break;
    default: printf("errata\n");  
  }
  
  system("PAUSE");  return 0;
}
