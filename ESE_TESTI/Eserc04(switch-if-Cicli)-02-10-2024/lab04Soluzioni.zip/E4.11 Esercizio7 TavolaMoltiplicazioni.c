#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]){
	int righe, colonne, i_riga, i_colonna;
	printf("inserire numero di righe: ");
	scanf("%d", &righe);
	printf("inserire numero di colonne: ");
	scanf("%d", &colonne);
	
	i_riga = 1;
	while (i_riga <= righe){
		i_colonna = 1;
		while (i_colonna <= colonne){
			printf("%3d", i_riga*i_colonna);
			i_colonna = i_colonna + 1;
		}
		printf("\n");
		i_riga = i_riga + 1;
	}
	
	system("PAUSE");	
	return 0;
}

