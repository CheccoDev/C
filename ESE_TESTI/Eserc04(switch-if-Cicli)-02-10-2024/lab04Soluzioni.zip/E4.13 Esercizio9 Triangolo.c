#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]){
	int riga, colonna, limite;
	printf("inserire il numero di righe\n");
	scanf("%d", &limite);

/*
+
+ +
+ + +
+ + + +
+ + + + +
*/	
	riga = 1;
	while (riga <= limite){
		colonna = 1;
		while (colonna <= riga){
			printf("* ");
			colonna = colonna + 1;
		}
		printf("\n");
		riga = riga + 1;
	}	
	
	printf("\n------------------------\n");
	
/*
+ + + + + 
+ + + + 
+ + + 
+ + 
+ 

*/
	riga = 1;
	while (riga <= limite){
		colonna = 1;
		while (colonna <= limite - riga +1 ){
			printf("+ ");
			colonna = colonna + 1;
		}
		printf("\n");
		riga = riga + 1;
	}
	
	system("PAUSE");	
	return 0;
}

