/* input: mese numerico
output: mese letterale
*/
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]){
	int mese;
	printf("inserisci mese: "); scanf("%d",&mese);
	
	/* soluzione 1*/
	if(mese==1){
		printf("gennaio\n");
	}else{
		if(mese==2){
			printf("febbraio\n");
		}else{
			if(mese==3){
				printf("marzo\n");
			}else{
				if(mese==4){
					printf("aprile\n");
				}else{
					if(mese==5){
						printf("maggio\n");
					}else{
						if(mese==6){
							printf("giugno\n");
						}else{
							if(mese==7){
								printf("luglio\n");
							}else{
								if(mese==8){
									printf("agosto\n");
								}else{
									if(mese==9){
										printf("settembre\n");
									}else{
										if(mese==10){
											printf("ottobre\n");
										}else{
											if(mese==11){
												printf("novembre\n");
											}else{
												if(mese==12){
													printf("dicembre\n");
												}else{
													printf("????\n");
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	
	/* soluzione 2*/
	if(mese==1){
		printf("gennaio\n");
	}
	if(mese==2){
		printf("febbraio\n");
	}
	if(mese==3){
		printf("marzo\n");
	}
	if(mese==4){
		printf("aprile\n");
	}
	if(mese==5){
		printf("maggio\n");
	}
	if(mese==6){
		printf("giugno\n");
	}
	if(mese==7){
		printf("luglio\n");
	}
	if(mese==8){
		printf("agosto\n");
	}
	if(mese==9){
		printf("settembre\n");
	}
	if(mese==10){
		printf("ottobre\n");
	}
	if(mese==11){
		printf("novembre\n");
	}
	if(mese==12){
		printf("dicembre\n");
	}
	// if(mese!=1 && mese!=2 && mese!=3 && mese!=4 && mese!=5 && mese!=6 && mese!=7 && mese!=8 && mese!=9 && mese!=10 && mese!=11 && mese!=12){
	if(mese<1 ||  mese>12){
		printf("????\n");
	}
	
	/* soluzione 3*/
	switch(mese){
		case 1: 	printf("gennaio\n");
		case 2: 	printf("febbraio\n"); break;
		case 3: 	printf("marzo\n"); break;
		case 4: 	printf("aprile\n"); break;
		case 5: 	printf("maggio\n"); break;
		case 6: 	printf("giugno\n"); break;
		case 7: 	printf("luglio\n"); break;
		case 8: 	printf("agosto\n"); break;
		case 9: 	printf("settembre\n"); break;
		case 10: 	printf("ottobre\n"); break;
		case 11: 	printf("novembre\n"); break;
		case 12: 	printf("dicembre\n"); break;
		default: 	printf("????\n");
	}
	
  	system("PAUSE");	
  	return 0;
}

