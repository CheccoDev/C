/* input: mese numerico con controllo valori
output: mese letterale
*/
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]){
	int mese, tentativi=1;
	printf("tentativo num %d inserisci mese:",tentativi); scanf("%d",&mese);
	/*
    //con l'if farei un solo controllo
    if (mese<1 or mese>12) {
      printf("valore mese errato! ");         
      printf("inserisci mese:"); scanf("%d",&mese);
    }
    */
    //fintantoch� il valore � errato continuo a richiederlo
    //ma solo per 3 volte al massimo
	while ( (mese<1 || mese>12) && tentativi<=3) {
      printf("valore errato! ");      
      printf("tentativo num %d inserisci mese:",tentativi); scanf("%d",&mese);
      tentativi++;
    }   
    //visto che almeno 1 volte dove leggere il mese da tastiera potrei usare il do-while
    /*do{
    	printf("tentativo num %d inserisci mese:",tentativi); scanf("%d",&mese);
    	if (mese<1 || mese>12) {
    		printf("valore errato! "); 	
		}
		tentativi++;
	}while ( (mese<1 || mese>12) && tentativi<=3);
	*/
    if (mese>=1 && mese<=12) {	
    	switch(mese){
    		case 1: 	printf("gennaio\n");
    		case 2: 	printf("febbraio\n"); break;
    		case 3: 	printf("marzo\n"); break;
    		case 4: 	printf("aprile\n"); break;
    		case 5: 	printf("maggio\n"); break;
    		case 6: 	printf("giugno\n"); break;
    		case 7: 	printf("luglio\n"); break;
    		case 8: 	printf("agosto\n"); break;
    		case 9: 	printf("settembre\n"); break;
    		case 10: 	printf("ottobre\n"); break;
    		case 11: 	printf("novembre\n"); break;
    		case 12: 	printf("dicembre\n"); break;
    		default: 	printf("????\n");
    	}
    } else {
        printf("spiacente numero tentativi esaurito\n"); 
    }
  	system("PAUSE");	
  	return 0;
}

