#include <stdio.h>
#include <stdlib.h>

int main(){
	//dichiarazione delle variabili  
	int a, x;
	int b;  //dichiar. + inizializ.
	//inizializzazione delle variabili
	scanf("%d", &a);
	scanf("%d", &b);
	
	x=a%b;
	printf("a vale:\n");
	printf("%d\n", a);
	printf("b vale:\n");
	printf("%d\n", b);
	printf("resto della divisione a/b vale:\n");
	printf("%d\n", x); 
	printf("il resto tra %d e %d vale %d\n", a, b, x);
	printf("divisione tra interi %d e %d vale %d\n", a, b, a/b);
	// casting
	printf("divisione tra %d e %d (con cast) vale %f\n", a, b, (float)a/b);
	printf("divisione tra %d e %d (con cast) vale %f\n", a, b, a/(float)b);
	
	system("PAUSE"); 
	return 0;
}

