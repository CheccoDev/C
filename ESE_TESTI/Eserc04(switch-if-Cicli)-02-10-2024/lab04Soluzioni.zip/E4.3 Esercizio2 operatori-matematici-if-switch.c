/* input: operatore
output: operazione
*/
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]){
	char op;
	printf("inserisci operatore: "); 
	fflush(stdin); 
	scanf("%c",&op);
	
	/* soluzione 1*/
	if(op=='+'){
		printf("somma\n");
	}else{
		if(op=='-'){
			printf("sottrazione\n");
		}else{
			if(op=='*' || op=='x'){
				printf("prodotto\n");
			}else{
				if(op=='/'){
					printf("divisione\n");
				}else{
					printf("Errore!!\n");
				}
			}
		}
	}
	
	/* soluzione 2*/
	if(op=='+'){
		printf("somma\n");
	}
	if(op=='-'){
		printf("sottrazione\n");
	}
	if(op=='*' || op=='x'){
		printf("prodotto\n");
	}
	if(op=='/'){
		printf("divisione\n");
	}
	if(op!='+' && op!='-' && op!='*' && op!='x' && op!='/'){
		printf("Errore!!\n");
	}
	
	/* soluzione 3*/
	switch(op){
		case '+': 	printf("somma\n"); break;
		case '-': 	printf("sottrazione\n"); break;
		case '*': 	
		case 'x': 	printf("prodotto\n"); break;
		case '/': 	printf("divisione\n"); break;
		default: 	printf("Errore!!\n");
	}

  	return 0;
}

