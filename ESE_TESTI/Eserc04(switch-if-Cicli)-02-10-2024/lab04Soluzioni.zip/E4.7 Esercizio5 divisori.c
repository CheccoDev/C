#include <stdio.h>
#include <stdlib.h>

int main(){
	int i, x;
	// input con controllo while
	printf("Inserisci numero: ");
	scanf("%d", &x);
	/* controllo input */ 
	while(x<=0){
		printf("Inserisci numero positivo: ");
		scanf("%d", &x);
	}
	
	/*
	// input con controllo do-while
	do{
		printf("Inserisci numero positivo: ");
		scanf("%d", &x);
	}while(x<=0);
	*/
	
	
	/* ricerca divisori */
	/* i=0 non ha senso, i=1 e i=x sono sempre divisori */
	i = 2;
	/* while (i < x/2) :  riduce il numero di cicli */
	while(i < x){
		if( x%i == 0 ){
			printf("Divisore: %d\n", i);
		}
		i++;  
	}
	
	system("PAUSE"); 
	return 0;
}

