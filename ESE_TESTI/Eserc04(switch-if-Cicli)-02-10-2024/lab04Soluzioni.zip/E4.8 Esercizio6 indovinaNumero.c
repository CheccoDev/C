#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]){
	int valore, tentativo, indovinato;
	indovinato = 0;
	printf("Inserisci il valore da indovinare\n");
	scanf("%d", &valore);
	system("CLS");
	while (!indovinato){
		printf("Indovina il numero\n");
		scanf("%d", &tentativo);
		if (tentativo == valore){
			printf("Non ci posso credere ;-) hai indovinato!\n");
			indovinato = 1;
			}
		else{
			if (tentativo > valore){ 
				printf("Il numero da indovinare e' piu' piccolo\n"); 
			}
			else{ 
				printf("Il numero da indovinare e' piu' grande\n");
			}
		} 
			
	} 
	system("PAUSE");	
	return 0;
}

