#include <cstdlib>
#include <iostream>
#include "stack.h"
#define DIM 3
#define K 10

using namespace std;

int main(int argc, char *argv[])
{
	int pos;
    int i;
    StackPtr pv[DIM]; // array di puntatori a stack
    /*for(i=0 ; i<DIM ; ++){
			pv[i] = new Stack(4);
    }*/
	init(pv, DIM, 4);
	Tdato d;
	
    for(i=0; i<K; i++) {
		d = dato_casuale();
      	pos = casuale(0, DIM-1); 
      	if(! pv[pos]->isFull()) { 
        	pv[pos]->push(d);
      	}
    }
    
    printArray(pv, DIM);
    for(i=0; i<DIM ; ++){
      delete pv[i];
    }
    system("PAUSE");
    return EXIT_SUCCESS;
}
