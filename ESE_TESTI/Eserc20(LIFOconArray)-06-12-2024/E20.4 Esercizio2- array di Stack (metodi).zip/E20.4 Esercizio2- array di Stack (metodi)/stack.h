#ifndef __STACK_H__
#define __STACK_H__
#include <cstdlib>
#include <iostream>
using namespace std;
typedef struct Tdato{
	int x,y,z;       
	Tdato(){
		x=0; y=0; z=0;  
	}
	Tdato (int _x, int _y, int _z){
		x=_x; y=_y; z=_z; 
	}
	void stampa()const{
		printf("[%d,%d,%d]",x,y,z);   
	}
}Tdato;

typedef struct TipoStack {
	int n; 	// numero elementi presenti
	int dim; 	// dimensione massima
	Tdato * s; 	// vettore
	TipoStack () {
		n=0;
		dim=5;
		s = new Tdato[5];         
	}
	TipoStack (int _dim) {
		n = 0;
		dim = _dim;
		s = new Tdato [dim];
	}
	~TipoStack(){
		delete s;
	}
	void stampa()const{
		int i;
		for(i=0; i<dim; i++){
			if (i<n){
				s[i].stampa();
			}else{
				printf("[,,]");      
			}       
		}
		cout << endl;  
	}
	bool isFull(){
		return (n==dim);
	}
	bool isEmpty(){
		return (n==0);
	}
	void push(Tdato d){
		s[n]=d;
		n++;
	}
	Tdato pop(){
		n--;
		return s[n];       
	}
	Tdato read(){
		return s[n-1];
	}
}TipoStack;

typedef TipoStack Stack;
typedef TipoStack *StackPtr;

int casuale(int min, int max);

// Verifica se lo stack � pieno o no
bool stackIsFull(StackPtr p);

// Verifica se lo stack � vuoto o no
bool stackIsEmpty(StackPtr p);

// Inserisce l�elemento d nello stack incrementando la dimensione dello stack
void push(StackPtr p, Tdato d);
 
// Rimuove un elemento dallo stack, riducendo la dimensione dello stack e ritorna il valore
Tdato pop(StackPtr p);

// Stampa (a video) del contenuto dello Stack
void stampa(StackPtr p);

void init(StackPtr v[], int n_elem, int dim);
Tdato dato_casuale();
void printArray(StackPtr v[], int n_elem);

#endif
