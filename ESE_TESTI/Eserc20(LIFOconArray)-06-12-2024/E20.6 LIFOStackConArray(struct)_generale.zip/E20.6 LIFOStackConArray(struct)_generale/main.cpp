#include <cstdlib>
#include <iostream>
#include "stack.h"
using namespace std;

int main(int argc, char *argv[])
{
	TipoStack* pd = new TipoStack[5];
	Stack s0(5); //var di tipostack
	StackPtr s1 = new Stack(5);//puntatore di tipostack
	Tdato d;
	
	printf("stack0 pieno=%d\n",s0.isFull());
	printf("stack0 vuoto=%d\n",s0.isEmpty());
	
	printf("stack pieno=%d\n",s1->isFull());
	printf("stack vuoto=%d\n",s1->isEmpty());
	d.eta=23; d.altezza=156.4; s1->push(d);
	d.eta=18; d.altezza=186.9; s1->push(d);
	s1->stampa();
	d = s1->pop();
	d.stampa(); printf("\n");
	s1->stampa();
	delete s1;
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
