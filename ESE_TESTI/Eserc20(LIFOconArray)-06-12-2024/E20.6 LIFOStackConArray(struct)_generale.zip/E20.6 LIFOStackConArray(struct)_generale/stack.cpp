#include <cstdlib>
#include <iostream>
#include "stack.h"
using namespace std;

// Sfruttando i metodi
/*
bool stackIsFull(StackPtr p){
	return p->isFull();
}
bool stackIsEmpty(StackPtr p){
	return p->isEmpty();
}
void push(StackPtr p, Tdato d){
	if(!p->isFull())
		return p->push(d);
}
Tdato pop(StackPtr p){
	if(!p->isEmpty())
		return p->pop();
	else
		return Tdato();
}
void stampa(StackPtr p){
	p->stampa();
}
*/

// funzioni riscritte senza l'uso dei metodi di TipoStack
bool stackIsFull(StackPtr p){
	return p->n == p->dim;
}
bool stackIsEmpty(StackPtr p){
	return p->n == 0;
}
void push(StackPtr p, Tdato d){
	if ( stackIsFull(p) ){
		printf("dato non inserito stack pieno \n");
	}else{   
		p->s[p->n] = d;
		p->n++;
	}
}
Tdato pop(StackPtr p){
	if ( stackIsEmpty(p) ) {
		printf("stack vuoto \n");
		return Tdato(); 
	}else{ 
		p->n--;
		return p->s[p->n];
	}
}
void stampa(StackPtr p){
	int i;
	for (i=0; i<p->dim; i++){
		if (i<p->n){
			p->s[i].stampa();
		}else{
			printf("[ ]");      
		}   
	}
	printf("\n");
}

