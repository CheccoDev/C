#include <cstdlib>
#include <iostream>
#include "stack.h"
#define K 10
using namespace std;

int main(int argc, char *argv[])
{
	// esempi
	Tdato d;
	
	Stack s;
	stampa(&s);
	if( !stackIsFull(&s) ){
		push(&s, d);
    }
	if( !stackIsEmpty(&s) ){
		pop(&s);
    }
	
    StackPtr ps[3];
    int i,j,pos;
    
    for (i=0; i<3; i++){
      ps[i] = new Stack(4);
    }
    for(i=0; i<K; i++){
       d = Tdato(i, i+1, i+2);
       pos=rand()%(2-0+1)+0;
       ps[pos]->push(d); 
       for (j=0; j<3; j++){
         ps[j]->stampa();
       }  
       cout << endl << endl;    
    }
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
