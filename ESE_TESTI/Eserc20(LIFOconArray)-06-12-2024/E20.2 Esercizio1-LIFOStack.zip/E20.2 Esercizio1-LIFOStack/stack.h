#ifndef __TIPOSTACK__
#define __TIPOSTACK__

typedef struct Tdato{
	int x, y, z;
	Tdato(int _x, int _y, int _z){
		x = _x;
		y = _y;
		z = _z;      
	}  
	Tdato(){
		x = y = z = 0;
	}    
	void stampa()const{
		printf("[%d %d %d]", x, y, z);
	} 
}Tdato;


typedef struct TipoStack{
	int dim; //dim massima
	int n;   //num elementi presenti
	Tdato* s;  //dato di tipo dati        
	
	TipoStack(){
		dim = 3;
		n = 0;
		s = new Tdato[3];         
	}
	TipoStack(int _dim)
	{
		dim = _dim;
		n = 0;
		s = new Tdato[dim];         
	}
	bool isFull(){
		return (n == dim);  
	}
	bool isEmpty() {
		return (n == 0);
	}
	void stampa()const{
		int i;
		for (i=0; i<dim; i++){
			if (i<n){
				s[i].stampa();
			}else{
				printf("[,,]");      
			}   
		}
		printf("\n");   
	}
	void push(Tdato x) {
		if ( isFull() ){
			printf("dato non inserito stack pieno \n");
		}else{   
			s[n]=x;
			n++;
		}  
	}
	Tdato pop() {
		if ( isEmpty() ) {
			printf("stack vuoto \n");
			return Tdato(); 
		}else{ 
			n--;
			return s[n];
		}
	}
}TipoStack;

typedef TipoStack Stack; 
typedef TipoStack* StackPtr;

// funzioni analoghe ai metodi definiti in TipoStack
// Verifica se lo stack � pieno o no
bool stackIsFull(StackPtr p);
// Verifica se lo stack � vuoto o no
bool stackIsEmpty(StackPtr p);
// Inserisce l�elemento d nello stack 
// incrementando la dimensione dello stack
void push(StackPtr p, Tdato d);
// Rimuove un elemento dallo stack, 
// riducendo la dimensione dello stack e ritorna il valore
Tdato pop(StackPtr p);
// Stampa (a video) del contenuto dello Stack
void stampa(StackPtr p);


#endif
