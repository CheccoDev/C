#include <cstdlib>
#include <iostream>
#include "stack.h"
using namespace std;

int casuale(int min, int max){
	return rand()%(max-min+1)+min;
}

Tdato dato_casuale(){
	// Tdato r;
	// r.x=rand()%(9-0+1)+0;
	// r.y=rand()%(9-0+1)+0;
	// r.z=rand()%(9-0+1)+0;
	// return r;
	// --oppure--
	// Tdato r;
	// r = Tdato( casuale(0,9), casuale(0,9), casuale(0,9) );
	// return r;
	// --oppure--
	return Tdato( casuale(0,9), casuale(0,9), casuale(0,9) );
}

// Verifica se lo stack � pieno o no
bool stackIsFull(StackPtr p){
	return p->n == p->dim;
	// return p->isFull();
}

// Verifica se lo stack � vuoto o no
bool stackIsEmpty(StackPtr p){
	return p->n ==0 ;
	// return p->isEmpty();
}

// Inserisce l�elemento d nello stack incrementando la dimensione dello stack
void push(StackPtr p, Tdato d){
	p->s[p->n] = d;
	p->n++;
	// p->push(d);
}
 
// Rimuove un elemento dallo stack, riducendo la dimensione dello stack e ritorna il valore
Tdato pop(StackPtr p){
	p->n--;
	return p->s[p->n];
	// return p->pop();
}

// Stampa (a video) del contenuto dello Stack
void stampa(StackPtr p){
	p->stampa();
}

void init(StackPtr v[], int n_elem, int dim){
	int i;
	for(i=0 ; i<n_elem ; i++){
		v[i] = new Stack(dim);
    }
}
void printArray(StackPtr v[], int n_elem){
	int i;
	for(i=0 ; i<n_elem ; i++){
		cout << "Stack " << i << endl;
		v[i]->stampa();
		cout << endl;
	}
		
}

