#include <cstdlib>
#include <iostream>
#include "stack.h"
#define DIM 3
#define K 10

using namespace std;

int main(int argc, char *argv[])
{
	int pos;
    int i;
    StackPtr pv[DIM]; // array di puntatori a stack
    // for(i=0 ; i<DIM ; ++)
	//		pv[i] = new Stack(4);
	init(pv, DIM, 4);
	Tdato d;
	
    for(i=0 ; i<K ; i++ ) {
    		d = dato_casuale();
          	pos = casuale(0, DIM-1); 
          	if(!(stackIsFull(pv[pos]))) { 
            	push(pv[pos], d);
          	}
    }
    
    printArray(pv, DIM);
    
    int index;
    index = cerca_stack_grande(pv, DIM);
    printf("\nCoda piu' grande: %d\n", index);
	index = cerca_massimo(pv, DIM);
    printf("\nCoda con valore x massimo: %d\n", index);
	if( cerca_coppia(pv, DIM) ){
		printf("Esiste elemento da estrarre con due valori uguali\n");
	}else{
		printf("NON esiste elemento da estrarre con due valori uguali\n");
	}
    
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
