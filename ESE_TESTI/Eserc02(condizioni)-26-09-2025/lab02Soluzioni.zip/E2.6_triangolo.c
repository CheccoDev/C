/* determinare se tre valori inseriti sono i lati 
di un triangolo
*/
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
	
  	int x, y, z;
  	printf("Valore di x: ");
  	scanf("%d", &x);
  	printf("Valore di y: ");
  	scanf("%d", &y);
  	printf("Valore di y: ");
  	scanf("%d", &z);
  	// soluzione 1
	if( x>0 && y>0 && z>0 && x+y>z && x+z>y && y+z>x ){
		if( x==y && y==z ){
			printf("equilatero\n");
		}else{
			if( x==y || x==z || y==z ){
				printf("isoscele\n");
			}else{
				printf("scaleno\n");
			}
		}
	}else{
		printf("i dati non sono i lati di un triangolo\n");
	}
	
	// soluzione 2
	if( x<0 || y<0 || z<0 || x+y<z || x+z<y || y+z<x ){
		printf("i dati non sono i lati di un triangolo\n");
	}else{
		if( x==y && y==z ){
			printf("equilatero\n");
		}else{
			if( x==y || x==z || y==z ){
				printf("isoscele\n");
			}else{
				printf("scaleno\n");
			}
		}
	}
	
  	system("PAUSE");	

  	return 0;

}

