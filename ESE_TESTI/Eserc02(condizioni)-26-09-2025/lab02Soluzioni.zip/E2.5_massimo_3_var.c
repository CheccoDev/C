#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  int a,b,c,d; //dichiarazione
  int min,max;
  float media;
  //inizializzazione
  printf("a="); scanf("%d",&a);
  printf("b="); scanf("%d",&b); 
  printf("c="); scanf("%d",&c); 

  min=a; max=a;
  if (b>max) {max=b;} 
  if (b<min) {min=b;}
  if (c>max) {max=c;} 
  if (c<min) {min=c;} 

  printf("min=%d \n", min);
  printf("max=%d \n", max);  
 
  media =(float) (a+b+c)/3.0;
  printf("massimo=%d\n",max);
  printf("media=%f\n",media);
  printf("media=%.3f\n",media);
  printf("media=%.3f\n",(a+b+c)/3.0);
     
  system("PAUSE");	
  return 0;
}
