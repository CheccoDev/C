#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]){
 /*
  * ESEMPIO 1
  */   
 int max, alfa, beta;
 printf("Valore di alfa: ");
 scanf("%d", &alfa);
 printf("Valore di beta: ");
 scanf("%d", &beta);

 max = (alfa > beta) ? alfa : beta;
 printf("valore di max: %d\n", max);
 
 /*
  * ESEMPIO 2
  */ 
  int x, y;
  printf("Valore di x: ");
  scanf("%d", &x);
  printf("Valore di y: ");
  scanf("%d", &y);

  ( x > y ) ? printf("%d e' maggiore di %d\n", x, y) : printf("%d e' maggiore di %d\n", y, x);  
  
 system("PAUSE");	
 return 0;
}
