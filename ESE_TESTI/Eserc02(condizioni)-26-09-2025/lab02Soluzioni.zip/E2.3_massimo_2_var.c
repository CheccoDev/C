/* ricerca massimo tra due numeri interi */
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
	
  	int x, y;
  	printf("Valore di x: ");
  	scanf("%d", &x);
  	printf("Valore di y: ");
  	scanf("%d", &y);
  	// soluzione 1
	if (x > y) { 
		printf("%d e' maggiore di %d\n", x, y); 
	}else {
		if (x < y){ 
			printf("%d e' maggiore di %d\n", y, x); 
		}else{ 
			printf("%d e' uguale a %d\n", x, y); 
		}
	}
	// soluzione 2
	if (x > y) { 
		printf("il massimo e' %d\n", x); 
	}else {
		if (x < y){ 
			printf("il massimo e' %d\n", y); 
		}else{ 
			printf("i due numeri sono uguali\n"); 
		}
	}
    // soluzione 2
	if (x == y) { 
		printf("i due numeri sono uguali\n");  
	}else {
		if (x > y){ 
			printf("il massimo e' %d\n", x);	 
		}else{ 
			printf("il massimo e' %d\n", y);
		}
	}
	// soluzione 3
	int max;
	if (x == y) { 
		printf("i due numeri sono uguali\n");  
	}else {
		if (x > y){ 
			max = x;	 
		}else{ 
			max = y
		}
		printf("il massimo e' %d\n", max);
	}
	// soluzione 4
	int max;
	if (x == y) { 
		printf("i due numeri sono uguali\n");  
	}else {
		max = y;
		if (x > max){ 
			max = x;	 
		}
		printf("il massimo e' %d\n", max);
	}

  system("PAUSE");	

  return 0;

}

