/* determinare se il valore inserito e'
un anno bisestile
*/
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  	int anno;
  	printf("Inseirsci anno: ");
  	scanf("%d", &anno);
	if( anno%400==0 || ( anno%4==0 && anno%100!=0 ) ){
	/* 
	considerando:
		FALSO uguale a 0
		VERO diverso da 0
	la condizione si puo' scrivere come
	!(anno%400) || ( !(anno%4) && anno%100 ) 
	*/
		printf("anno bisestile\n");
	}else{
		printf("anno NON bisestile\n");
	}
	
  	system("PAUSE");	

  	return 0;

}

