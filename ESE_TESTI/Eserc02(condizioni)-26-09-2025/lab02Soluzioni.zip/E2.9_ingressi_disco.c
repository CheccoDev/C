#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]){
	int anni;
	char m_o_f;
	printf("anni: "); scanf("%d",&anni);
	printf("maschio (m) o femmina (f): "); 
	fflush(stdin);
	scanf("%c",&m_o_f);
	
	if( anni<21 ){
		printf("non puoi entrare\n");
	}else{
		if(m_o_f == 'm'){
			printf("costo: 30 euro\n");
		}else{
			printf("gratis\n");
		}
	}
	
	// e se l'utente inserisce un carattere diverso da m ed f?
	printf("\n---- soluzione 2 ----\n");
	if( anni<21 ){
		printf("non puoi entrare\n");
	}else{
		if( m_o_f == 'm' ){
			printf("costo: 30 euro\n");
		}else{
			if( m_o_f == 'f' ){
				printf("gratis\n");
			}else{
				printf("dato errato\n");
			}
			
		}
	}
	
	printf("\n---- soluzione 3 ----\n");
	printf("anni: "); 
	scanf("%d",&anni);
	// chiedere maschio o femmina se gli anni sono adatti per entrare
	if( anni<21 ){
		printf("non puoi entrare\n");
	}else{
		printf("maschio (m) o femmina (f): "); 
		fflush(stdin);
		scanf("%c",&m_o_f);
		if(m_o_f == 'm'){
			printf("costo: 30 euro\n");
		}else{
			if( m_o_f == 'f' ){
				printf("gratis\n");
			}else{
				printf("dato errato\n");
			}
		}
	}
		
  	system("PAUSE");	
  	return 0;
}

