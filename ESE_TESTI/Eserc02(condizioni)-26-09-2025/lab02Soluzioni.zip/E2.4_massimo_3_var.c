/* ricerca massimo tra tre numeri interi */
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
	
  	int x, y, z;
  	printf("Valore di x: ");
  	scanf("%d", &x);
  	printf("Valore di y: ");
  	scanf("%d", &y);
  	printf("Valore di y: ");
  	scanf("%d", &z);
  	// soluzione 1
	if( x==y && y==z ){
		printf("i tre numeri sono uguali\n");
	}else{
		if( x>y && x>z ) { 
			printf("il massimo e' %d\n", x);
		}
		if( y>x && y>z ) { 
			printf("il massimo e' %d\n", y);
		}
		if( z>y && z>x ) { 
			printf("il massimo e' %d\n", z);
		}
	}
	
	// soluzione 2
	if( x==y && y==z ){
		printf("i tre numeri sono uguali\n");
	}else{
		if( x>y ){
			// massimo tra 2 numeri: x e z
			// problema noto
			if( x>z ){ 
				printf("il massimo e' %d\n", x);
			}else{ 
				printf("il massimo e' %d\n", z);
			}
		}else {
			// massimo tra 2 numeri: y e z
			// problema noto
			if( y>z ){ 
				printf("il massimo e' %d\n", y);
			}else{ 
				printf("il massimo e' %d\n", z);
			}
		}
	}
	
	// soluzione 3
	int max;
	if( x==y && y==z ) { 
		printf("i tre numeri sono uguali\n");  
	}else {
		max = x;
		if( y>max ){ 
			max = y;	 
		}
		if( z>max ){ 
			max = z;	 
		}
		printf("il massimo e' %d\n", max);
	}
	
  	system("PAUSE");	

  	return 0;

}

