#include <stdio.h>
#include <stdlib.h>

#define CELL_X 20
#define CELL_Y 30

int main(int argc, char *argv[])
{ 
	int m[CELL_X][CELL_Y];
	int x, y, conta;
	srand(time(0));
	for (x = 0; x < CELL_X; x++){
		for (y = 0; y < CELL_Y; y++){
			m[x][y] = rand()%3;
		}
	}
	
	conta = 0;
	for (x = 0; x < CELL_X; x++){
		for (y = 0; y < CELL_Y; y++){
			if(m[x][y]>0){
				conta++;
			}
		}
	}

	printf("\nNumero schegge: %d\n", conta);

	
	//system("PAUSE");	
	return 0;
}
