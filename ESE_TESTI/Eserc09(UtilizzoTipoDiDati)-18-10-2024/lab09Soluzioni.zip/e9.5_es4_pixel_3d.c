#include <stdio.h>
#include <stdlib.h>

#define H 20
#define L 30
#define P 40
#define VMIN 0
#define VMAX 255

typedef struct Tpixel{	
	int r, g, b;
} Tpixel;

typedef struct Timmagine{
	Tpixel imm[H][L][P];
	int h, l, p;
} Timmagine;

int main(int argc, char *argv[])
{ 
	Timmagine immagine;
	int i, j, k, i_max, j_max, k_max, s_max, s;
	
	do{
		printf("h: "); scanf("%d", &immagine.h);
	}while(immagine.h<0 || immagine.h>H);
	do{
		printf("l: "); scanf("%d", &immagine.l);
	}while(immagine.l<0 || immagine.l>L);
	do{
		printf("p: "); scanf("%d", &immagine.p);
	}while(immagine.p<0 || immagine.p>P);
	
	for (i = 0; i < immagine.h; i++){
		for (j = 0; j < immagine.l; j++){
			for (k = 0; k < immagine.p; k++){
				/*do{
					printf("pixel %d %d r: ", i, j); 
					scanf("%d", &immagine.imm[i][j][k].r);
					if(immagine.imm[i][j][k].r<VMIN || immagine.imm[i][j][k].r>VMAX){
						pritnf("errore %d %d r\n", i, j);
					}
				}while(immagine.imm[i][j][k].r<VMIN || immagine.imm[i][j][k].r>VMAX);
				do{
					printf("pixel %d %d g: ", i, j); 
					scanf("%d", &immagine.imm[i][j][k].g);
					if(immagine.imm[i][j][k].g<VMIN || immagine.imm[i][j][k].g>VMAX){
						pritnf("errore %d %d g\n", i, j);
					}
				}while(immagine.imm[i][j][k].g<VMIN || immagine.imm[i][j][k].g>VMAX);
				do{
					printf("pixel %d %d r: ", i, j); 
					scanf("%d", &immagine.imm[i][j][k].b);
					if(immagine.imm[i][j][k].b<VMIN || immagine.imm[i][j][k].b>VMAX){
						pritnf("errore %d %d b\n", i, j);
					}
				}while(immagine.imm[i][j][k].b<VMIN || immagine.imm[i][j][k].b>VMAX);
				*/
				
				immagine.imm[i][j][k].r = rand()%(VMAX-VMIN+1)+VMIN;
				immagine.imm[i][j][k].g = rand()%(VMAX-VMIN+1)+VMIN; 
				immagine.imm[i][j][k].b = rand()%(VMAX-VMIN+1)+VMIN;
			}
		}
	}
	
	for (i = 0; i < immagine.h; i++){
		for (j = 0; j < immagine.l; j++){
			for (k = 0; k < immagine.p; k++){
				printf("(%3d, %3d, %3d) ", immagine.imm[i][j][k].r, immagine.imm[i][j][k].g, immagine.imm[i][j][k].b);
			}
			printf("\n");
		}
		printf("\n--\n");
	}
	
	i_max = 0; 
	j_max = 0;
	k_max = 0;
	s_max = immagine.imm[i_max][j_max][k_max].r+immagine.imm[i_max][j_max][k_max].g+immagine.imm[i_max][j_max][k_max].b;
	for (i = 0; i < immagine.h; i++){
		for (j = 0; j < immagine.l; j++){
			for (k = 0; k < immagine.p; k++){
				s = immagine.imm[i][j][k].r+immagine.imm[i][j][k].g+immagine.imm[i][j][k].b;
				if( s>s_max ){
					i_max = i;
					j_max = j;
					k_max = k;
					s_max = s;
				}
			}
		}
	}
	printf("\nMassimo in %d %d %d: (%d %d %d)\n", i_max, j_max, k_max, 
			immagine.imm[i_max][j_max][k_max].r,
			immagine.imm[i_max][j_max][k_max].g,
			immagine.imm[i_max][j_max][k_max].b);

	
	//system("PAUSE");	
	return 0;
}
