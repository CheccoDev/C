#include <stdio.h>
#include <stdlib.h>

#define NVERTICI 8
#define NFIGURE 10
#define VMIN -20
#define VMAX 20

typedef struct Tvertice{	
	float x;
	float y;
} Tvertice;

typedef struct Tfigura{
	Tvertice v[NVERTICI];
	int n_vertici;
} Tfigura;

typedef struct Tdisegno{
  Tfigura figure[NFIGURE];
  int n_figure;
} Tdisegno;


int main(int argc, char *argv[])
{ 
	Tdisegno d;
	int i, j, i_max;
	float dx, dy, perimetro, perimetro_max;
	
	d.n_figure = rand()%(NFIGURE-3+1)+3;
	for (i = 0; i < d.n_figure; i++){
		d.figure[i].n_vertici = rand()%(NVERTICI-3+1)+3;
		for (j = 0; j < d.figure[i].n_vertici; j++){
			d.figure[i].v[j].x = (rand()%(VMAX*10-VMIN*10+1)+VMIN*10)/10;
			d.figure[i].v[j].y = (rand()%(VMAX*10-VMIN*10+1)+VMIN*10)/10;
		}
	}
	
	// IP: primo elemento con perimetro massimo
	perimetro_max = 0;
	i_max = 0;
	for (j = 0; j < d.figure[0].n_vertici-1 ; j++){
		dx = d.figure[0].v[j].x - d.figure[0].v[j+1].x;
		dy = d.figure[0].v[j].y - d.figure[0].v[j+1].y;
		perimetro_max = perimetro_max + sqrt(dx*dx + dy*dy);
	}
	dx = d.figure[0].v[0].x - d.figure[0].v[d.figure[0].n_vertici-1].x;
	dy = d.figure[0].v[0].y - d.figure[0].v[d.figure[0].n_vertici-1].y;
	perimetro_max = perimetro_max + sqrt(dx*dx + dy*dy);
	
	perimetro= 0;
	for (i = 0; i < d.n_figure ; i++){
		for (j = 0; j < d.figure[i].n_vertici-1 ; j++){
			dx = d.figure[0].v[j].x - d.figure[0].v[j+1].x;
			dy = d.figure[0].v[j].y - d.figure[0].v[j+1].y;
			perimetro = perimetro + sqrt(dx*dx + dy*dy);
		}
		dx = d.figure[i].v[0].x - d.figure[i].v[d.figure[i].n_vertici-1].x;
		dy = d.figure[i].v[0].y - d.figure[i].v[d.figure[i].n_vertici-1].y;
		perimetro = perimetro + sqrt(dx*dx + dy*dy);
		if( perimetro > perimetro_max){
			perimetro_max = perimetro;
			i_max = i;
		}
	}
	
	printf("Figura con perimetro massimo in posizione: %d\n E vale %f\n", i_max, perimetro_max);        

	//system("PAUSE");	
	return 0;
}
