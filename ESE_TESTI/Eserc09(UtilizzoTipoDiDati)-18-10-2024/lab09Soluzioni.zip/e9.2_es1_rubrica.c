/* Soluzione alternativa Es8.1
*/
#include <stdio.h>
#include <stdlib.h>

#define NPERSONE 10
#define MAXL 30
#define ANNO_OGGI 2019 
#define ANNO_INIZ 1950

typedef struct Tdata{
	int g, m, a;
}Tdata;

typedef struct Tpersona{
	char nome[MAXL];
	char cognome[MAXL];
	int eta;
	Tdata iscrizione;
}Persona;

typedef struct Rubrica{
	Persona vet[NPERSONE];
	int n_pers;
}Rubrica;


int main(int argc, char *argv[])
{ 
	int i, min, max, n_pers, continua;
	float somma;
	int giorni_per_mese[]={31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
	Rubrica r;
	
	continua = 1; 
	r.n_pers = 0;
	do{
		printf("Dammi il nome della persona %d: ", (r.n_pers +1));
		fflush(stdin); scanf("%s", r.vet[r.n_pers].nome);
		//gets(r.vet[r.n_pers].nome);
		printf("Dammi il cognome della persona %d: ", (r.n_pers +1));
		fflush(stdin); scanf("%s", r.vet[r.n_pers].cognome);
		printf("Dammi l'eta' della persona %d: ", (r.n_pers +1));
		scanf("%d", &r.vet[r.n_pers].eta);
		r.vet[r.n_pers].iscrizione.a = rand()%(ANNO_OGGI - ANNO_INIZ + 1) + ANNO_INIZ;
		r.vet[r.n_pers].iscrizione.m = rand()%12;
		r.vet[r.n_pers].iscrizione.g = rand()%giorni_per_mese[r.vet[r.n_pers].iscrizione.m];
		r.n_pers++;
		printf("\nContinua? 1=si, 0= no");
		fflush(stdin); scanf("%d", &continua);
	}while(continua && r.n_pers < NPERSONE);
	
	somma = 0;
	min = 0;
	max = 0;
	for (i = 0; i < r.n_pers; i++) {
		printf("%s %s di anni %d", r.vet[i].nome, r.vet[i].cognome, r.vet[i].eta)
		somma = somma + r.vet[i].eta;
		if (r.vet[i].eta < r.vet[min].eta) 
			min = i;
		if (r.vet[i].eta > r.vet[max].eta) 
			max = i;
	}
	
	printf("Il piu' anziano si chiama %s %s.\n", r.vet[max].nome, r.vet[max].cognome);
	printf("Il piu' giovane si chiama %s %s.\n", r.vet[min].nome, r.vet[min].cognome);
	printf("La media delle eta' e' %2.1f\n", somma/r.n_pers);
	
	//system("PAUSE");	
	return 0;
}
