#include <stdio.h>
#include <stdlib.h>

#define H 20
#define L 30
#define VMIN 0
#define VMAX 255

typedef struct Tpixel{	
	int r, g, b;
} Tpixel;

typedef struct Timmagine{
	Tpixel imm[H][L];
	int h, l;
} Timmagine;

int main(int argc, char *argv[])
{ 
	Timmagine immagine;
	int i, j, i_max, j_max, s_max, s;
	
	do{
		printf("h: "); scanf("%d", &immagine.h);
	}while(immagine.h<0 || immagine.h>H);
	do{
		printf("l: "); scanf("%d", &immagine.l);
	}while(immagine.l<0 || immagine.l>L);

	
	for (i = 0; i < immagine.h; i++){
		for (j = 0; j < immagine.l; j++){
			/*do{
				printf("pixel %d %d r: ", i, j); 
				scanf("%d", &immagine.imm[i][j].r);
				if(immagine.imm[i][j].r<VMIN || immagine.imm[i][j].r>VMAX){
					pritnf("errore %d %d r\n", i, j);
				}
			}while(immagine.imm[i][j].r<VMIN || immagine.imm[i][j].r>VMAX);
			do{
				printf("pixel %d %d g: ", i, j); 
				scanf("%d", &immagine.imm[i][j].g);
				if(immagine.imm[i][j].g<VMIN || immagine.imm[i][j].g>VMAX){
					pritnf("errore %d %d g\n", i, j);
				}
			}while(immagine.imm[i][j].g<VMIN || immagine.imm[i][j].g>VMAX);
			do{
				printf("pixel %d %d r: ", i, j); 
				scanf("%d", &immagine.imm[i][j].b);
				if(immagine.imm[i][j].b<VMIN || immagine.imm[i][j].b>VMAX){
					pritnf("errore %d %d b\n", i, j);
				}
			}while(immagine.imm[i][j].b<VMIN || immagine.imm[i][j].b>VMAX);
			*/
			
			immagine.imm[i][j].r = rand()%(VMAX-VMIN+1)+VMIN;
			immagine.imm[i][j].g = rand()%(VMAX-VMIN+1)+VMIN; 
			immagine.imm[i][j].b = rand()%(VMAX-VMIN+1)+VMIN;
			
		}
	}
	
	for (i = 0; i < immagine.h; i++){
		for (j = 0; j < immagine.l; j++){
			printf("(%3d, %3d, %3d) ", immagine.imm[i][j].r, immagine.imm[i][j].g, immagine.imm[i][j].b);			
		}
		printf("\n");
	}
	printf("\nHEX\n");
	char hex[] = "0123456789abcdef";
	for (i = 0; i < immagine.h; i++){
		for (j = 0; j < immagine.l; j++){
			printf("(%c%c, ", hex[immagine.imm[i][j].r/16], hex[immagine.imm[i][j].r%16]);
			printf("%c%c, ", hex[immagine.imm[i][j].g/16], hex[immagine.imm[i][j].g%16]);
			printf("%c%c) ", hex[immagine.imm[i][j].b/16], hex[immagine.imm[i][j].b%16]);
			
		}
		printf("\n");
	}
	printf("\nHEX - v2\n");
	for (i = 0; i < immagine.h; i++){
		for (j = 0; j < immagine.l; j++){
			printf("(%02x, %02x, %02x) ", immagine.imm[i][j].r, immagine.imm[i][j].g, immagine.imm[i][j].b);			
		}
		printf("\n");
	}
	
	i_max = 0; 
	j_max = 0;
	s_max = immagine.imm[i_max][j_max].r+immagine.imm[i_max][j_max].g+immagine.imm[i_max][j_max].b;
	for (i = 0; i < immagine.h; i++){
		for (j = 0; j < immagine.l; j++){
			s = immagine.imm[i][j].r+immagine.imm[i][j].g+immagine.imm[i][j].b;
			if( s>s_max ){
				i_max = i;
				j_max = j;
				s_max = s;
			}		
		}
	}
	printf("\nMassimo in %d %d: (%d %d %d)\n", i_max, j_max, 
			immagine.imm[i_max][j_max].r,
			immagine.imm[i_max][j_max].g,
			immagine.imm[i_max][j_max].b);

	
	//system("PAUSE");	
	return 0;
}
