#include <stdio.h>
#include <stdlib.h>

#define CELL_X 20
#define CELL_Y 30
#define CELL_Z 10

int main(int argc, char *argv[])
{ 
	int m[CELL_X][CELL_Y][CELL_Z];
	int x, y, z, conta;
	srand(time(0));
	for (x = 0; x < CELL_X; x++){
		for (y = 0; y < CELL_Y; y++){
			for (z = 0; z < CELL_Z; z++){
				m[x][y][z] = rand()%3;
			}
		}
	}
	
	conta = 0;
	for (x = 0; x < CELL_X; x++){
		for (y = 0; y < CELL_Y; y++){
			for (z = 0; z < CELL_Z; z++){
				if(m[x][y][z]>0){
					conta++;
				}
			}
		}
	}

	printf("\nNumero schegge: %d\n", conta);

	
	//system("PAUSE");	
	return 0;
}
