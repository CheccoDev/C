/*
Dato un numero intero convertirlo in esadecimale
*/
#include <stdio.h>
#define MAX 100

int main (int argc, const char * argv[]) {
	int num, n_digit, tmp;
	char hex[MAX];
	
	printf("num: "); scanf("%d", &num);
	
	// versione 1
	n_digit=0;
	tmp = num;
	while(tmp>0){
		switch(tmp%16){
			case 0: hex[n_digit] = '0'; break;
			case 1: hex[n_digit] = '1'; break;
			case 2: hex[n_digit] = '2'; break;
			case 3: hex[n_digit] = '3'; break;
			case 4: hex[n_digit] = '4'; break;
			case 5: hex[n_digit] = '5'; break;
			case 6: hex[n_digit] = '6'; break;
			case 7: hex[n_digit] = '7'; break;
			case 8: hex[n_digit] = '8'; break;
			case 9: hex[n_digit] = '9'; break;
			case 10: hex[n_digit] = 'A'; break;
			case 11: hex[n_digit] = 'B'; break;
			case 12: hex[n_digit] = 'C'; break;
			case 13: hex[n_digit] = 'D'; break;
			case 14: hex[n_digit] = 'E'; break;
			case 15: hex[n_digit] = 'F'; break;
		}
		tmp = tmp/16;
		n_digit++;
	}
	
	while(--n_digit>=0){
		printf("%c", hex[n_digit]);
	}
	printf("\n\n");
	
	// versione 2
	char alfabeto[]={'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};
	n_digit=0;
	tmp = num;
	while(tmp>0){
		hex[n_digit] = alfabeto[tmp%16];
		tmp = tmp/16;
		n_digit++;
	}	
	while(--n_digit>=0){
		printf("%c", hex[n_digit]);
	}
	printf("\n\n");
	
	
	// versione 3
	char s_alfabeto[]="0123456789ABCDEF";
	n_digit=0;
	tmp = num;
	while(tmp>0){
		hex[n_digit] = s_alfabeto[tmp%16];
		tmp = tmp/16;
		n_digit++;
	}	
	while(--n_digit>=0){
		printf("%c", hex[n_digit]);
	}
	printf("\n\n");
	
	// versione 4
	printf("%x", num);
	printf("\n\n");
	
    return 0;
}

