/* costrutto if/if-else annidato in ciclo */
/*
	Chiedere all'utente un anno.
	Controllo input: anno dopo il 1900:
		1. Stampare gli anni tra il 1900 e l'anno inserito.
		2. Stampare gli anni BISESTILI tra il 1900 e l'anno inserito.
	
	BISESTILE: 
		anno divisibile per 400 OPPURE 
		anno divisibile per 4 ma non per 100
*/

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  int anno, i;
  printf("Inserisci anno?\n");
  scanf("%d", &anno);
  // controllo input
  while(anno<1900){
  	printf("Errore anno>=1900 \n");
	printf("inserisci "); scanf("%d", &anno);
  }
  
  // stampa tutti gli anni  
  printf("\n\nstampa tutti gli anni\n");
  i = 1900;
  while(i <= anno) { 
      printf("%d ",i);
      i = i+1;  // equivalente i++;
  }
  
  
  // stampa gli anni bisestili  
  printf("\n\nstampa gli anni bisestili\n");
  i = 1900;
  while(i <= anno) { 
      if(i%400==0 || (i%4==0 && i%100!=0) ){
      	// stampa eseguita solo se anno bisestile
      	printf("%d ",i);
      	// NON serve costrutto else
	  }
	  i = i+1;  // equivalente i++;
  }                     
  system("PAUSE");	
  return 0;
}
