/*
	Chiedere all'utente un numero.
	Controllo input: numero strettamente positivo.
	Stampare a video i divisori del numero inserito.
*/
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  	int x, divisore;
  
  	printf("Inserire numero >0 ");
  	scanf("%d", &x);
  
  	// controllo input
  	while(x<=0){
  		printf("Errore: inserire numero >0 ");
    	scanf("%d", &x);
  	}
  
  	divisore = 1;
  	while (divisore < x){
        if (x%divisore==0){ 
			printf ("%d ", divisore); 
		}
        divisore = divisore + 1;
  	}
  
  	system("PAUSE");	
  	return 0;
}
