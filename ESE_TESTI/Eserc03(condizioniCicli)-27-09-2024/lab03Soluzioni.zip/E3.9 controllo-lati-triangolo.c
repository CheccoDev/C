/*
	Richiedere all'utente 3 valori.
	Controllo input: i valori devono essere i lati di un triangolo.
	Stampare a video l'informazione sul tipo di triangolo: equilatero, isoscele o scaleno.
*/
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
	int x, y, z;
	printf("Valore di x: ");
  	scanf("%d", &x);
  	printf("Valore di y: ");
  	scanf("%d", &y);
  	printf("Valore di y: ");
  	scanf("%d", &z);
	// controllo input
	while(x<=0 || y<=0 || z<=0 || x+y<z || x+z<y || y+z<x ){
		printf("Errore!\ndati inseriti non validi\n");
		printf("Valore di x: ");
	  	scanf("%d", &x);
	  	printf("Valore di y: ");
	  	scanf("%d", &y);
	  	printf("Valore di y: ");
	  	scanf("%d", &z);
	}
	
	// non serve pi� controllo su correttezza dei dati
	// i valori memorizzati in x, y e z sono valori ammissibili
	if( x==y && y==z ){
		printf("equilatero\n");
	}else{
		if( x==y || x==z || y==z ){
			printf("isoscele\n");
		}else{
			printf("scaleno\n");
		}
	}   
                        
  system("PAUSE");	
  return 0;
}
