/* cicli annidati in costrutto if/if-else */
/*
	Chiede all�utente un numero intero positivo x.
	Controllo input: controllare che il valore di x sia compreso tra 0 e 10.

	Se x MINORE di 5
		Stampare a video i numeri compresi tra x e 10 in ordine crescente.
	Altrimenti (x MAGGIORE o UGUALE a 5)
		Stampare a video i numeri compresi tra x e 0 in ordine decrescente.
*/
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
	int x, i = 0;
	printf("Valore massimo della sequenza (min 0 max 10)?\n");
	scanf("%d", &x);
	// controllo input
	while(x<0 || x>10){
		printf("Errore 0<=x<=10 \n");
		printf("x="); scanf("%d", &x);
	}
  
  /* opzione 1 
  valore x non viene modificato: uso variabile i
  */
	printf("\n\nopzione 1\n");
	if (x > 5) {
		i = x;
		while(i >= 0) { 
		  printf("Valore della variabile incrementale i: %d\n",i);
		  --i;  // equivale a x = x-1
		}
	}
	else {
		i = x;
		while(i <= 10) {
		  printf("Valore della variabile incrementale i: %d\n",i);
		  i++;  // equivale a x = x+1
		}
	}  
  
	/* opzione 2 
	valore x viene modificato: 
	alla fine del programma non so qual � il valore inserito dall'utente all'inizio
	*/
	printf("\n\nopzione 2\n");
	if (x > 5) {
		while(x >= 0) { 
		  printf("Valore della variabile incrementale i: %d\n",x);
		  --x;  // equivale a x = x-1
		}
	}
	else {
		while(x <= 10) {
		  printf("Valore della variabile incrementale i: %d\n",x);
		  x++;  // equivale a x = x+1
		}
	}  
                        
  system("PAUSE");	
  return 0;
}
