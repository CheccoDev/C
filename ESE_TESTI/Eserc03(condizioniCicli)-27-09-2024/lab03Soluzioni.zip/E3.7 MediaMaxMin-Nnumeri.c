/*
	Richiedere all'utente il numero di valori interi da inserire (N).
	Richiedere all'utente N numeri interi.
	Calcolare e stmapare a video il massimo, il minimo e la media.
*/
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  int N, min, max, somma, valore, contatore;
	float media;
	printf("di quanti numeri eseguire la media?\n");
	scanf("%d", &N);
	printf("Inserire il primo numero\n");
	scanf("%d", &valore);
	min = valore;
	max = valore;
	somma = valore;
	contatore = 1;
	while (contatore < N){
        printf("Inserire un altro numero\n");
        scanf("%d", &valore);
        if (valore < min){ min = valore; }
        if (valore > max){ max = valore; }
        somma = somma + valore;
        contatore = contatore + 1;
	}
	media = (float)somma/N;
	printf ("Massimo = %d\nMinimo = %d\nMedia = %f\n", max, min, media);
  system("PAUSE");	
  return 0;
}
