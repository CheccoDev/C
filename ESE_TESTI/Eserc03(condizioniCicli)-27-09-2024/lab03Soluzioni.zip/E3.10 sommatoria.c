/*
	Chiedere all'utente gli estremi delle sommatoria (limite inferiore li e limite superiore ls).
	Calcolare le sommatorie:
	1. sommatoria da i=li a ls di i
	2. sommatoria da i=li a ls di i^3
	3. sommatoria da i=li a ls di (a+i)^3 --> richiedere all'utente il valore a
	4. sommatoria da i=li a ls di (-1)^i * i
	5. sommatoria da i=li a ls di (1/i)
*/

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]){
	int limite_inf, limite_sup;
	int tot, i, a;
	
	printf("limite inferiore: "); scanf("%d", &limite_inf);
	printf("limite superiore: "); scanf("%d", &limite_sup);
	
	tot = 0;
	i=limite_inf;
	while(i<=limite_sup){
		tot += i;  // tot = tot + i;
		i++;  // i = i+1;
	}
	printf("\nsomma: %d", tot);

/* i^3 */
    tot = 0;
    i = li;
    while( i <= ls ){
        tot += i*i*i;
        i++;
    }
	printf("\nsomma: %d", tot);


/* (a+i)^3 */
	printf("valore a: "); scanf("%d", &a);
    tot = 0;
    i = li;
    while( i <= ls ){
        tot += (a+i)*(a+i)*(a+i);
        i++;
    }
	printf("\nsomma: %d", tot);


/* (-1)^i*i */
    tot = 0;
    i = li;
    while( i <= ls ){
        if( i%2 == 0 ) tot += i;
        else tot -= i;
        /* operatore ternario
        tot += (i%2==0 ? i : (-1)*i);
        */
        i++;
    }
	printf("\nsomma: %d", tot);



/* (1/i) */
	// NB: il risultato della sommatoria e' un numero con virgola
    float ftot;
    ftot = 0;
    i = li;
    while( i <= ls ){
        ftot += 1.0/i;
        i++;
    }
	printf("\nsomma: %f", ftot);

	system("PAUSE");	
	return 0;
}

