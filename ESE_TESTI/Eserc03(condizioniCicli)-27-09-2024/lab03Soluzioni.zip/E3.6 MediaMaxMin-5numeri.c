/*
	Richiedere all'utente 5 valori interi.
	Calcolare e stmapare a video il massimo, il minimo e la media.
*/

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  int min, max, somma, valore, contatore;
  float media;
  printf("Inserire il primo numero\n");
  scanf("%d", &valore);
  // ipotesi arbitraria: minimo � il primo valore inserito
  min = valore;
  // ipotesi arbitraria: massimo � il primo valore inserito
  max = valore;
  somma = valore;
  contatore = 1;
  while (contatore < 5){
        printf("Inserire un altro numero\n");
        scanf("%d", &valore);
        // controllo se il valore inserito � minore dell'attuale minimo
        if (valore < min){ min = valore; /* trovato un nuovo minimo */ }
        // controllo se il valore inserito � maggiore dell'attuale massimo
        if (valore > max){ max = valore; /* trovato un nuovo massimo */ }
        // sommare i valori
        somma = somma + valore;
        contatore = contatore + 1;
  }
  media = somma / 5.0;
  // se invece si usa:
  // media = somma / 5;
  // cosa accade?
  // e se invece somma fosse definito float?
  printf ("Massimo = %d\nMinimo = %d\nMedia = %f\n", max, min, media);
  system("PAUSE");	
  return 0;
}
