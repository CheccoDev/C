/* 
	Stampare i numeri compresi tra 0 ed un valore definito dall'utente.
*/
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
	int x, i;
	printf("Valore massimo della sequenza?\n");
	scanf("%d",&x);
	i=0;
	while(i <= x) {
		printf("Valore della variabile incrementale i: %d\n",i);
		i++;  // equivale a i = i+1
	}           
  system("PAUSE");	
  return 0;
}
