/* 
	Stampare i numeri compresi tra 0 ed un valore definito dall'utente.
	Controllo input: valore compreso tra 1 e 10 (limit inclusi).
*/
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
	int x, i = 0;
	printf("Valore massimo della sequenza (min 0 max 10)?\n");
	scanf("%d", &x);
	// controllo input
	while(x<0 || x>10){
		printf("Errore 0<=x<=10 \n");
		printf("x="); scanf("%d", &x);
	}
	
	i=0;
	while(i <= x) {
		printf("Valore della variabile incrementale i: %d\n",i);
		i++;  // equivale a i = i+1
	}   
                        
  system("PAUSE");	
  return 0;
}
