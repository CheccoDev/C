#include <stdio.h>
#include <stdlib.h>

typedef struct Tforza{
  char label[10]; //max 9 caratteri
  float x,y,modulo;
}Tforza;
typedef struct Tcollezione{
  Tforza v[20];
  int n;
}Tcollezione;

int main(int argc, char *argv[])
{
	Tcollezione col;
	Tcollezione col_letta, col_letta2;
	FILE *f_txt;
	FILE *f_bin;
	int i;
	// formato TESTO
	// lettura dati da file dati.txt
	// Forza1 (1.1,1.8)=12.4
	// Forza2 (2.5,2.9)=5.2
	// Forza3 (1.9,3.2)=8.9
	// numero elementi NON noto a priori
	f_txt = fopen("dati.txt", "r");
	if(f_txt==NULL){
		printf("Errore apertura file dati.txt");
		return 1;
	}
	//Lettura contenuto
	col.n=0;
	while( fscanf(f_txt, "%s (%f,%f)=%f", col.v[col.n].label, &col.v[col.n].x, &col.v[col.n].y, &col.v[col.n].modulo)==4 ){
		col.n++;
	}
	fclose(f_txt);
	
	//stampa di controllo
	printf("\n\ndim: %d\n\n", col.n);
	i=0;
	for(i=0 ; i<col.n ; i++){
		printf("valore letto: %s %f %f %f\n", col.v[i].label, col.v[i].x, col.v[i].y, col.v[i].modulo);
	}
	
	//scrittura dati collezione formato BINARIO: scrittura collezione
	f_bin = fopen("datibin.txt", "wb");
	if(f_bin==NULL){
		printf("Errore apertura file. datibin wb");
		return 1;
	}
	fwrite(&col, sizeof(Tcollezione), 1, f_bin);
	fclose(f_bin);
	
	//lettura dati collezione formato BINARIO:lettura collezione
	f_bin = fopen("datibin.txt", "rb");
	if(f_bin==NULL){
		printf("Errore apertura file. datibin rb");
		return 1;
	}
	fread(&col_letta, sizeof(Tcollezione), 1, f_bin);
	fclose(f_bin);
	
	// stampa di controllo
	printf("\n\ndim: %d\n\n", col.n);
	i=0;
	for(i=0 ; i<col.n ; i++){
		printf("valore letto (bin): %s %f %f %f\n", col_letta.v[i].label, col_letta.v[i].x, col_letta.v[i].y, col_letta.v[i].modulo);
	}
	
	
	//scrittura n elementi di tipo Tforza formato BINARIO
	f_bin = fopen("datibin2.txt", "wb");
	if(f_bin==NULL){
		printf("Errore apertura file. datibin2 wb");
		return 1;
	}
	fwrite(col.v, sizeof(Tforza), col.n, f_bin);
	fclose(f_bin);
	
	//lettura n elementi di tipo Tforza formato BINARIO
	f_bin = fopen("datibin2.txt", "rb");
	if(f_bin==NULL){
		printf("Errore apertura file. datibin2 rb");
		return 1;
	}
	col_letta2.n=0;
	while( fread(&col_letta2.v[col_letta2.n], sizeof(Tforza), 1, f_bin)>0 ){
		col_letta2.n++;
	}
	fclose(f_bin);
	
	// stampa di controllo
	printf("\n\ndim: %d\n\n", col_letta2.n);
	for(i=0 ; i<col_letta2.n ; i++){
		printf("valore letto (bin): %s %f %f %f\n", col_letta2.v[i].label, col_letta2.v[i].x, col_letta2.v[i].y, col_letta2.v[i].modulo);
	}
	system("PAUSE");
  	return 0;
}

