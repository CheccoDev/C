#define N_MAX_EVENTI 100

typedef struct { 
     int giorno;
     int mese;
     int anno;
     int ora;
     int minuti;
} Tdata;

typedef enum {LEZIONE, PISCINA, APPUNTAMENTO, PALLAVOLO, STUDIO} Attivita;

typedef struct {
   Tdata inizio;
   Tdata fine;
   Attivita attivita;
} Tevento;

typedef struct{
   Tevento eventi [N_MAX_EVENTI];
   int n_eventi;
} Tagenda;

//

Tdata inizializzaData(int anno, int mese, int giorno, int ora, int minuti);
void stampaData(Tdata d);
Tevento inizializzaTevento(Tdata inizio, Tdata fine, Attivita attivita);
void stampaEvento(Tevento e);
Tagenda inizializzaTagenda(void);
void stampaAttivita(Attivita a);
//Tagenda aggiungiTevento(Tagenda a, Tevento e);
void aggiungiTevento(Tagenda* pa, Tevento e);
void stampaAgenda(Tagenda a);
void cancellaUltimoTevento(Tagenda * pa);
void cancellaTevento(Tagenda * pa, int pos);
void inserisciTevento(Tagenda * pa, int pos, Tevento e);

// gestione file
int scriviFile(Tagenda pa, char *nomefile);
int leggiFile(Tagenda *pa, char *nomefile);
int scriviFileBin(Tagenda pa, char *nomefile);
int leggiFileBin(Tagenda *pa, char *nomefile);

