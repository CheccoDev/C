#include <stdio.h>
#include <stdlib.h>
#include "agenda.h"

// gestione file
int scriviFile(Tagenda a, char *nomefile){
	FILE* fout;
	fout=fopen(nomefile, "w");
	if(fout==NULL){  
    	printf("Errore in apertura file W");
    	return 0;
 	}
  	int i;
  	fprintf(fout, "%d\n", a.n_eventi);
  	for(i=0 ; i< a.n_eventi ; i++){  
    	fprintf(fout, "%d %d %d\n", a.eventi[i].inizio.giorno,a.eventi[i].inizio.mese, a.eventi[i].inizio.anno);
    	fprintf(fout, "%d %d\n", a.eventi[i].inizio.ora,a.eventi[i].inizio.minuti);
    	fprintf(fout, "%d %d %d\n", a.eventi[i].fine.giorno,a.eventi[i].fine.mese, a.eventi[i].fine.anno);
    	fprintf(fout, "%d %d\n", a.eventi[i].fine.ora,a.eventi[i].fine.minuti);
     
     	switch(a.eventi[i].attivita){
       		case LEZIONE:
         		fprintf(fout, "Lezione\n"); break;
       		case PISCINA:
         		fprintf(fout, "Piscina\n"); break;
       		case APPUNTAMENTO:
         		fprintf(fout, "Appuntamento\n"); break;
       		case PALLAVOLO: 
         		fprintf(fout, "Pallavolo\n"); break;
       		case STUDIO:
         		fprintf(fout, "Studio\n"); break;
     	} 
   	}
   	fclose(fout);
   	return 1;
}
int leggiFile(Tagenda *pa, char *nomefile){
	FILE *fin;
  	fin=fopen(nomefile, "r");
  	if(fin==NULL){
  		printf("Errore in apertura file R");
     	return 0;
  	}
  	int i;
  	char tmp[20];
  	fscanf(fin, "%d", &(pa->n_eventi));
  	for(i=0 ; i< pa->n_eventi ; i++) {
    	fscanf(fin, "%d %d %d", &(pa->eventi[i].inizio.giorno),&(pa->eventi[i].inizio.mese), &(pa->eventi[i].inizio.anno));
    	fscanf(fin, "%d %d", &(pa->eventi[i].inizio.ora),&(pa->eventi[i].inizio.minuti));
    	fscanf(fin, "%d %d %d", &(pa->eventi[i].fine.giorno),&(pa->eventi[i].fine.mese), &(pa->eventi[i].fine.anno));
    	fscanf(fin, "%d %d", &(pa->eventi[i].fine.ora),&(pa->eventi[i].fine.minuti));
    	fscanf(fin, "%s", tmp);
     	if(!strcmp(tmp, "Lezione"))
        { pa->eventi[i].attivita=LEZIONE; }
     	if(!strcmp(tmp, "Piscina"))
        { pa->eventi[i].attivita=PISCINA; }
     	if(!strcmp(tmp, "Appuntamento"))
        { pa->eventi[i].attivita=APPUNTAMENTO; }
     	if(!strcmp(tmp, "Pallavolo"))
        { pa->eventi[i].attivita=PALLAVOLO; }
     	if(!strcmp(tmp, "Studio"))
        { pa->eventi[i].attivita=STUDIO; }
  	}
  	fclose(fin);
  	return 1;
}
int scriviFileBin(Tagenda a, char *nomefile){
	FILE* fout;
  	fout=fopen(nomefile, "wb");
  	if(fout==NULL){
    	printf("Errore in apertura file WB agenda");
    	return 0;
  	}
  	fwrite(&a, sizeof(Tagenda), 1, fout);
  	fclose(fout);
  	return 1;
}
int leggiFileBin(Tagenda *pa, char *nomefile){
	FILE* fin;
  	fin=fopen(nomefile, "rb");
  	if(fin==NULL){
    	printf("Errore in apertura file RB agenda");
    	return 0;
  	}
  	fread(pa, sizeof(Tagenda), 	1, fin);
  	fclose(fin);
  	return 1;
}



Tdata inizializzaData(int anno, int mese, int giorno, int ora, int minuti){
    Tdata daRitornare;
    daRitornare.anno = anno;
    daRitornare.mese = mese;
    daRitornare.giorno = giorno;
    daRitornare.ora = ora;
    daRitornare.minuti = minuti;
    return daRitornare;
}
void stampaData(Tdata d){
	printf("%2d/%02d/%4d %02d:%02d",
		d.giorno,d.mese,d.anno,d.ora,d.minuti);
}

void stampaAttivita(Attivita a){
  switch(a){
    case LEZIONE:
      printf("Lezione");
    break;
    case PISCINA:
      printf("Piscina");
    break;
    case APPUNTAMENTO:
      printf("Appuntamento");
    break;
    case PALLAVOLO: 
      printf("Pallavolo");
    break;
    case STUDIO:
      printf("Studio");
    break;
  }
}

Tevento inizializzaTevento(Tdata inizio, Tdata fine, Attivita attivita){
   Tevento daRitornare;
   daRitornare.inizio = inizio;
   daRitornare.fine = fine;
   daRitornare.attivita = attivita;
   return daRitornare;
}

void stampaEvento(Tevento e){
   printf("Inizio: ");
   stampaData(e.inizio);
   printf("\n");
   printf("Fine: ");
   stampaData(e.fine);
   printf("\n");
   stampaAttivita(e.attivita);
}

Tagenda inizializzaTagenda(void){
   Tagenda daRitornare;
   daRitornare.n_eventi = 0;
   return daRitornare;
}

void aggiungiTevento(Tagenda* pa, Tevento e){
   if (pa->n_eventi >= N_MAX_EVENTI){
      printf("Errore, l'agenda e' piena\n");
   } else {
      pa->eventi[pa->n_eventi] = e;
      pa->n_eventi++;
    }
}
void cancellaUltimoTevento(Tagenda* pa){ 
     pa->n_eventi--; 
}

void cancellaTevento(Tagenda* pa, int pos){
  if (pos>pa->n_eventi-1)
   { return;}
  int i;
  for (i=pos; i<pa->n_eventi-1; i++)
   { pa->eventi[i]=pa->eventi[i+1];  } 
  pa->n_eventi--;  
}

void inserisciTevento(Tagenda * pa, int pos, Tevento e){
  if (pos>pa->n_eventi+1)
   { return;} 
  int i;
  for (i=pa->n_eventi; i>pos; i--)
   { pa->eventi[i]=pa->eventi[i-1];  }
   pa->n_eventi++;    
   pa->eventi[pos]=e; 
}

void stampaAgenda(Tagenda a){
	int i;
	for (i = 0; i < a.n_eventi; i++){
		printf("Tevento in posizione %d:\n", i);
		stampaEvento(a.eventi[i]);
		printf("\n\n");
	}
}
