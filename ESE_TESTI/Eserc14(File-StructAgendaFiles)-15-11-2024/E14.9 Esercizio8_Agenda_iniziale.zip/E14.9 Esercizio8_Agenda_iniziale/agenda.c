#include <stdio.h>
#include <stdlib.h>
#include "agenda.h"

Tdata inizializzaData(int anno, int mese, int giorno, int ora, int minuti){
    Tdata daRitornare;
    daRitornare.anno = anno;
    daRitornare.mese = mese;
    daRitornare.giorno = giorno;
    daRitornare.ora = ora;
    daRitornare.minuti = minuti;
    return daRitornare;
}
void stampaData(Tdata d){
	printf("%2d/%02d/%4d %02d:%02d",
		d.giorno,d.mese,d.anno,d.ora,d.minuti);
}

void stampaAttivita(Attivita a){
  switch(a){
    case LEZIONE:
      printf("Lezione");
    break;
    case PISCINA:
      printf("Piscina");
    break;
    case APPUNTAMENTO:
      printf("Appuntamento");
    break;
    case PALLAVOLO: 
      printf("Pallavolo");
    break;
    case STUDIO:
      printf("Studio");
    break;
  }
}

Tevento inizializzaTevento(Tdata inizio, Tdata fine, Attivita attivita){
   Tevento daRitornare;
   daRitornare.inizio = inizio;
   daRitornare.fine = fine;
   daRitornare.attivita = attivita;
   return daRitornare;
}

void stampaEvento(Tevento e){
   printf("Inizio: ");
   stampaData(e.inizio);
   printf("\n");
   printf("Fine: ");
   stampaData(e.fine);
   printf("\n");
   stampaAttivita(e.attivita);
}

Tagenda inizializzaTagenda(void){
   Tagenda daRitornare;
   daRitornare.n_eventi = 0;
   return daRitornare;
}

void aggiungiTevento(Tagenda* pa, Tevento e){
   if (pa->n_eventi >= N_MAX_EVENTI){
      printf("Errore, l'agenda e' piena\n");
   } else {
      pa->eventi[pa->n_eventi] = e;
      pa->n_eventi++;
    }
}
void cancellaUltimoTevento(Tagenda* pa){ 
     pa->n_eventi--; 
}

void cancellaTevento(Tagenda* pa, int pos){
  if (pos>pa->n_eventi-1)
   { return;}
  int i;
  for (i=pos; i<pa->n_eventi-1; i++)
   { pa->eventi[i]=pa->eventi[i+1];  } 
  pa->n_eventi--;  
}

void inserisciTevento(Tagenda * pa, int pos, Tevento e){
  if (pos>pa->n_eventi+1)
   { return;} 
  int i;
  for (i=pa->n_eventi; i>pos; i--)
   { pa->eventi[i]=pa->eventi[i-1];  }
   pa->n_eventi++;    
   pa->eventi[pos]=e; 
}

void stampaAgenda(Tagenda a){
	int i;
	for (i = 0; i < a.n_eventi; i++){
		printf("Tevento in posizione %d:\n", i);
		stampaEvento(a.eventi[i]);
		printf("\n\n");
	}
}
