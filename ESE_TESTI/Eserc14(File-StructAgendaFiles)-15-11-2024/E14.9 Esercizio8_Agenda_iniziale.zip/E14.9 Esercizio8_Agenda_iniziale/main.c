#include <stdio.h>
#include <stdlib.h>
#include "agenda.h"

int main(void) {
	Tdata d1, d2;
	Tevento e;
	Tagenda a;

	a = inizializzaTagenda();

	d1 = inizializzaData(2018,6,10,10,30);
	d2 = inizializzaData(2018,6,10,11,30);
	e = inizializzaTevento(d1,d2,PISCINA);
	aggiungiTevento(&a, e);
	
	d1 = inizializzaData(2018,6,11,14,30);
	d2 = inizializzaData(2018,6,11,16,0);
	e = inizializzaTevento(d1,d2,STUDIO);
	aggiungiTevento(&a, e);

	d1 = inizializzaData(2018,7,11,16,0);
	d2 = inizializzaData(2018,6,11,16,30);
	e = inizializzaTevento(d1,d2,APPUNTAMENTO);
	aggiungiTevento(&a, e);
	
	//cancellaUltimoTevento(&a);
	//cancellaTevento(&a,2); //provare con posizioni 1 e 2
	d1 = inizializzaData(2018,1,11,12,0);
	d2 = inizializzaData(2018,1,11,12,30);
	e = inizializzaTevento(d1,d2,STUDIO);
	inserisciTevento(&a,0,e);
	stampaAgenda(a);
	
 	return 0;
}
