#include <stdio.h>
#include <stdlib.h>

int fatt(int n, FILE* pf);
void readFile(FILE* pf);

int main(int argc, char *argv[]){
  //fattoriale
  int d;
  FILE* pf;
  pf = fopen("fatt.txt","w");
  
  printf("d="); scanf("%d",&d);
  printf("fatt di %d = %d\n",d,fatt(d,pf));
  
  fclose(pf);
  pf = fopen("fatt.txt","r");  
// Call funzione fattoriale che legge da file i dati
  readFile(pf); 
  fclose (pf);

  
  system("PAUSE"); return 0;
}
// n! = n * (n-1)! ricorsione
// caso base 1! = 1   0! = 1
int fatt(int n, FILE* pf){
  int ris;
  //fprintf(pf,"%d\n",n);
  if (n==0 || n==1)
   { return 1; }
  ris= n * fatt(n-1,pf); 
  fprintf(pf,"%d\n",ris);
  return ris;
}

void readFile(FILE* pf) {
 int dato;
  do {
    fscanf(pf,"%d",&dato);
    fprintf(stdout,"%d \n", dato);
    
    //printf("ERRORE=%d ",ferror(pf));
    /*if (!feof(pf)){
      fscanf(pf,"%d",&dato); 
      fprintf(stdout,"%d \n", dato);
    }*/
  }while( !feof(pf) );
}





