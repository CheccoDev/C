#include <cstdlib>
#include <iostream>
using namespace std;
typedef struct Forza{
  char label[10]; //max 9 caratteri
  float x,y,modulo;
} Forza;

int main(int argc, char *argv[]){
  FILE* pf;
  FILE* pf1;
  Forza f;

  pf=fopen("dati.txt","r");
  pf1=fopen("risultati.txt","w");
  if (pf==NULL){ 
     printf("ERRORE apertura file");             
     system("PAUSE");  return 1;
   }
 
  //scorrere il file e leggerne il contenuto
  do {
    //fscanf(pf,"%s",label); fscanf(pf,"%f",&x);  fscanf(pf,"%f",&y); fscanf(pf,"%f",&modulo); 
    fscanf(pf,"%s (%f,%f)=%f",f.label,&f.x,&f.y,&f.modulo);
    f.modulo *= 2;  //modulo moltiplicato per 2
    //printf("ERRORE=%d ",ferror(pf));
    if (!feof(pf))    
     { 
      fwrite(&f,sizeof(Forza),1,pf1);                
      printf("%s (%3.1f;%3.1f) %5.2f\n",f.label,f.x,f.y,f.modulo); 
     }
  }while( !feof(pf) );
   
  fclose(pf); fclose(pf1);
  pf1=fopen("risultati.txt","r");
  do {
    fread(&f,sizeof(f),1,pf1);
    if ( !feof(pf1) )
     { printf("%s [%3.1f;%3.1f] %5.2f\n",f.label,f.x,f.y,f.modulo); }
  } while( !feof(pf1) );
  fclose(pf1);
  system("PAUSE");
  return 0;
}



