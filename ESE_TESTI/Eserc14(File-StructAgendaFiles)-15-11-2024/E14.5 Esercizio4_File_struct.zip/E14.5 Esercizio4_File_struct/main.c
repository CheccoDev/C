#include <stdio.h>
#include <stdlib.h>
#define N 3
typedef struct Forza{
  float m;
  int a;      
} Forza;

int Random(int min, int max);
void InitArrayForze(Forza miaF[], int numEle);
void InitForza(Forza* pF);
void Stampa(Forza miaF[], int numEle);
void ScriviFile(Forza miaF[], int numEle, FILE* miofile);

int main(int argc, char *argv[])
{
   Forza f[N];  //array di forze
   Forza fdafile;
   int i;
   srand(time(0));
   FILE* miofile;
   
   //apertura file in scrittura
   miofile = fopen("dati.txt","w");
   InitArrayForze(f,N);
   Stampa(f,N);
   ScriviFile(f,N,miofile);
   fclose(miofile);
   
   //apertura file in lettura
   //esempio di riga nel file: 23.000 110
   miofile=fopen("dati.txt","r");
   while (!feof(miofile)){
      fscanf(miofile,"%f",&fdafile.m);
      fscanf(miofile,"%d",&fdafile.a);
      if (!feof(miofile)){ 
        printf("[%f,%d]\n",fdafile.m,fdafile.a); 
      }
   }
   fclose(miofile);
   system("PAUSE");	
   return 0;
}

void ScriviFile(Forza miaF[], int numEle, FILE* miofile){ 
  int i; 
  for (i=0; i<N; i++){
    fprintf(miofile,"%5.3f %d\n", miaF[i].m, miaF[i].a);
    //fprintf(stdout,"%5.3f %d\n",F[i].m,F[i].a);
    //printf("%5.3f %d\n",F[i].m,F[i].a);
  }    
}
void Stampa(Forza miaF[], int numEle){ 
  int i;
  for (i=0;i<numEle; i++){ 
      printf("[%5.3f,%d]\n",miaF[i].m,miaF[i].a); 
  }
  printf("\n");
}
void InitArrayForze(Forza miaF[], int numEle){
  int i;
  for (i=0; i<numEle; i++) { 
     InitForza(&miaF[i]);  
  }
}
int Random(int min, int max){ 
    return rand()%(max-min+1)+min; 
}
void InitForza(Forza* pF){
  //pF->m=Random(0,20);  //(*pF).m   
  printf("modulo=");
  scanf("%f",&pF->m);
  pF->a=Random(0,359);
}


